// List resource for Frappe list views
import { createResource } from './resources'

interface ListResourceOptions {
  doctype: string
  fields?: string[]
  filters?: Record<string, any>
  orderBy?: string
  pageLength?: number
  auto?: boolean
  cache?: string | boolean
  onSuccess?: (data: any) => void
  onError?: (error: Error) => void
}

export function createListResource(options: ListResourceOptions | string) {
  if (typeof options === 'string') {
    options = { doctype: options }
  }
  
  const { doctype, fields, filters, orderBy, pageLength, ...resourceOptions } = options
  
  const makeParams = (params: any = {}) => {
    return {
      doctype,
      fields: fields ? JSON.stringify(fields) : undefined,
      filters: filters ? JSON.stringify(filters) : undefined,
      order_by: orderBy,
      page_length: pageLength || 20,
      ...params,
    }
  }
  
  return createResource({
    url: '/api/method/frappe.desk.reportview.get',
    method: 'POST',
    makeParams,
    ...resourceOptions,
  })
}

export function getCachedListResource(doctype: string) {
  return getCachedResource(`list-${doctype}`)
}

// Import getCachedResource from resources
import { getCachedResource } from './resources'
