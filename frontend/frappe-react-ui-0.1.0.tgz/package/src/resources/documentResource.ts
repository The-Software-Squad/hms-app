// Document resource for Frappe documents
import { createResource } from './resources'

interface DocumentResourceOptions {
  doctype: string
  name?: string
  auto?: boolean
  cache?: string | boolean
  onSuccess?: (doc: any) => void
  onError?: (error: Error) => void
}

export function createDocumentResource(options: DocumentResourceOptions | string) {
  if (typeof options === 'string') {
    const [doctype, name] = options.split('/')
    options = { doctype, name }
  }
  
  const { doctype, name, ...resourceOptions } = options
  
  const url = name 
    ? `/api/resource/${doctype}/${name}`
    : `/api/resource/${doctype}`
  
  return createResource({
    url,
    method: name ? 'GET' : 'POST',
    ...resourceOptions,
  })
}

export function getCachedDocumentResource(doctype: string, name?: string) {
  const cacheKey = name ? `${doctype}/${name}` : doctype
  return getCachedResource(cacheKey)
}

// Import getCachedResource from resources
import { getCachedResource } from './resources'
