// Legacy resources system for backward compatibility
// This is a simplified React version of the Vue resources system

import { request } from '../utils/request'
import { debounce } from '../utils/debounce'
// Legacy resources system for backward compatibility

interface ResourceOptions {
  url: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  auto?: boolean
  cache?: string | boolean
  debounce?: number
  initialData?: any
  makeParams?: (params: any) => any
  validate?: (params: any) => string | void | Promise<string | void>
  onFetch?: (params: any) => void
  onSuccess?: (data: any) => void
  onError?: (error: Error) => void
  onData?: (data: any) => void
  beforeSubmit?: (params: any) => void
}

export interface Resource {
  url: string
  method?: string
  data: any
  previousData: any
  loading: boolean
  fetched: boolean
  error: Error | null
  promise: Promise<any> | null
  auto?: boolean
  params: any
  fetch: (params?: any, options?: any) => Promise<any>
  reload: (params?: any, options?: any) => Promise<any>
  submit: (params?: any, options?: any) => Promise<any>
  reset: () => void
  update: (data: any) => void
  setData: (data: any) => void
}

let cached: Record<string, Resource> = {}

function getCacheKey(cache: string | boolean): string {
  return typeof cache === 'string' ? cache : 'default'
}

export function createResource(optionsInput: ResourceOptions | string): Resource {
  let cacheKey: string | null = null
  
  const options: ResourceOptions = typeof optionsInput === 'string' 
    ? { url: optionsInput, auto: true }
    : optionsInput
  
  if (options.cache) {
    cacheKey = getCacheKey(options.cache)
    let cachedResource = cached[cacheKey]
    
    if (cachedResource) {
      if (cachedResource.auto) {
        cachedResource.reload()
      }
      return cachedResource
    }
  }
  
  async function fetchData(params?: any, tempOptions: any = {}): Promise<any> {
    return fetch(params, tempOptions)
  }

  const fetchFunction = options.debounce
    ? (async (...args: any[]) => {
        const debouncedFn = debounce(fetchData, options.debounce!)
        debouncedFn(...args)
        return fetchData(...args)
      })
    : fetchData
  
  const resource: Resource = {
    url: options.url,
    method: options.method as 'GET' | 'POST' | 'PUT' | 'DELETE' | undefined,
    data: options.initialData || null,
    previousData: null,
    loading: false,
    fetched: false,
    error: null,
    promise: null,
    auto: options.auto,
    params: null,
    fetch: fetchFunction,
    reload: fetchFunction,
    submit: fetchFunction,
    reset,
    update,
    setData,
  }
  
  async function fetch(params?: any, tempOptions: any = {}): Promise<any> {
    const resourceFetcher = request
    
    if (params instanceof Event) {
      params = null
    }
    
    params = params || resource.params
    if (options.makeParams) {
      params = options.makeParams(params)
    }
    
    resource.params = params
    resource.previousData = resource.data ? JSON.parse(JSON.stringify(resource.data)) : null
    resource.loading = true
    resource.error = null
    
    if (options.onFetch) {
      options.onFetch(resource.params)
    }
    
    const beforeSubmitFunctions = [options.beforeSubmit, tempOptions.beforeSubmit]
    for (const fn of beforeSubmitFunctions) {
      if (fn) {
        fn(resource.params)
      }
    }
    
    const validateFunction = tempOptions.validate || options.validate
    const errorFunctions = [options.onError, tempOptions.onError]
    const successFunctions = [options.onSuccess, tempOptions.onSuccess]
    const dataFunctions = [options.onData, tempOptions.onData]
    
    if (validateFunction) {
      try {
        const invalidMessage = await validateFunction(resource.params)
        if (invalidMessage && typeof invalidMessage === 'string') {
          throw new Error(invalidMessage)
        }
      } catch (error) {
        handleError(error as Error, errorFunctions)
        return
      }
    }
    
    try {
      resource.promise = resourceFetcher(resource.url, {
        method: resource.method as 'GET' | 'POST' | 'PUT' | 'DELETE' | undefined,
        body: resource.method !== 'GET' ? params : undefined,
        params: resource.method === 'GET' ? params : undefined,
      })
      
      const data = await resource.promise
      
      resource.loading = false
      resource.fetched = true
      resource.data = data
      
      for (const fn of successFunctions) {
        if (fn) {
          fn(data)
        }
      }
      
      for (const fn of dataFunctions) {
        if (fn) {
          fn(data)
        }
      }
      
      return data
    } catch (error) {
      handleError(error as Error, errorFunctions)
      throw error
    }
  }
  
  function handleError(error: Error, errorFunctions: Array<((error: Error) => void) | undefined>) {
    resource.loading = false
    resource.error = error
    
    for (const fn of errorFunctions) {
      if (fn) {
        fn(error)
      }
    }
  }
  
  function reset() {
    resource.data = options.initialData || null
    resource.previousData = null
    resource.loading = false
    resource.fetched = false
    resource.error = null
    resource.promise = null
    resource.params = null
  }
  
  function update(data: any) {
    resource.data = data
  }
  
  function setData(data: any) {
    resource.data = data
  }
  
  if (options.auto) {
    fetch()
  }
  
  if (cacheKey) {
    cached[cacheKey] = resource
  }
  
  return resource
}

export function getCachedResource(cacheKey: string): Resource | null {
  return cached[cacheKey] || null
}
