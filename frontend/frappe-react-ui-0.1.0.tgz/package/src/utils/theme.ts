// Theme utilities for frappe-react-ui

export type Theme = 'gray' | 'blue' | 'green' | 'red' | 'yellow' | 'purple'
export type Variant = 'solid' | 'subtle' | 'outline' | 'ghost'
export type Size = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl'

export const themes: Record<Theme, string> = {
  gray: 'gray',
  blue: 'blue',
  green: 'green',
  red: 'red',
  yellow: 'yellow',
  purple: 'purple',
}

export const variants: Record<Variant, string> = {
  solid: 'solid',
  subtle: 'subtle',
  outline: 'outline',
  ghost: 'ghost',
}

export const sizes: Record<Size, string> = {
  xs: 'xs',
  sm: 'sm',
  md: 'md',
  lg: 'lg',
  xl: 'xl',
  '2xl': '2xl',
}

// Theme class generators
export function getThemeClasses(theme: Theme, variant: Variant): string {
  const baseClasses = {
    solid: {
      gray: 'bg-gray-900 text-white hover:bg-gray-800',
      blue: 'bg-blue-600 text-white hover:bg-blue-700',
      green: 'bg-green-600 text-white hover:bg-green-700',
      red: 'bg-red-600 text-white hover:bg-red-700',
      yellow: 'bg-yellow-500 text-white hover:bg-yellow-600',
      purple: 'bg-purple-600 text-white hover:bg-purple-700',
    },
    subtle: {
      gray: 'bg-gray-100 text-gray-900 hover:bg-gray-200',
      blue: 'bg-blue-50 text-blue-700 hover:bg-blue-100',
      green: 'bg-green-50 text-green-700 hover:bg-green-100',
      red: 'bg-red-50 text-red-700 hover:bg-red-100',
      yellow: 'bg-yellow-50 text-yellow-700 hover:bg-yellow-100',
      purple: 'bg-purple-50 text-purple-700 hover:bg-purple-100',
    },
    outline: {
      gray: 'border border-gray-300 text-gray-700 hover:bg-gray-50',
      blue: 'border border-blue-300 text-blue-700 hover:bg-blue-50',
      green: 'border border-green-300 text-green-700 hover:bg-green-50',
      red: 'border border-red-300 text-red-700 hover:bg-red-50',
      yellow: 'border border-yellow-300 text-yellow-700 hover:bg-yellow-50',
      purple: 'border border-purple-300 text-purple-700 hover:bg-purple-50',
    },
    ghost: {
      gray: 'text-gray-700 hover:bg-gray-100',
      blue: 'text-blue-700 hover:bg-blue-50',
      green: 'text-green-700 hover:bg-green-50',
      red: 'text-red-700 hover:bg-red-50',
      yellow: 'text-yellow-700 hover:bg-yellow-50',
      purple: 'text-purple-700 hover:bg-purple-50',
    },
  }
  
  return baseClasses[variant][theme] || baseClasses.solid.gray
}

export function getSizeClasses(size: Size): string {
  const sizeClasses = {
    xs: 'px-2 py-1 text-xs',
    sm: 'px-3 py-1.5 text-sm',
    md: 'px-4 py-2 text-sm',
    lg: 'px-4 py-2 text-base',
    xl: 'px-6 py-3 text-base',
    '2xl': 'px-8 py-4 text-lg',
  }
  
  return sizeClasses[size] || sizeClasses.md
}

// Color utilities
export function getColorValue(theme: Theme, shade: number = 500): string {
  const colors = {
    gray: {
      50: '#f9fafb',
      100: '#f3f4f6',
      200: '#e5e7eb',
      300: '#d1d5db',
      400: '#9ca3af',
      500: '#6b7280',
      600: '#4b5563',
      700: '#374151',
      800: '#1f2937',
      900: '#111827',
    },
    blue: {
      50: '#eff6ff',
      100: '#dbeafe',
      200: '#bfdbfe',
      300: '#93c5fd',
      400: '#60a5fa',
      500: '#3b82f6',
      600: '#2563eb',
      700: '#1d4ed8',
      800: '#1e40af',
      900: '#1e3a8a',
    },
    green: {
      50: '#f0fdf4',
      100: '#dcfce7',
      200: '#bbf7d0',
      300: '#86efac',
      400: '#4ade80',
      500: '#22c55e',
      600: '#16a34a',
      700: '#15803d',
      800: '#166534',
      900: '#14532d',
    },
    red: {
      50: '#fef2f2',
      100: '#fee2e2',
      200: '#fecaca',
      300: '#fca5a5',
      400: '#f87171',
      500: '#ef4444',
      600: '#dc2626',
      700: '#b91c1c',
      800: '#991b1b',
      900: '#7f1d1d',
    },
    yellow: {
      50: '#fefce8',
      100: '#fef3c7',
      200: '#fde68a',
      300: '#fcd34d',
      400: '#fbbf24',
      500: '#f59e0b',
      600: '#d97706',
      700: '#b45309',
      800: '#92400e',
      900: '#78350f',
    },
    purple: {
      50: '#faf5ff',
      100: '#f3e8ff',
      200: '#e9d5ff',
      300: '#d8b4fe',
      400: '#c084fc',
      500: '#a855f7',
      600: '#9333ea',
      700: '#7c3aed',
      800: '#6b21a8',
      900: '#581c87',
    },
  }
  
  return colors[theme]?.[shade as keyof typeof colors[typeof theme]] || colors.gray[500]
}
