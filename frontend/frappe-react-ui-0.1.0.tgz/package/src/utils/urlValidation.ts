// URL validation utilities

export function isValidUrl(string: string): boolean {
  try {
    new URL(string)
    return true
  } catch (_) {
    return false
  }
}

export function isValidHttpUrl(string: string): boolean {
  try {
    const url = new URL(string)
    return url.protocol === 'http:' || url.protocol === 'https:'
  } catch (_) {
    return false
  }
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function normalizeUrl(url: string): string {
  if (!url) return ''
  
  // Add protocol if missing
  if (!url.match(/^https?:\/\//)) {
    url = 'https://' + url
  }
  
  try {
    const urlObj = new URL(url)
    return urlObj.toString()
  } catch (_) {
    return url
  }
}

export function getDomain(url: string): string {
  try {
    const urlObj = new URL(url)
    return urlObj.hostname
  } catch (_) {
    return ''
  }
}

export function isInternalUrl(url: string, baseUrl?: string): boolean {
  try {
    const urlObj = new URL(url)
    const currentDomain = baseUrl ? new URL(baseUrl).hostname : window.location.hostname
    return urlObj.hostname === currentDomain
  } catch (_) {
    // If it's not a valid URL, assume it's a relative path (internal)
    return !url.startsWith('http')
  }
}

export function buildUrl(base: string, params: Record<string, any> = {}): string {
  try {
    const url = new URL(base)
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        url.searchParams.set(key, String(value))
      }
    })
    
    return url.toString()
  } catch (_) {
    return base
  }
}

export function parseUrl(url: string) {
  try {
    const urlObj = new URL(url)
    const params: Record<string, string> = {}
    
    urlObj.searchParams.forEach((value, key) => {
      params[key] = value
    })
    
    return {
      protocol: urlObj.protocol,
      hostname: urlObj.hostname,
      port: urlObj.port,
      pathname: urlObj.pathname,
      search: urlObj.search,
      hash: urlObj.hash,
      params,
    }
  } catch (_) {
    return null
  }
}
