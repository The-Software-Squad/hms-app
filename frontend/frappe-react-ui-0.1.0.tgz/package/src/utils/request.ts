// Generic request utility (used by resources)
export interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  headers?: Record<string, string>
  body?: any
  params?: Record<string, any>
}

export async function request(url: string, options: RequestOptions = {}): Promise<any> {
  const { method = 'GET', headers = {}, body, params } = options
  
  // Build URL with params
  let finalUrl = url
  if (params && Object.keys(params).length > 0) {
    const searchParams = new URLSearchParams()
    Object.entries(params).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        searchParams.append(key, String(value))
      }
    })
    finalUrl += (finalUrl.includes('?') ? '&' : '?') + searchParams.toString()
  }
  
  // Prepare request options
  const requestOptions: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
    credentials: 'include',
  }
  
  // Add body for POST/PUT requests
  if (body && (method === 'POST' || method === 'PUT')) {
    requestOptions.body = typeof body === 'string' ? body : JSON.stringify(body)
  }
  
  try {
    const response = await fetch(finalUrl, requestOptions)
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }
    
    const contentType = response.headers.get('content-type')
    if (contentType && contentType.includes('application/json')) {
      return await response.json()
    }
    
    return await response.text()
  } catch (error) {
    console.error('Request failed:', error)
    throw error
  }
}
