// Simple markdown parser for basic formatting
export function parseMarkdown(text: string): string {
  if (!text) return ''

  let html = text
    // Escape HTML first
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    
    // Headers
    .replace(/^### (.*$)/gm, '<h3>$1</h3>')
    .replace(/^## (.*$)/gm, '<h2>$1</h2>')
    .replace(/^# (.*$)/gm, '<h1>$1</h1>')
    
    // Bold and italic
    .replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>')
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.*?)\*/g, '<em>$1</em>')
    
    // Code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    
    // Links
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
    
    // Line breaks
    .replace(/\n/g, '<br>')

  return html
}

// Convert markdown to plain text
export function markdownToText(text: string): string {
  if (!text) return ''

  return text
    // Remove headers
    .replace(/^#{1,6}\s+/gm, '')
    
    // Remove bold and italic
    .replace(/\*\*\*(.*?)\*\*\*/g, '$1')
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/\*(.*?)\*/g, '$1')
    
    // Remove code
    .replace(/`([^`]+)`/g, '$1')
    
    // Convert links to text
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    
    // Clean up extra whitespace
    .replace(/\s+/g, ' ')
    .trim()
}

// Extract links from markdown
export function extractMarkdownLinks(text: string): Array<{ text: string; url: string }> {
  const links: Array<{ text: string; url: string }> = []
  const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g
  let match

  while ((match = linkRegex.exec(text)) !== null) {
    links.push({
      text: match[1],
      url: match[2],
    })
  }

  return links
}
