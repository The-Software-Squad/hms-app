import { frappeRequest } from './frappeRequest'

export interface CallOptions {
  method?: string
  args?: Record<string, any>
  callback?: (response: any) => void
  error?: (error: Error) => void
  freeze?: boolean
  btn?: HTMLElement
}

/**
 * Make a server-side method call to Frappe
 */
export async function call(
  method: string, 
  args: Record<string, any> = {}, 
  options: Omit<CallOptions, 'method' | 'args'> = {}
): Promise<any> {
  const { callback, error, freeze, btn } = options
  
  // Disable button if provided
  if (btn && freeze !== false) {
    btn.setAttribute('disabled', 'true')
  }
  
  try {
    const response = await frappeRequest('/api/method/' + method, {
      method: 'POST',
      body: args,
    })
    
    if (callback) {
      callback(response)
    }
    
    return response
  } catch (err) {
    if (error) {
      error(err as Error)
    } else {
      console.error('Frappe call failed:', err)
    }
    throw err
  } finally {
    // Re-enable button
    if (btn && freeze !== false) {
      btn.removeAttribute('disabled')
    }
  }
}

/**
 * Create a reusable call function with predefined options
 */
export function createCall(defaultOptions: CallOptions = {}) {
  return (method: string, args: Record<string, any> = {}, options: CallOptions = {}) => {
    return call(method, args, { ...defaultOptions, ...options })
  }
}

export default call
