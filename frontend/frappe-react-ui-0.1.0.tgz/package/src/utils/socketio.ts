import { io, Socket } from 'socket.io-client'
import { getConfig } from './config'

let socket: Socket | null = null

export interface SocketOptions {
  port?: number
  namespace?: string
  auth?: Record<string, any>
}

export function initSocket(options: SocketOptions = {}): Socket {
  if (socket && socket.connected) {
    return socket
  }
  
  const config = getConfig()
  const port = options.port || config.socketPort || 9000
  const namespace = options.namespace || ''
  
  // Construct socket URL
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
  const hostname = window.location.hostname
  const socketUrl = `${protocol}//${hostname}:${port}${namespace}`
  
  socket = io(socketUrl, {
    withCredentials: true,
    transports: ['websocket', 'polling'],
    auth: {
      ...options.auth,
    },
  })
  
  // Add default event listeners
  socket.on('connect', () => {
    console.log('Socket.IO connected:', socket?.id)
  })
  
  socket.on('disconnect', (reason) => {
    console.log('Socket.IO disconnected:', reason)
  })
  
  socket.on('connect_error', (error) => {
    console.error('Socket.IO connection error:', error)
  })
  
  return socket
}

export function getSocket(): Socket | null {
  return socket
}

export function disconnectSocket(): void {
  if (socket) {
    socket.disconnect()
    socket = null
  }
}

// React hook for socket connection
export function useSocket(options: SocketOptions = {}) {
  const [isConnected, setIsConnected] = React.useState(false)
  
  React.useEffect(() => {
    const socketInstance = initSocket(options)
    
    const handleConnect = () => setIsConnected(true)
    const handleDisconnect = () => setIsConnected(false)
    
    socketInstance.on('connect', handleConnect)
    socketInstance.on('disconnect', handleDisconnect)
    
    // Set initial state
    setIsConnected(socketInstance.connected)
    
    return () => {
      socketInstance.off('connect', handleConnect)
      socketInstance.off('disconnect', handleDisconnect)
    }
  }, [])
  
  return {
    socket: getSocket(),
    isConnected,
    disconnect: disconnectSocket,
  }
}

export default initSocket

// Import React for the hook
import React from 'react'
