import { getConfig } from './config'

interface FrappeRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  headers?: Record<string, string>
  body?: any
  params?: Record<string, any>
}

export async function frappeRequest(
  url: string, 
  options: FrappeRequestOptions = {}
): Promise<any> {
  const config = getConfig()
  const baseUrl = config.baseUrl || ''
  
  // Construct full URL
  const fullUrl = url.startsWith('http') ? url : `${baseUrl}${url}`
  
  // Prepare headers
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    ...options.headers,
  }
  
  // Add CSRF token if available
  if (typeof window !== 'undefined' && window.csrf_token) {
    headers['X-Frappe-CSRF-Token'] = window.csrf_token
  }
  
  // Prepare request options
  const requestOptions: RequestInit = {
    method: options.method || 'GET',
    headers,
    credentials: 'include', // Include cookies for authentication
  }
  
  // Add body for POST/PUT requests
  if (options.body && (options.method === 'POST' || options.method === 'PUT')) {
    requestOptions.body = JSON.stringify(options.body)
  }
  
  // Add query parameters for GET requests
  let finalUrl = fullUrl
  if (options.params && Object.keys(options.params).length > 0) {
    const searchParams = new URLSearchParams()
    Object.entries(options.params).forEach(([key, value]) => {
      if (value !== null && value !== undefined) {
        searchParams.append(key, String(value))
      }
    })
    finalUrl += (finalUrl.includes('?') ? '&' : '?') + searchParams.toString()
  }
  
  try {
    const response = await fetch(finalUrl, requestOptions)
    
    if (!response.ok) {
      const errorText = await response.text()
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`
      
      try {
        const errorData = JSON.parse(errorText)
        errorMessage = errorData.message || errorData.error || errorMessage
      } catch {
        errorMessage = errorText || errorMessage
      }
      
      throw new Error(errorMessage)
    }
    
    const contentType = response.headers.get('content-type')
    if (contentType && contentType.includes('application/json')) {
      const data = await response.json()
      return data.message || data
    }
    
    return await response.text()
  } catch (error) {
    console.error('Frappe request failed:', error)
    throw error
  }
}

// Convenience methods
export const frappeCall = {
  get: (url: string, params?: Record<string, any>, headers?: Record<string, string>) =>
    frappeRequest(url, { method: 'GET', params, headers }),
    
  post: (url: string, body?: any, headers?: Record<string, string>) =>
    frappeRequest(url, { method: 'POST', body, headers }),
    
  put: (url: string, body?: any, headers?: Record<string, string>) =>
    frappeRequest(url, { method: 'PUT', body, headers }),
    
  delete: (url: string, headers?: Record<string, string>) =>
    frappeRequest(url, { method: 'DELETE', headers }),
}

// Global type declaration for window.csrf_token
declare global {
  interface Window {
    csrf_token?: string
  }
}
