// File upload utilities for Frappe

export interface FileUploadOptions {
  file: File
  doctype?: string
  docname?: string
  fieldname?: string
  folder?: string
  isPrivate?: boolean
  onProgress?: (progress: number) => void
  onSuccess?: (response: any) => void
  onError?: (error: Error) => void
}

export interface UploadResponse {
  message: {
    doctype: string
    docname: string
    file_name: string
    file_url: string
    is_private: number
    file_size: number
  }
}

export class FileUploadHandler {
  private xhr: XMLHttpRequest | null = null
  
  constructor(private options: FileUploadOptions) {}
  
  async upload(): Promise<UploadResponse> {
    const { file, doctype, docname, fieldname, folder, isPrivate = false } = this.options
    
    return new Promise((resolve, reject) => {
      const formData = new FormData()
      formData.append('file', file)
      
      if (doctype) formData.append('doctype', doctype)
      if (docname) formData.append('docname', docname)
      if (fieldname) formData.append('fieldname', fieldname)
      if (folder) formData.append('folder', folder)
      formData.append('is_private', isPrivate ? '1' : '0')
      
      this.xhr = new XMLHttpRequest()
      
      // Track upload progress
      this.xhr.upload.addEventListener('progress', (e) => {
        if (e.lengthComputable && this.options.onProgress) {
          const progress = (e.loaded / e.total) * 100
          this.options.onProgress(progress)
        }
      })
      
      // Handle completion
      this.xhr.addEventListener('load', () => {
        if (this.xhr!.status >= 200 && this.xhr!.status < 300) {
          try {
            const response = JSON.parse(this.xhr!.responseText)
            if (this.options.onSuccess) {
              this.options.onSuccess(response)
            }
            resolve(response)
          } catch (error) {
            const parseError = new Error('Failed to parse response')
            if (this.options.onError) {
              this.options.onError(parseError)
            }
            reject(parseError)
          }
        } else {
          const error = new Error(`Upload failed: ${this.xhr!.statusText}`)
          if (this.options.onError) {
            this.options.onError(error)
          }
          reject(error)
        }
      })
      
      // Handle errors
      this.xhr.addEventListener('error', () => {
        const error = new Error('Upload failed')
        if (this.options.onError) {
          this.options.onError(error)
        }
        reject(error)
      })
      
      // Handle abort
      this.xhr.addEventListener('abort', () => {
        const error = new Error('Upload aborted')
        if (this.options.onError) {
          this.options.onError(error)
        }
        reject(error)
      })
      
      // Set headers
      this.xhr.open('POST', '/api/method/upload_file')
      
      // Add CSRF token if available
      if (typeof window !== 'undefined' && window.csrf_token) {
        this.xhr.setRequestHeader('X-Frappe-CSRF-Token', window.csrf_token)
      }
      
      // Start upload
      this.xhr.send(formData)
    })
  }
  
  abort(): void {
    if (this.xhr) {
      this.xhr.abort()
    }
  }
}

// Convenience function for simple file uploads
export async function uploadFile(options: FileUploadOptions): Promise<UploadResponse> {
  const handler = new FileUploadHandler(options)
  return handler.upload()
}

// React hook for file uploads
export function useFileUpload() {
  const [uploading, setUploading] = React.useState(false)
  const [progress, setProgress] = React.useState(0)
  const [error, setError] = React.useState<Error | null>(null)
  
  const upload = React.useCallback(async (options: FileUploadOptions) => {
    setUploading(true)
    setProgress(0)
    setError(null)
    
    try {
      const response = await uploadFile({
        ...options,
        onProgress: (progress) => {
          setProgress(progress)
          options.onProgress?.(progress)
        },
      })
      
      setUploading(false)
      return response
    } catch (err) {
      setError(err as Error)
      setUploading(false)
      throw err
    }
  }, [])
  
  return {
    upload,
    uploading,
    progress,
    error,
  }
}

export default FileUploadHandler

// Import React for the hook
import React from 'react'
