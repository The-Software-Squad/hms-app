interface FrappeConfig {
  baseUrl?: string
  siteName?: string
  socketPort?: number
  enableRealtime?: boolean
  [key: string]: any
}

let config: FrappeConfig = {}

export function setConfig(newConfig: Partial<FrappeConfig>) {
  config = { ...config, ...newConfig }
}

export function getConfig(): FrappeConfig {
  return config
}

export function getBaseUrl(): string {
  return config.baseUrl || ''
}

export function getSiteName(): string {
  return config.siteName || window.location.hostname
}
