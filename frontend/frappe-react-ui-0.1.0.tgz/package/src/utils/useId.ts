import { useId as reactUseId } from 'react'

// Re-export React's useId hook for compatibility
export const useId = reactUseId

// Generate a random ID (fallback for non-React contexts)
export function generateId(prefix: string = 'id'): string {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}`
}
