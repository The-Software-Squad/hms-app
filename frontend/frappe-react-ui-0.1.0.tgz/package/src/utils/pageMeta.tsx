import React, { useEffect } from 'react'

export interface PageMeta {
  title?: string
  description?: string
  image?: string
  keywords?: string
  author?: string
  robots?: string
  canonical?: string
  ogTitle?: string
  ogDescription?: string
  ogImage?: string
  ogUrl?: string
  twitterCard?: string
  twitterTitle?: string
  twitterDescription?: string
  twitterImage?: string
}

export function setPageMeta(meta: PageMeta) {
  if (typeof document === 'undefined') return

  // Set document title
  if (meta.title) {
    document.title = meta.title
  }

  // Helper function to set or update meta tag
  const setMetaTag = (name: string, content: string, property?: boolean) => {
    const attribute = property ? 'property' : 'name'
    let element = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement
    
    if (!element) {
      element = document.createElement('meta')
      element.setAttribute(attribute, name)
      document.head.appendChild(element)
    }
    
    element.setAttribute('content', content)
  }

  // Set meta tags
  if (meta.description) {
    setMetaTag('description', meta.description)
  }

  if (meta.keywords) {
    setMetaTag('keywords', meta.keywords)
  }

  if (meta.author) {
    setMetaTag('author', meta.author)
  }

  if (meta.robots) {
    setMetaTag('robots', meta.robots)
  }

  // Set Open Graph tags
  if (meta.ogTitle) {
    setMetaTag('og:title', meta.ogTitle, true)
  }

  if (meta.ogDescription) {
    setMetaTag('og:description', meta.ogDescription, true)
  }

  if (meta.ogImage) {
    setMetaTag('og:image', meta.ogImage, true)
  }

  if (meta.ogUrl) {
    setMetaTag('og:url', meta.ogUrl, true)
  }

  // Set Twitter Card tags
  if (meta.twitterCard) {
    setMetaTag('twitter:card', meta.twitterCard)
  }

  if (meta.twitterTitle) {
    setMetaTag('twitter:title', meta.twitterTitle)
  }

  if (meta.twitterDescription) {
    setMetaTag('twitter:description', meta.twitterDescription)
  }

  if (meta.twitterImage) {
    setMetaTag('twitter:image', meta.twitterImage)
  }

  // Set canonical URL
  if (meta.canonical) {
    let linkElement = document.querySelector('link[rel="canonical"]') as HTMLLinkElement
    
    if (!linkElement) {
      linkElement = document.createElement('link')
      linkElement.setAttribute('rel', 'canonical')
      document.head.appendChild(linkElement)
    }
    
    linkElement.setAttribute('href', meta.canonical)
  }
}

// React hook for managing page meta
export function usePageMeta(meta: PageMeta) {
  useEffect(() => {
    setPageMeta(meta)
  }, [meta])
}

// Higher-order component for page meta
export function withPageMeta<P extends object>(
  Component: React.ComponentType<P>,
  meta: PageMeta | ((props: P) => PageMeta)
): React.ComponentType<P> {
  const PageMetaWrapper: React.FC<P> = (props: P) => {
    const resolvedMeta = typeof meta === 'function' ? meta(props) : meta
    usePageMeta(resolvedMeta)
    return <Component {...props} />
  }
  
  PageMetaWrapper.displayName = `withPageMeta(${Component.displayName || Component.name})`
  
  return PageMetaWrapper
}
