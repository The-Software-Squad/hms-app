let confirmDialogInstance: any = null

export interface ConfirmDialogOptions {
  title?: string
  message: string
  primaryAction?: string
  secondaryAction?: string
  onConfirm?: () => void | Promise<void>
  onCancel?: () => void
}

export function setConfirmDialogInstance(instance: any) {
  confirmDialogInstance = instance
}

export function confirmDialog(options: ConfirmDialogOptions): Promise<boolean> {
  return new Promise((resolve) => {
    if (!confirmDialogInstance) {
      // Fallback to native confirm if no dialog instance is available
      const result = window.confirm(options.message)
      if (result && options.onConfirm) {
        Promise.resolve(options.onConfirm()).then(() => resolve(true))
      } else if (!result && options.onCancel) {
        options.onCancel()
        resolve(false)
      } else {
        resolve(result)
      }
      return
    }

    // Use the custom confirm dialog instance
    confirmDialogInstance.show({
      ...options,
      onConfirm: async () => {
        if (options.onConfirm) {
          await Promise.resolve(options.onConfirm())
        }
        resolve(true)
      },
      onCancel: () => {
        if (options.onCancel) {
          options.onCancel()
        }
        resolve(false)
      },
    })
  })
}

// React hook for confirm dialog
export function useConfirmDialog() {
  return {
    confirm: confirmDialog,
    setInstance: setConfirmDialogInstance,
  }
}
