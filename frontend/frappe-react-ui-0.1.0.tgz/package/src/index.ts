// Core components
export { Button } from './components/Button'
export { Input } from './components/Input'
export { Textarea } from './components/Textarea'
export { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/Select'
export { Checkbox } from './components/Checkbox'
export { Switch } from './components/Switch'
export { Card } from './components/Card'
export { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger, DialogClose } from './components/Dialog'
export { Popover, PopoverContent, PopoverTrigger } from './components/Popover'
export { Tooltip } from './components/Tooltip'
export { Badge } from './components/Badge'
export { Avatar, AvatarImage, AvatarFallback } from './components/Avatar'
export { Progress } from './components/Progress'
export { Spinner } from './components/Spinner'
export { LoadingIndicator } from './components/LoadingIndicator'
export { Alert, AlertTitle, AlertDescription } from './components/Alert'
export { Toast, ToastProvider, ToastViewport, toast } from './components/Toast'
export { Tabs, TabsList, TabsTrigger, TabsContent } from './components/Tabs'
export { Dropdown, DropdownContent, DropdownItem, DropdownTrigger } from './components/Dropdown'

// New components
export { Autocomplete } from './components/Autocomplete'
export { Breadcrumbs } from './components/Breadcrumbs'
export { Combobox } from './components/Combobox'
export { Divider } from './components/Divider'
export { Rating } from './components/Rating'
export { FileUploader } from './components/FileUploader'
export { ListView } from './components/ListView'
export { CommandPalette } from './components/CommandPalette'
export { TimePicker } from './components/TimePicker'
export { Sidebar, useMobileSidebar } from './components/Sidebar'

// Recently added missing components
export { TextInput } from './components/TextInput'
export { FormLabel } from './components/FormLabel'
export { FormControl } from './components/FormControl'
export { Provider } from './components/Provider'
export { ErrorMessage } from './components/ErrorMessage'
export { CircularProgressBar } from './components/CircularProgressBar'
export { Password } from './components/Password'
export { TabButtons } from './components/TabButtons'
export { ListFilter } from './components/ListFilter'
export { Tree } from './components/Tree'
export { FeatherIcon } from './components/FeatherIcon'
export { KeyboardShortcut } from './components/KeyboardShortcut'
export { Link } from './components/Link'
export { LoadingText } from './components/LoadingText'
export { ListItem } from './components/ListItem'
export { GreenCheckIcon } from './components/GreenCheckIcon'
export { ConfirmDialog } from './components/ConfirmDialog'
export { GridLayout } from './components/GridLayout'
export { Resource } from './components/Resource'
export { Dialogs, DialogsProvider, useDialogs } from './components/Dialogs'

// Advanced components
export { DatePicker } from './components/DatePicker'
export { TextEditor } from './components/TextEditor'

// Chart components
export { AxisChart } from './components/Charts/AxisChart'
export { DonutChart } from './components/Charts/DonutChart'
export { ECharts } from './components/Charts/ECharts'

// Data fetching hooks
export {
  useCall,
  useList,
  useDoc,
  useNewDoc,
  useDoctype,
  useFrappeFetch,
} from './data-fetching'

// Hooks
export { useVisibility } from './hooks/useVisibility'
export { useOutsideClick } from './hooks/useOutsideClick'
export { useImageNavigation } from './hooks/useImageNavigation'
export { useTouchHandler } from './hooks/useTouchHandler'
export { useZoomPan } from './hooks/useZoomPan'

// Utilities
export { cn } from './utils/cn'
export { debounce } from './utils/debounce'
export { dayjs } from './utils/dayjs'
export { call, createCall } from './utils/call'
export { frappeRequest, frappeCall } from './utils/frappeRequest'
export { setConfig, getConfig, getBaseUrl, getSiteName } from './utils/config'
export { initSocket, getSocket, disconnectSocket, useSocket } from './utils/socketio'
export { FileUploadHandler, uploadFile, useFileUpload } from './utils/fileUploadHandler'
export { setPageMeta, usePageMeta, withPageMeta } from './utils/pageMeta.tsx'
export { confirmDialog, setConfirmDialogInstance, useConfirmDialog } from './utils/confirmDialog'
export { parseMarkdown, markdownToText, extractMarkdownLinks } from './utils/markdown'
export { 
  isValidUrl, 
  isValidHttpUrl, 
  isValidEmail, 
  normalizeUrl, 
  getDomain, 
  isInternalUrl, 
  buildUrl, 
  parseUrl 
} from './utils/urlValidation'
export { default as fileToBase64 } from './utils/fileToBase64'
export { request } from './utils/request'
export { getThemeClasses, getSizeClasses, getColorValue, themes, variants, sizes } from './utils/theme'
export { useId, generateId } from './utils/useId'

// Legacy resources system (for backward compatibility)
export {
  createResource,
  createDocumentResource,
  createListResource,
  getCachedResource,
  getCachedDocumentResource,
  getCachedListResource,
} from './resources'

// Types
export type { ButtonProps } from './components/Button'
export type { InputProps } from './components/Input'
export type { TextareaProps } from './components/Textarea'
export type { SelectProps } from './components/Select'
export type { CheckboxProps } from './components/Checkbox'
export type { SwitchProps } from './components/Switch'
export type { CardProps } from './components/Card'
export type { DialogProps } from './components/Dialog'
export type { PopoverProps } from './components/Popover'
export type { TooltipProps } from './components/Tooltip'
export type { BadgeProps } from './components/Badge'
export type { AvatarProps } from './components/Avatar'
export type { ProgressProps } from './components/Progress'
export type { SpinnerProps } from './components/Spinner'
export type { LoadingIndicatorProps } from './components/LoadingIndicator'
export type { AlertProps } from './components/Alert'
export type { ToastProps } from './components/Toast'
export type { TabsProps } from './components/Tabs'
export type { DropdownProps } from './components/Dropdown'
export type { DatePickerProps } from './components/DatePicker'
export type { TextEditorProps } from './components/TextEditor'
export type { EChartsProps, AxisChartProps, DonutChartProps } from './components/Charts'

// New component types
export type { AutocompleteProps, AutocompleteOption } from './components/Autocomplete'
export type { BreadcrumbsProps, BreadcrumbItem } from './components/Breadcrumbs'
export type { ComboboxProps, ComboboxOption } from './components/Combobox'
export type { DividerProps } from './components/Divider'
export type { RatingProps } from './components/Rating'
export type { FileUploaderProps } from './components/FileUploader'
export type { ListViewProps, ListViewColumn, ListViewRow } from './components/ListView'
export type { CommandPaletteProps, CommandItem } from './components/CommandPalette'
export type { TimePickerProps } from './components/TimePicker'
export type { SidebarProps, SidebarItem } from './components/Sidebar'

// Recently added component types
export type { TextInputProps } from './components/TextInput'
export type { FormLabelProps } from './components/FormLabel'
export type { FormControlProps } from './components/FormControl'
export type { ProviderProps } from './components/Provider'
export type { ErrorMessageProps } from './components/ErrorMessage'
export type { CircularProgressBarProps } from './components/CircularProgressBar'
export type { PasswordProps } from './components/Password'
export type { TabButtonsProps, TabButton } from './components/TabButtons'
export type { ListFilterProps, FilterField, FilterCondition } from './components/ListFilter'
export type { TreeProps, TreeNode, TreeOptions } from './components/Tree'
export type { FeatherIconProps } from './components/FeatherIcon'
export type { KeyboardShortcutProps } from './components/KeyboardShortcut'
export type { LinkProps } from './components/Link'
export type { LoadingTextProps } from './components/LoadingText'
export type { ListItemProps } from './components/ListItem'
export type { GreenCheckIconProps } from './components/GreenCheckIcon'
export type { ConfirmDialogProps, ConfirmDialogRef } from './components/ConfirmDialog'
export type { GridLayoutProps, Layout, LayoutItem, LayoutItemRequired } from './components/GridLayout'
export type { ResourceProps, ResourceOptions } from './components/Resource'
export type { DialogsProps, DialogsProviderProps, DialogItem } from './components/Dialogs'

// Re-export commonly used types
export type { ComponentProps, ReactNode } from 'react'
