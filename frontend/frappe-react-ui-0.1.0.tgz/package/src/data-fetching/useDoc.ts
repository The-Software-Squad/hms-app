import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { useFrappeFetch } from './useFrappeFetch'

export interface UseDocOptions<TData = any> {
  doctype: string
  name: string
  fields?: string[]
  auto?: boolean
  cache?: boolean
  transform?: (data: TData) => TData
  onSuccess?: (data: TData) => void
  onError?: (error: Error) => void
}

export interface UseDocResult<TData = any> {
  doc: TData | null
  error: Error | null
  loading: boolean
  reload: () => void
  save: (data?: Partial<TData>) => Promise<TData>
  delete: () => Promise<void>
  setValue: (fieldname: string, value: any) => void
  getValue: (fieldname: string) => any
}

export function useDoc<TData = any>(
  options: UseDocOptions<TData>
): UseDocResult<TData> {
  const {
    doctype,
    name,
    fields,
    auto = true,
    cache = true,
    transform,
    onSuccess,
    onError,
  } = options

  const queryClient = useQueryClient()
  const { request } = useFrappeFetch()

  const queryKey = ['doc', doctype, name]

  // Fetch document
  const queryResult = useQuery({
    queryKey,
    queryFn: async () => {
      const params: any = {
        doctype,
        name,
      }

      if (fields) {
        params.fields = JSON.stringify(fields)
      }

      const response = await request<{ data: TData }>({
        url: '/api/method/frappe.desk.form.load.getdoc',
        method: 'GET',
        params,
      })

      // Extract the actual document data
      const rawData = response.data?.data || response.data
      let data = rawData
      
      if (transform) {
        const transformed = transform(data as TData)
        if (transformed !== undefined) {
          data = transformed as any
        }
      }

      if (onSuccess) {
        onSuccess(data as TData)
      }

      return data
    },
    enabled: auto && !!name,
    staleTime: cache ? 5 * 60 * 1000 : 0,
    retry: false,
  })

  // Save document
  const saveMutation = useMutation({
    mutationFn: async (data?: Partial<TData>) => {
      const doc = data || queryResult.data
      const response = await request<{ data: TData }>({
        url: '/api/method/frappe.desk.form.save.savedocs',
        method: 'POST',
        data: {
          doc: JSON.stringify(doc),
          action: 'Save',
        },
      })

      // Extract and update cache with unwrapped data
      const savedDoc = (response.data?.data || response.data) as TData
      queryClient.setQueryData(queryKey, savedDoc)
      
      return savedDoc
    },
    onError: (error: Error) => {
      if (onError) {
        onError(error)
      }
    },
  })

  // Delete document
  const deleteMutation = useMutation({
    mutationFn: async () => {
      await request({
        url: '/api/method/frappe.client.delete',
        method: 'POST',
        data: {
          doctype,
          name,
        },
      })

      // Remove from cache
      queryClient.removeQueries({ queryKey })
    },
    onError: (error: Error) => {
      if (onError) {
        onError(error)
      }
    },
  })

  const reload = () => {
    queryResult.refetch()
  }

  const save = async (data?: Partial<TData>): Promise<TData> => {
    return saveMutation.mutateAsync(data)
  }

  const deleteDoc = async (): Promise<void> => {
    return deleteMutation.mutateAsync()
  }

  const setValue = (fieldname: string, value: any) => {
    if (queryResult.data) {
      const updatedDoc = { ...queryResult.data, [fieldname]: value }
      queryClient.setQueryData(queryKey, updatedDoc)
    }
  }

  const getValue = (fieldname: string) => {
    return queryResult.data ? (queryResult.data as any)[fieldname] : null
  }

  return {
    doc: (queryResult.data as TData) || null,
    error: queryResult.error as Error | null,
    loading: queryResult.isLoading || saveMutation.isPending || deleteMutation.isPending,
    reload,
    save,
    delete: deleteDoc,
    setValue,
    getValue,
  }
}
