import { useQuery } from '@tanstack/react-query'
import { useFrappeFetch } from './useFrappeFetch'

export interface DoctypeField {
  fieldname: string
  fieldtype: string
  label: string
  reqd?: number
  hidden?: number
  read_only?: number
  options?: string
  default?: any
  description?: string
  depends_on?: string
  mandatory_depends_on?: string
  read_only_depends_on?: string
}

export interface DoctypeInfo {
  name: string
  module: string
  custom: number
  is_submittable: number
  is_child_table: number
  track_changes: number
  track_seen: number
  track_views: number
  allow_copy: number
  allow_rename: number
  allow_import: number
  allow_auto_repeat: number
  fields: DoctypeField[]
  permissions: any[]
  links: any[]
  actions: any[]
  states: any[]
}

export interface UseDoctypeOptions {
  doctype: string
  cache?: boolean
  onSuccess?: (data: DoctypeInfo) => void
  onError?: (error: Error) => void
}

export interface UseDoctypeResult {
  doctype: DoctypeInfo | null
  fields: DoctypeField[]
  loading: boolean
  error: Error | null
  reload: () => void
  getField: (fieldname: string) => DoctypeField | undefined
  isFieldRequired: (fieldname: string) => boolean
  isFieldHidden: (fieldname: string) => boolean
  isFieldReadOnly: (fieldname: string) => boolean
}

export function useDoctype(options: UseDoctypeOptions): UseDoctypeResult {
  const { doctype, cache = true, onSuccess, onError: _onError } = options
  const { request } = useFrappeFetch()

  const queryResult = useQuery({
    queryKey: ['doctype', doctype],
    queryFn: async () => {
      const response = await request<{ data: DoctypeInfo }>({
        url: '/api/method/frappe.desk.form.load.getdoctype',
        method: 'GET',
        params: {
          doctype,
          with_parent: 1,
        },
      })

      const doctypeInfo = (response.data?.data || response.data) as DoctypeInfo

      if (onSuccess) {
        onSuccess(doctypeInfo)
      }

      return doctypeInfo
    },
    enabled: !!doctype,
    staleTime: cache ? 10 * 60 * 1000 : 0, // 10 minutes if cache enabled
    retry: false,
  })

  const reload = () => {
    queryResult.refetch()
  }

  const getField = (fieldname: string): DoctypeField | undefined => {
    const doctype = queryResult.data as DoctypeInfo
    return doctype?.fields.find((field: any) => field.fieldname === fieldname)
  }

  const isFieldRequired = (fieldname: string): boolean => {
    const field = getField(fieldname)
    return field?.reqd === 1
  }

  const isFieldHidden = (fieldname: string): boolean => {
    const field = getField(fieldname)
    return field?.hidden === 1
  }

  const isFieldReadOnly = (fieldname: string): boolean => {
    const field = getField(fieldname)
    return field?.read_only === 1
  }

  const doctypeData = queryResult.data as DoctypeInfo
  return {
    doctype: doctypeData || null,
    fields: doctypeData?.fields || [],
    loading: queryResult.isLoading,
    error: queryResult.error as Error | null,
    reload,
    getField,
    isFieldRequired,
    isFieldHidden,
    isFieldReadOnly,
  }
}
