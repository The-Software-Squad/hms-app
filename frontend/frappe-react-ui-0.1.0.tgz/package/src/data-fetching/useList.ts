import { useQuery } from '@tanstack/react-query'
import { useFrappeFetch } from './useFrappeFetch'

export interface UseListOptions<TData = any> {
  doctype: string
  fields?: string[]
  filters?: Record<string, any>
  orderBy?: string
  limit?: number
  start?: number
  pageLength?: number
  cache?: boolean
  auto?: boolean
  transform?: (data: TData[]) => TData[]
  onSuccess?: (data: TData[]) => void
  onError?: (error: Error) => void
}

export interface UseListResult<TData = any> {
  data: TData[]
  error: Error | null
  loading: boolean
  hasNextPage: boolean
  hasPreviousPage: boolean
  reload: () => void
  loadMore: () => void
}

export function useList<TData = any>(
  options: UseListOptions<TData>
): UseListResult<TData> {
  const {
    doctype,
    fields = ['name'],
    filters = {},
    orderBy,
    limit = 20,
    start = 0,
    pageLength,
    cache = true,
    auto = true,
    transform,
    onSuccess,
    onError: _onError,
  } = options

  // const queryClient = useQueryClient() // Unused
  const { request } = useFrappeFetch()

  const queryKey = ['list', doctype, fields, filters, orderBy, limit, start]

  const queryResult = useQuery({
    queryKey,
    queryFn: async () => {
      const params = {
        doctype,
        fields: JSON.stringify(fields),
        filters: JSON.stringify(filters),
        order_by: orderBy,
        limit_start: start,
        limit_page_length: pageLength || limit,
      }

      const response = await request<{ data: TData[] }>({
        url: '/api/method/frappe.desk.reportview.get',
        method: 'GET',
        params,
      })

      let data = Array.isArray(response.data) ? response.data : response.data?.data || []
      
      if (transform) {
        const transformed = transform(data)
        if (transformed !== undefined) {
          data = transformed
        }
      }

      if (onSuccess) {
        onSuccess(data)
      }

      return { data }
    },
    enabled: auto,
    staleTime: cache ? 5 * 60 * 1000 : 0, // 5 minutes if cache enabled
    retry: false,
  })

  const reload = () => {
    queryResult.refetch()
  }

  const loadMore = () => {
    // Implementation for pagination/infinite loading
    // This would typically involve updating the start parameter
    // and merging results
  }

  const listData = Array.isArray(queryResult.data) 
    ? queryResult.data 
    : queryResult.data?.data || []

  return {
    data: listData,
    error: queryResult.error as Error | null,
    loading: queryResult.isLoading,
    hasNextPage: (listData.length || 0) >= limit,
    hasPreviousPage: start > 0,
    reload,
    loadMore,
  }
}
