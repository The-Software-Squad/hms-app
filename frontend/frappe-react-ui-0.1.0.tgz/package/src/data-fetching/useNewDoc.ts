import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useFrappeFetch } from './useFrappeFetch'

export interface UseNewDocOptions<TData = any> {
  doctype: string
  defaults?: Partial<TData>
  onSuccess?: (data: TData) => void
  onError?: (error: Error) => void
}

export interface UseNewDocResult<TData = any> {
  doc: TData
  loading: boolean
  error: Error | null
  save: () => Promise<TData>
  setValue: (fieldname: string, value: any) => void
  getValue: (fieldname: string) => any
  reset: () => void
}

export function useNewDoc<TData = any>(
  options: UseNewDocOptions<TData>
): UseNewDocResult<TData> {
  const { doctype, defaults = {}, onSuccess, onError } = options
  const queryClient = useQueryClient()
  const { request } = useFrappeFetch()

  const [doc, setDoc] = useState<TData>({
    doctype,
    __islocal: 1,
    __unsaved: 1,
    ...defaults,
  } as TData)

  const saveMutation = useMutation({
    mutationFn: async () => {
      const response = await request<{ data: TData }>({
        url: '/api/method/frappe.desk.form.save.savedocs',
        method: 'POST',
        data: {
          doc: JSON.stringify(doc),
          action: 'Save',
        },
      })

      // Update cache for the new document
      const savedDoc = (response.data?.data || response.data) as TData
      const docName = (savedDoc as any).name
      
      if (docName) {
        queryClient.setQueryData(['doc', doctype, docName], savedDoc)
        
        // Update list cache if it exists
        queryClient.invalidateQueries({
          queryKey: ['list', doctype],
        })
      }

      if (onSuccess) {
        onSuccess(savedDoc)
      }

      return savedDoc
    },
    onError: (error: Error) => {
      if (onError) {
        onError(error)
      }
    },
  })

  const setValue = (fieldname: string, value: any) => {
    setDoc(prev => ({
      ...prev,
      [fieldname]: value,
    }))
  }

  const getValue = (fieldname: string) => {
    return (doc as any)[fieldname]
  }

  const reset = () => {
    setDoc({
      doctype,
      __islocal: 1,
      __unsaved: 1,
      ...defaults,
    } as TData)
  }

  const save = async (): Promise<TData> => {
    return saveMutation.mutateAsync()
  }

  return {
    doc,
    loading: saveMutation.isPending,
    error: saveMutation.error as Error | null,
    save,
    setValue,
    getValue,
    reset,
  }
}
