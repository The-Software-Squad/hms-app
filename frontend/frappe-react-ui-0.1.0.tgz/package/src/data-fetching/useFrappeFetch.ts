import { useCallback } from 'react'

export interface FrappeRequestOptions {
  url: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  data?: any
  params?: any
  headers?: Record<string, string>
}

export interface FrappeResponse<T = any> {
  data: T
  message?: string
  debug?: any[]
  docs?: any[]
}

export class FrappeResponseError extends Error {
  title: string
  type: string
  exception?: string
  indicator?: string

  constructor(
    message: string,
    options: {
      title: string
      type: string
      exception?: string
      indicator?: string
    }
  ) {
    super(message)
    this.name = 'FrappeResponseError'
    this.title = options.title
    this.type = options.type
    this.exception = options.exception
    this.indicator = options.indicator

    if ((Error as any).captureStackTrace) {
      (Error as any).captureStackTrace(this, FrappeResponseError)
    }
  }
}

export function useFrappeFetch() {
  const setHeaders = useCallback((headers: HeadersInit = {}) => {
    const siteName = typeof window !== 'undefined' ? window.location.hostname : null
    const csrfToken = typeof window !== 'undefined' && (window as any).csrf_token !== '{{ csrf_token }}'
      ? (window as any).csrf_token
      : null

    const defaultHeaders: Record<string, string> = {
      Accept: 'application/json',
      'Content-Type': 'application/json; charset=utf-8',
    }

    if (siteName) {
      defaultHeaders['X-Frappe-Site-Name'] = siteName
    }
    if (csrfToken) {
      defaultHeaders['X-Frappe-CSRF-Token'] = csrfToken
    }

    return { ...headers, ...defaultHeaders }
  }, [])

  const request = useCallback(async <T = any>(
    options: FrappeRequestOptions
  ): Promise<FrappeResponse<T>> => {
    const { url, method = 'GET', data, params, headers = {} } = options

    let finalUrl = url
    const requestInit: RequestInit = {
      method,
      headers: setHeaders(headers),
    }

    // Handle GET params
    if (method === 'GET' && params) {
      const searchParams = new URLSearchParams()
      Object.entries(params).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          searchParams.append(key, String(value))
        }
      })
      finalUrl += `?${searchParams.toString()}`
    }

    // Handle request body
    if (data && method !== 'GET') {
      requestInit.body = JSON.stringify(data)
    }

    try {
      const response = await fetch(finalUrl, requestInit)
      const responseText = await response.text()
      
      if (!response.ok) {
        // Handle Frappe error response
        try {
          const errorResponse = JSON.parse(responseText)
          const errors = errorResponse.errors || []
          const error = errors[0]
          
          if (error) {
            const errorDescription = error.message
              ? `: ${error.message}`
              : error.exception
                ? ` (Traceback)`
                : ''
            
            throw new FrappeResponseError(
              `${error.type}${errorDescription}`,
              {
                title: error.title,
                type: error.type,
                exception: error.exception,
                indicator: error.indicator,
              }
            )
          }
        } catch (parseError) {
          if (parseError instanceof FrappeResponseError) {
            throw parseError
          }
        }
        
        throw new Error(`HTTP ${response.status}: ${response.statusText}`)
      }

      const responseData = JSON.parse(responseText)
      
      // Handle debug information
      if (responseData.debug) {
        const path = response.url.replace(window.location.origin, '')
        console.group(path)
        responseData.debug.forEach((d: any) => {
          console.log(d?.message)
        })
        console.groupEnd()
      }

      return responseData
    } catch (error) {
      if (error instanceof FrappeResponseError) {
        throw error
      }
      throw new Error(`Network error: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }, [setHeaders])

  return { request }
}
