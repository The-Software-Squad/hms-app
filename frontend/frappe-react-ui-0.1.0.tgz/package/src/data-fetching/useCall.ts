import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { request } from '../utils/request'

export interface UseCallOptions<TData = any, TParams = any> {
  url: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  params?: TParams
  immediate?: boolean
  refetch?: boolean
  baseUrl?: string
  initialData?: TData
  cacheKey?: string | string[]
  transform?: (data: TData) => TData
  onSuccess?: (data: TData) => void
  onError?: (error: Error) => void
  enabled?: boolean
}

export interface UseCallResult<TData = any, TParams = any> {
  data: TData | null
  error: Error | null
  loading: boolean
  isFetching: boolean
  isFinished: boolean
  execute: () => Promise<TData | null>
  submit: (params?: TParams) => Promise<TData | null>
  reset: () => void
}

export function useCall<TData = any, TParams = any>(
  options: UseCallOptions<TData, TParams>
): UseCallResult<TData, TParams> {
  const {
    url,
    method = 'GET',
    params,
    immediate = true,
    cacheKey,
    transform,
    onSuccess,
    onError,
    enabled = true,
  } = options

  const queryClient = useQueryClient()

  // Generate cache key
  const queryKey = cacheKey 
    ? Array.isArray(cacheKey) ? cacheKey : [cacheKey]
    : [url, method, params]

  // For GET requests, use useQuery
  const queryResult = useQuery({
    queryKey,
    queryFn: async () => {
      const response = await request(url, {
        method: method as any,
        body: method === 'GET' ? undefined : params as any,
        params: method === 'GET' ? params as any : undefined,
      })
      
      let data = response.data?.data || response.data
      if (transform) {
        const transformed = transform(data)
        if (transformed !== undefined) {
          data = transformed
        }
      }
      
      if (onSuccess) {
        onSuccess(data)
      }
      
      return data
    },
    enabled: enabled && immediate && method === 'GET',
    retry: false,
  })

  // For mutations (POST, PUT, DELETE), use useMutation
  const mutationResult = useMutation({
    mutationFn: async (submitParams?: TParams) => {
      const response = await request(url, {
        method: method as any,
        body: (submitParams || params) as any,
      })
      
      let data = response.data?.data || response.data
      if (transform) {
        const transformed = transform(data)
        if (transformed !== undefined) {
          data = transformed
        }
      }
      
      if (onSuccess) {
        onSuccess(data)
      }
      
      return data
    },
    onError: (error: Error) => {
      if (onError) {
        onError(error)
      }
    },
  })

  const isQuery = method === 'GET'
  const activeResult = isQuery ? queryResult : mutationResult

  const execute = async (): Promise<TData | null> => {
    if (isQuery) {
      const result = await queryResult.refetch()
      return result.data || null
    } else {
      const result = await mutationResult.mutateAsync(params)
      return result || null
    }
  }

  const submit = async (submitParams?: TParams): Promise<TData | null> => {
    if (isQuery) {
      // For GET requests, update params and refetch
      queryClient.setQueryData(queryKey, undefined)
      const result = await queryResult.refetch()
      return result.data || null
    } else {
      const result = await mutationResult.mutateAsync(submitParams || params)
      return result || null
    }
  }

  const reset = () => {
    if (isQuery) {
      queryClient.removeQueries({ queryKey })
    } else {
      mutationResult.reset()
    }
  }

  return {
    data: activeResult.data || null,
    error: activeResult.error as Error | null,
    loading: activeResult.isPending,
    isFetching: isQuery ? queryResult.isFetching : mutationResult.isPending,
    isFinished: !activeResult.isPending,
    execute,
    submit,
    reset,
  }
}
