import { useEffect, useRef, useState } from 'react'

export interface UseVisibilityOptions {
  threshold?: number | number[]
  root?: Element | null
  rootMargin?: string
  triggerOnce?: boolean
}

export function useVisibility<T extends Element = HTMLDivElement>(
  options: UseVisibilityOptions = {}
) {
  const [isVisible, setIsVisible] = useState(false)
  const [entry, setEntry] = useState<IntersectionObserverEntry | null>(null)
  const elementRef = useRef<T>(null)
  const observerRef = useRef<IntersectionObserver | null>(null)

  const { threshold = 0, root = null, rootMargin = '0px', triggerOnce = false } = options

  useEffect(() => {
    const element = elementRef.current
    if (!element) return

    const observer = new IntersectionObserver(
      (entries: IntersectionObserverEntry[]) => {
        const entry = entries[0]
        const visible = entry.isIntersecting && entry.intersectionRatio > 0
        
        setIsVisible(visible)
        setEntry(entry)

        // If triggerOnce is true and element is visible, disconnect observer
        if (triggerOnce && visible) {
          observer.disconnect()
        }
      },
      {
        threshold,
        root,
        rootMargin,
      }
    )

    observer.observe(element)
    observerRef.current = observer

    return () => {
      observer.disconnect()
    }
  }, [threshold, root, rootMargin, triggerOnce])

  return {
    ref: elementRef,
    isVisible,
    entry,
  }
}
