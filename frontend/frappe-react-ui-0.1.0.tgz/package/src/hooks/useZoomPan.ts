import { useState, useCallback, useRef } from 'react'

export interface ZoomPanState {
  scale: number
  x: number
  y: number
}

export interface ZoomPanOptions {
  minScale?: number
  maxScale?: number
  initialScale?: number
  step?: number
}

export function useZoomPan({
  minScale = 0.1,
  maxScale = 10,
  initialScale = 1,
  step = 0.1,
}: ZoomPanOptions = {}) {
  const [state, setState] = useState<ZoomPanState>({
    scale: initialScale,
    x: 0,
    y: 0,
  })
  
  const isDragging = useRef(false)
  const lastPosition = useRef({ x: 0, y: 0 })
  
  const zoomIn = useCallback((centerX?: number, centerY?: number) => {
    setState((prev) => {
      const newScale = Math.min(prev.scale + step, maxScale)
      
      if (centerX !== undefined && centerY !== undefined) {
        // Zoom towards the specified point
        const scaleFactor = newScale / prev.scale
        const newX = centerX - (centerX - prev.x) * scaleFactor
        const newY = centerY - (centerY - prev.y) * scaleFactor
        
        return {
          scale: newScale,
          x: newX,
          y: newY,
        }
      }
      
      return { ...prev, scale: newScale }
    })
  }, [step, maxScale])
  
  const zoomOut = useCallback((centerX?: number, centerY?: number) => {
    setState((prev) => {
      const newScale = Math.max(prev.scale - step, minScale)
      
      if (centerX !== undefined && centerY !== undefined) {
        // Zoom towards the specified point
        const scaleFactor = newScale / prev.scale
        const newX = centerX - (centerX - prev.x) * scaleFactor
        const newY = centerY - (centerY - prev.y) * scaleFactor
        
        return {
          scale: newScale,
          x: newX,
          y: newY,
        }
      }
      
      return { ...prev, scale: newScale }
    })
  }, [step, minScale])
  
  const setZoom = useCallback((scale: number, centerX?: number, centerY?: number) => {
    const clampedScale = Math.max(minScale, Math.min(maxScale, scale))
    
    setState((prev) => {
      if (centerX !== undefined && centerY !== undefined) {
        // Zoom towards the specified point
        const scaleFactor = clampedScale / prev.scale
        const newX = centerX - (centerX - prev.x) * scaleFactor
        const newY = centerY - (centerY - prev.y) * scaleFactor
        
        return {
          scale: clampedScale,
          x: newX,
          y: newY,
        }
      }
      
      return { ...prev, scale: clampedScale }
    })
  }, [minScale, maxScale])
  
  const pan = useCallback((deltaX: number, deltaY: number) => {
    setState((prev) => ({
      ...prev,
      x: prev.x + deltaX,
      y: prev.y + deltaY,
    }))
  }, [])
  
  const reset = useCallback(() => {
    setState({
      scale: initialScale,
      x: 0,
      y: 0,
    })
  }, [initialScale])
  
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    isDragging.current = true
    lastPosition.current = { x: e.clientX, y: e.clientY }
  }, [])
  
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDragging.current) return
    
    const deltaX = e.clientX - lastPosition.current.x
    const deltaY = e.clientY - lastPosition.current.y
    
    pan(deltaX, deltaY)
    
    lastPosition.current = { x: e.clientX, y: e.clientY }
  }, [pan])
  
  const handleMouseUp = useCallback(() => {
    isDragging.current = false
  }, [])
  
  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault()
    
    const rect = e.currentTarget.getBoundingClientRect()
    const centerX = e.clientX - rect.left
    const centerY = e.clientY - rect.top
    
    if (e.deltaY < 0) {
      zoomIn(centerX, centerY)
    } else {
      zoomOut(centerX, centerY)
    }
  }, [zoomIn, zoomOut])
  
  const getTransform = useCallback(() => {
    return `translate(${state.x}px, ${state.y}px) scale(${state.scale})`
  }, [state])
  
  const getTransformStyle = useCallback(() => {
    return {
      transform: getTransform(),
      transformOrigin: '0 0',
    }
  }, [getTransform])
  
  return {
    ...state,
    zoomIn,
    zoomOut,
    setZoom,
    pan,
    reset,
    getTransform,
    getTransformStyle,
    handlers: {
      onMouseDown: handleMouseDown,
      onMouseMove: handleMouseMove,
      onMouseUp: handleMouseUp,
      onWheel: handleWheel,
    },
  }
}
