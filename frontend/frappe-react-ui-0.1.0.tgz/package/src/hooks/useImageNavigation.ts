import { useState, useCallback } from 'react'

export interface ImageNavigationOptions {
  images: string[]
  initialIndex?: number
  loop?: boolean
}

export function useImageNavigation({
  images,
  initialIndex = 0,
  loop = true,
}: ImageNavigationOptions) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex)
  
  const goToNext = useCallback(() => {
    setCurrentIndex((prevIndex) => {
      if (prevIndex >= images.length - 1) {
        return loop ? 0 : prevIndex
      }
      return prevIndex + 1
    })
  }, [images.length, loop])
  
  const goToPrevious = useCallback(() => {
    setCurrentIndex((prevIndex) => {
      if (prevIndex <= 0) {
        return loop ? images.length - 1 : prevIndex
      }
      return prevIndex - 1
    })
  }, [images.length, loop])
  
  const goToIndex = useCallback((index: number) => {
    if (index >= 0 && index < images.length) {
      setCurrentIndex(index)
    }
  }, [images.length])
  
  const currentImage = images[currentIndex]
  const hasNext = loop || currentIndex < images.length - 1
  const hasPrevious = loop || currentIndex > 0
  
  return {
    currentIndex,
    currentImage,
    hasNext,
    hasPrevious,
    goToNext,
    goToPrevious,
    goToIndex,
    totalImages: images.length,
  }
}
