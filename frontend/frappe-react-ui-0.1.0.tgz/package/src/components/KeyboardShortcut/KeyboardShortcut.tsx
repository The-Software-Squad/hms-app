import React, { useMemo } from 'react'
import { 
  Command, 
  ArrowBigUp, 
  Option, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight, 
  CornerDownLeft, 
  Delete 
} from 'lucide-react'
import { cn } from '../../utils/cn'

export interface KeyboardShortcutProps {
  meta?: boolean
  ctrl?: boolean
  shift?: boolean
  alt?: boolean
  shortcut?: string
  bg?: boolean
  combo?: string
  showPlus?: boolean
  altCombos?: string[]
  useIcons?: boolean
  className?: string
  children?: React.ReactNode
}

interface Part {
  raw: string
  type: string
  display: string
}

const KeyboardShortcut: React.FC<KeyboardShortcutProps> = ({
  meta,
  ctrl,
  shift,
  alt,
  // shortcut, // Future feature
  bg = false,
  combo,
  showPlus = true,
  altCombos = [],
  useIcons = true,
  className,
  children,
}) => {
  const isMac = useMemo(() => {
    if (typeof navigator === 'undefined') return false
    const platform = (navigator as any).userAgentData?.platform || navigator.platform || ''
    if (/Mac|iPod|iPhone|iPad/i.test(platform)) return true
    return /Mac OS X|Macintosh|iPhone|iPad|iPod/i.test(navigator.userAgent)
  }, [])

  const parseCombo = (raw?: string): Part[] => {
    if (!raw) return []
    
    const aliasMap: Record<string, string> = {
      mod: isMac ? 'cmd' : 'ctrl',
      command: 'cmd',
      cmd: 'cmd',
      '⌘': 'cmd',
      control: 'ctrl',
      ctrl: 'ctrl',
      option: 'alt',
      opt: 'alt',
      alt: 'alt',
      '⌥': 'alt',
      shift: 'shift',
      '⇧': 'shift',
      meta: isMac ? 'cmd' : 'win',
      win: 'win',
      windows: 'win',
    }

    const keyMap: Record<string, string> = {
      esc: 'Esc',
      escape: 'Esc',
      enter: '↵',
      return: '↵',
      space: 'Space',
      ' ': 'Space',
      tab: 'Tab',
      backspace: '⌫',
      delete: '⌦',
      del: '⌦',
      up: '↑',
      arrowup: '↑',
      down: '↓',
      arrowdown: '↓',
      left: '←',
      arrowleft: '←',
      right: '→',
      arrowright: '→',
      pageup: 'PgUp',
      pagedown: 'PgDn',
      home: 'Home',
      end: 'End',
    }

    return raw
      .split('+')
      .map(p => p.trim())
      .filter(Boolean)
      .map(original => {
        const lower = original.toLowerCase()
        const type = aliasMap[lower] || 'key'
        let display = original
        
        if (type !== 'key') {
          if (type === 'cmd') display = '⌘'
          else if (type === 'shift') display = '⇧'
          else if (type === 'alt') display = '⌥'
          else if (type === 'ctrl') display = 'Ctrl'
          else if (type === 'win') display = 'Win'
        } else {
          if (keyMap[lower]) display = keyMap[lower]
          else if (/^[a-z]$/.test(lower)) display = lower.toUpperCase()
          else if (/^f\d{1,2}$/i.test(original)) display = original.toUpperCase()
        }
        
        return { raw: original, type, display }
      })
  }

  const parsedParts = useMemo(() => parseCombo(combo), [combo, isMac])

  const keyIconMap: Record<string, React.ComponentType<any>> = {
    '↑': ArrowUp,
    '↓': ArrowDown,
    '←': ArrowLeft,
    '→': ArrowRight,
    '↵': CornerDownLeft,
    '⌫': Delete,
  }

  const iconFor = (part: Part) => {
    if (!useIcons) return null
    if (['cmd', 'shift', 'alt'].includes(part.type)) return null
    return keyIconMap[part.display] || null
  }

  const ariaLabel = useMemo(() => {
    if (!parsedParts.length) return undefined
    const wordMap: Record<string, string> = {
      '⌘': 'Command',
      '⇧': 'Shift',
      '⌥': 'Option',
      'Ctrl': 'Control',
      'Win': 'Windows',
      '↵': 'Enter',
      '⌫': 'Backspace',
      '⌦': 'Delete',
      '↑': 'Up Arrow',
      '↓': 'Down Arrow',
      '←': 'Left Arrow',
      '→': 'Right Arrow',
    }
    const seq = parsedParts
      .map(p => wordMap[p.display] || p.display)
      .join(' + ')
    return 'Shortcut ' + seq
  }, [parsedParts])

  const rootClasses = cn(
    'inline-flex items-center gap-0.5 text-sm',
    bg ? 'bg-surface-gray-2 rounded-sm text-ink-gray-5 py-0.5 px-1' : 'text-ink-gray-4',
    className
  )

  return (
    <>
      <div
        className={rootClasses}
        aria-label={ariaLabel}
        role="note"
      >
        {/* Primary combo rendering */}
        {parsedParts.length > 0 ? (
          parsedParts.map((part, idx) => (
            <React.Fragment key={`${idx}-${part.raw}`}>
              {/* Explicit modifier icons */}
              {part.type === 'cmd' && (
                <Command className="w-3 h-3" aria-label="Command" />
              )}
              {part.type === 'shift' && (
                <ArrowBigUp className="w-3 h-3" aria-label="Shift" />
              )}
              {part.type === 'alt' && (
                <Option className="w-3 h-3" aria-label="Option" />
              )}
              
              {/* Non-modifier key */}
              {!['cmd', 'shift', 'alt'].includes(part.type) && (
                <>
                  {(() => {
                    const IconComponent = iconFor(part)
                    return IconComponent ? (
                      <IconComponent className="w-3 h-3" aria-label={part.display} />
                    ) : (
                      <span className="font-mono leading-none tracking-wide uppercase text-[10px]">
                        {part.display}
                      </span>
                    )
                  })()}
                </>
              )}
              
              {/* + separator */}
              {idx < parsedParts.length - 1 && showPlus && (
                <span
                  className="font-mono text-[10px] leading-none opacity-60"
                  aria-hidden="true"
                >
                  +
                </span>
              )}
            </React.Fragment>
          ))
        ) : (
          /* Backward compatibility path */
          <>
            {(ctrl || meta) && (
              <>
                {isMac ? (
                  <Command className="w-3 h-3" aria-label="Command" />
                ) : (
                  <span className="font-mono text-[10px] leading-none">Ctrl</span>
                )}
              </>
            )}
            {shift && <ArrowBigUp className="w-3 h-3" aria-label="Shift" />}
            {alt && <Option className="w-3 h-3" aria-label="Option" />}
            {children}
          </>
        )}
      </div>
      
      {/* Alternative combos */}
      {altCombos && altCombos.length > 0 && (
        <span className="inline-flex items-center gap-1 ml-1">
          {altCombos.map((alt, i) => (
            <div
              key={`alt-${i}-${alt}`}
              className="inline-flex items-center gap-0.5 text-sm bg-surface-gray-2 rounded-sm text-ink-gray-5 py-0.5 px-1"
              aria-label={`Alternative shortcut ${alt}`}
            >
              <KeyboardShortcut combo={alt} showPlus={showPlus} />
            </div>
          ))}
        </span>
      )}
    </>
  )
}

export { KeyboardShortcut }
