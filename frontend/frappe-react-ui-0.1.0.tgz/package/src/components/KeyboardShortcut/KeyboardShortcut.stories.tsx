import type { Meta, StoryObj } from '@storybook/react'
import { KeyboardShortcut } from './KeyboardShortcut'

const meta: Meta<typeof KeyboardShortcut> = {
  title: 'Components/KeyboardShortcut',
  component: KeyboardShortcut,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    combo: 'Mod+K',
  },
}

export const WithBackground: Story = {
  args: {
    combo: 'Mod+Shift+P',
    bg: true,
  },
}

export const ArrowKeys: Story = {
  args: {
    combo: 'Shift+Up',
    bg: true,
  },
}

export const FunctionKeys: Story = {
  args: {
    combo: 'F12',
    bg: true,
  },
}

export const ComplexCombo: Story = {
  args: {
    combo: 'Mod+Shift+Alt+Delete',
    bg: true,
  },
}

export const WithAlternatives: Story = {
  args: {
    combo: 'Mod+K',
    altCombos: ['Ctrl+K', 'F3'],
    bg: true,
  },
}

export const CommonShortcuts: Story = {
  render: () => (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <span>Copy:</span>
        <KeyboardShortcut combo="Mod+C" bg />
      </div>
      <div className="flex items-center gap-2">
        <span>Paste:</span>
        <KeyboardShortcut combo="Mod+V" bg />
      </div>
      <div className="flex items-center gap-2">
        <span>Undo:</span>
        <KeyboardShortcut combo="Mod+Z" bg />
      </div>
      <div className="flex items-center gap-2">
        <span>Redo:</span>
        <KeyboardShortcut combo="Mod+Shift+Z" bg />
      </div>
      <div className="flex items-center gap-2">
        <span>Save:</span>
        <KeyboardShortcut combo="Mod+S" bg />
      </div>
      <div className="flex items-center gap-2">
        <span>Find:</span>
        <KeyboardShortcut combo="Mod+F" bg />
      </div>
    </div>
  ),
}

export const LegacyProps: Story = {
  render: () => (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <span>Legacy Ctrl+C:</span>
        <KeyboardShortcut ctrl bg>C</KeyboardShortcut>
      </div>
      <div className="flex items-center gap-2">
        <span>Legacy Meta+Shift+P:</span>
        <KeyboardShortcut meta shift bg>P</KeyboardShortcut>
      </div>
    </div>
  ),
}
