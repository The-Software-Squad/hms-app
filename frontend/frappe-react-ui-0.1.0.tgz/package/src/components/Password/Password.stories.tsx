import type { Meta, StoryObj } from '@storybook/react'
import { Password } from './Password'

const meta: Meta<typeof Password> = {
  title: 'Components/Password',
  component: Password,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    label: 'Password',
    placeholder: 'Enter your password',
  },
}

export const WithValue: Story = {
  args: {
    label: 'Password',
    value: 'mypassword123',
  },
}

export const Required: Story = {
  args: {
    label: 'Password',
    placeholder: 'Enter your password',
    required: true,
    description: 'Password must be at least 8 characters long',
  },
}

export const MaskedPassword: Story = {
  args: {
    label: 'Masked Password',
    value: '********',
    description: 'This password is masked and cannot be revealed',
  },
}

export const WithoutEye: Story = {
  args: {
    label: 'Password',
    placeholder: 'Enter your password',
    showEye: false,
  },
}
