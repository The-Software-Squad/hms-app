import React, { useState, useCallback } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { FormControl, FormControlProps } from '../FormControl'
import { Tooltip } from '../Tooltip'

export interface PasswordProps extends Omit<FormControlProps, 'type' | 'suffix'> {
  value?: string
  showEye?: boolean
}

const Password: React.FC<PasswordProps> = ({
  value,
  showEye = true,
  ...props
}) => {
  const [show, setShow] = useState(false)

  const toggleShow = useCallback(() => {
    setShow(prev => !prev)
  }, [])

  // Handle keyboard shortcut (Cmd/Ctrl + I)
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'i') {
      e.preventDefault()
      toggleShow()
    }
  }, [toggleShow])

  // Don't show eye icon if value contains asterisks (masked password)
  const shouldShowEye = showEye && !value?.includes('*')

  const suffix = shouldShowEye ? (
    <Tooltip
      content={
        <div className="rounded bg-surface-gray-7 py-1.5 px-2 text-xs text-ink-white shadow-xl">
          <span className="flex items-center gap-1">
            {show ? 'Hide Password' : 'Show Password'}
            <kbd className="bg-surface-gray-5 text-ink-gray-2 px-1 rounded text-xs">
              ⌘I
            </kbd>
          </span>
        </div>
      }
    >
      <div className="cursor-pointer mr-1" onClick={toggleShow}>
        {show ? (
          <EyeOff size={12} />
        ) : (
          <Eye size={12} />
        )}
      </div>
    </Tooltip>
  ) : undefined

  return (
    <FormControl
      {...props}
      type={show ? 'text' : 'password'}
      value={value}
      suffix={suffix}
      onKeyDown={handleKeyDown}
    />
  )
}

export { Password }
