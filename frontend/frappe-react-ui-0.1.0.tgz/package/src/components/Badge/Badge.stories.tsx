import type { Meta, StoryObj } from '@storybook/react'
import { Badge } from './Badge'

const meta: Meta<typeof Badge> = {
  title: 'Components/Badge',
  component: Badge,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'secondary', 'destructive', 'outline'],
    },
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
    },
    theme: {
      control: 'select',
      options: ['gray', 'blue', 'green', 'red', 'yellow'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    children: 'Badge',
  },
}

export const Primary: Story = {
  args: {
    variant: 'default',
    theme: 'blue',
    children: 'Primary',
  },
}

export const Success: Story = {
  args: {
    variant: 'default',
    theme: 'green',
    children: 'Success',
  },
}

export const Warning: Story = {
  args: {
    variant: 'default',
    theme: 'yellow',
    children: 'Warning',
  },
}

export const Destructive: Story = {
  args: {
    variant: 'destructive',
    children: 'Error',
  },
}

export const Secondary: Story = {
  args: {
    variant: 'secondary',
    theme: 'blue',
    children: 'Secondary',
  },
}

export const Outline: Story = {
  args: {
    variant: 'outline',
    theme: 'green',
    children: 'Outline',
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <Badge size="sm">Small</Badge>
      <Badge size="md">Medium</Badge>
      <Badge size="lg">Large</Badge>
    </div>
  ),
}

export const Themes: Story = {
  render: () => (
    <div className="flex flex-wrap gap-2">
      <Badge theme="gray">Gray</Badge>
      <Badge theme="blue">Blue</Badge>
      <Badge theme="green">Green</Badge>
      <Badge theme="red">Red</Badge>
      <Badge theme="yellow">Yellow</Badge>
    </div>
  ),
}
