import React from 'react'
import { cn } from '../../utils/cn'

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'secondary' | 'destructive' | 'outline'
  size?: 'sm' | 'md' | 'lg'
  theme?: 'gray' | 'blue' | 'green' | 'red' | 'yellow'
}

const Badge: React.FC<BadgeProps> = ({
  className,
  variant = 'default',
  size = 'sm',
  theme = 'gray',
  children,
  ...props
}) => {
  return (
    <div
      className={cn(
        'inline-flex items-center rounded-full border font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-outline-gray-3 focus:ring-offset-2',
        {
          // Size variants
          'px-2 py-0.5 text-xs': size === 'sm',
          'px-2.5 py-1 text-sm': size === 'md',
          'px-3 py-1.5 text-base': size === 'lg',
        },
        {
          // Theme and variant combinations
          'border-transparent bg-surface-gray-7 text-ink-white': variant === 'default' && theme === 'gray',
          'border-transparent bg-blue-500 text-ink-white': variant === 'default' && theme === 'blue',
          'border-transparent bg-green-500 text-ink-white': variant === 'default' && theme === 'green',
          'border-transparent bg-red-500 text-ink-white': variant === 'default' && theme === 'red',
          'border-transparent bg-yellow-500 text-ink-white': variant === 'default' && theme === 'yellow',
          
          'border-transparent bg-surface-gray-2 text-ink-gray-8': variant === 'secondary' && theme === 'gray',
          'border-transparent bg-surface-blue-2 text-ink-blue-3': variant === 'secondary' && theme === 'blue',
          'border-transparent bg-surface-green-2 text-green-800': variant === 'secondary' && theme === 'green',
          'border-transparent bg-surface-red-2 text-red-700': variant === 'secondary' && theme === 'red',
          'border-transparent bg-yellow-100 text-yellow-800': variant === 'secondary' && theme === 'yellow',
          
          'border-transparent bg-red-600 text-ink-white': variant === 'destructive',
          
          'text-ink-gray-8 border-outline-gray-2': variant === 'outline' && theme === 'gray',
          'text-ink-blue-3 border-outline-blue-1': variant === 'outline' && theme === 'blue',
          'text-green-800 border-outline-green-2': variant === 'outline' && theme === 'green',
          'text-red-700 border-outline-red-1': variant === 'outline' && theme === 'red',
          'text-yellow-800 border-yellow-300': variant === 'outline' && theme === 'yellow',
        },
        className
      )}
      {...props}
    >
      {children}
    </div>
  )
}

Badge.displayName = 'Badge'

export { Badge }
