import React, { ReactNode } from 'react'
import { ToastProvider } from '../Toast'

export interface ProviderProps {
  children: ReactNode
}

const Provider: React.FC<ProviderProps> = ({ children }) => {
  return (
    <ToastProvider>
      {children}
    </ToastProvider>
  )
}

export { Provider }
