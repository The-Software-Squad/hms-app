import type { Meta, StoryObj } from '@storybook/react'
import { AxisChart, DonutChart, ECharts } from './index'

const meta: Meta<typeof AxisChart> = {
  title: 'Components/Charts',
  component: AxisChart,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

const sampleLineData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      name: 'Sales',
      values: [120, 190, 300, 500, 200, 300],
      color: '#3b82f6',
      type: 'line' as const,
    },
    {
      name: 'Revenue',
      values: [220, 290, 400, 600, 300, 400],
      color: '#10b981',
      type: 'line' as const,
    },
  ],
}

const sampleBarData = {
  labels: ['Q1', 'Q2', 'Q3', 'Q4'],
  datasets: [
    {
      name: 'Product A',
      values: [40, 60, 80, 90],
      color: '#3b82f6',
      type: 'bar' as const,
    },
    {
      name: 'Product B',
      values: [30, 50, 70, 85],
      color: '#10b981',
      type: 'bar' as const,
    },
  ],
}

const sampleDonutData = [
  { name: 'Desktop', value: 45, color: '#3b82f6' },
  { name: 'Mobile', value: 35, color: '#10b981' },
  { name: 'Tablet', value: 20, color: '#f59e0b' },
]

export const LineChart: Story = {
  render: () => (
    <div className="w-[600px] h-[400px]">
      <AxisChart
        data={sampleLineData}
        title="Sales vs Revenue"
        axisOptions={{
          xAxisName: 'Month',
          yAxisName: 'Amount ($)',
          formatTooltipY: (value) => `$${value}`,
        }}
      />
    </div>
  ),
}

export const BarChart: Story = {
  render: () => (
    <div className="w-[600px] h-[400px]">
      <AxisChart
        data={sampleBarData}
        title="Quarterly Performance"
        axisOptions={{
          xAxisName: 'Quarter',
          yAxisName: 'Units Sold',
        }}
      />
    </div>
  ),
}

export const DonutChartStory: Story = {
  render: () => (
    <div className="w-[400px] h-[400px]">
      <DonutChart
        data={sampleDonutData}
        title="Device Usage"
        centerText={{
          title: '100%',
          subtitle: 'Total Usage',
        }}
      />
    </div>
  ),
}

export const DonutWithoutLegend: Story = {
  render: () => (
    <div className="w-[400px] h-[400px]">
      <DonutChart
        data={sampleDonutData}
        title="Simple Donut"
        showLegend={false}
      />
    </div>
  ),
}

export const LoadingChart: Story = {
  render: () => (
    <div className="w-[600px] h-[400px]">
      <AxisChart
        data={sampleLineData}
        title="Loading Chart"
        loading={true}
      />
    </div>
  ),
}

export const CustomEChart: Story = {
  render: () => {
    const option = {
      title: {
        text: 'Custom EChart',
        left: 'center',
      },
      tooltip: {
        trigger: 'item',
      },
      series: [
        {
          name: 'Sample Data',
          type: 'pie',
          radius: '50%',
          data: [
            { value: 1048, name: 'Search Engine' },
            { value: 735, name: 'Direct' },
            { value: 580, name: 'Email' },
            { value: 484, name: 'Union Ads' },
            { value: 300, name: 'Video Ads' },
          ],
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 0, 0, 0.5)',
            },
          },
        },
      ],
    }

    return (
      <div className="w-[500px] h-[400px]">
        <ECharts option={option} />
      </div>
    )
  },
}
