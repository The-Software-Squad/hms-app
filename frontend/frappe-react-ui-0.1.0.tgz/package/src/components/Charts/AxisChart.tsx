import React from 'react'
import { ECharts } from './ECharts'
import type { EChartsOption } from 'echarts'

export interface AxisChartProps {
  data: {
    labels: string[]
    datasets: Array<{
      name: string
      values: number[]
      color?: string
      type?: 'line' | 'bar'
    }>
  }
  title?: string
  height?: number | string
  width?: number | string
  className?: string
  loading?: boolean
  colors?: string[]
  axisOptions?: {
    xAxisName?: string
    yAxisName?: string
    formatTooltipX?: (value: any) => string
    formatTooltipY?: (value: any) => string
  }
}

export const AxisChart: React.FC<AxisChartProps> = ({
  data,
  title,
  height = 400,
  width = '100%',
  className,
  loading = false,
  colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'],
  axisOptions = {},
}) => {
  const option: EChartsOption = {
    title: title ? {
      text: title,
      textStyle: {
        fontSize: 16,
        fontWeight: 'normal',
        color: '#374151',
      },
    } : undefined,
    tooltip: {
      trigger: 'axis',
      axisPointer: {
        type: 'cross',
        label: {
          backgroundColor: '#6a7985',
        },
      },
      formatter: (params: any) => {
        if (!Array.isArray(params)) params = [params]
        
        let tooltip = `<div class="font-medium">${params[0].axisValueLabel}</div>`
        
        params.forEach((param: any, _index: number) => {
          const value = axisOptions.formatTooltipY 
            ? axisOptions.formatTooltipY(param.value)
            : param.value
          
          tooltip += `
            <div class="flex items-center gap-2 mt-1">
              <div class="w-3 h-3 rounded-full" style="background-color: ${param.color}"></div>
              <span class="text-sm">${param.seriesName}: ${value}</span>
            </div>
          `
        })
        
        return tooltip
      },
    },
    legend: {
      data: data.datasets.map(d => d.name),
      bottom: 0,
      textStyle: {
        color: '#6b7280',
      },
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      boundaryGap: false,
      data: data.labels,
      name: axisOptions.xAxisName,
      nameLocation: 'middle',
      nameGap: 30,
      axisLine: {
        lineStyle: {
          color: '#e5e7eb',
        },
      },
      axisLabel: {
        color: '#6b7280',
        formatter: axisOptions.formatTooltipX,
      },
    },
    yAxis: {
      type: 'value',
      name: axisOptions.yAxisName,
      nameLocation: 'middle',
      nameGap: 50,
      axisLine: {
        lineStyle: {
          color: '#e5e7eb',
        },
      },
      axisLabel: {
        color: '#6b7280',
        formatter: axisOptions.formatTooltipY,
      },
      splitLine: {
        lineStyle: {
          color: '#f3f4f6',
        },
      },
    },
    series: data.datasets.map((dataset, index) => ({
      name: dataset.name,
      type: dataset.type || 'line',
      data: dataset.values,
      smooth: dataset.type === 'line',
      itemStyle: {
        color: dataset.color || colors[index % colors.length],
      },
      lineStyle: dataset.type === 'line' ? {
        width: 2,
      } : undefined,
      areaStyle: dataset.type === 'line' ? {
        opacity: 0.1,
      } : undefined,
    })),
  }

  return (
    <ECharts
      option={option}
      width={width}
      height={height}
      className={className}
      loading={loading}
    />
  )
}
