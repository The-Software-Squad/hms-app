import React from 'react'
import { ECharts } from './ECharts'
import type { EChartsOption } from 'echarts'

export interface DonutChartProps {
  data: Array<{
    name: string
    value: number
    color?: string
  }>
  title?: string
  height?: number | string
  width?: number | string
  className?: string
  loading?: boolean
  colors?: string[]
  innerRadius?: string
  outerRadius?: string
  showLegend?: boolean
  centerText?: {
    title?: string
    subtitle?: string
  }
}

export const DonutChart: React.FC<DonutChartProps> = ({
  data,
  title,
  height = 400,
  width = '100%',
  className,
  loading = false,
  colors = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#84cc16'],
  innerRadius = '50%',
  outerRadius = '80%',
  showLegend = true,
  centerText,
}) => {
  const total = data.reduce((sum, item) => sum + item.value, 0)

  const option: EChartsOption = {
    title: title ? {
      text: title,
      left: 'center',
      top: 20,
      textStyle: {
        fontSize: 16,
        fontWeight: 'normal',
        color: '#374151',
      },
    } : undefined,
    tooltip: {
      trigger: 'item',
      formatter: (params: any) => {
        const percentage = ((params.value / total) * 100).toFixed(1)
        return `
          <div class="font-medium">${params.name}</div>
          <div class="text-sm text-gray-600 mt-1">
            Value: ${params.value}<br/>
            Percentage: ${percentage}%
          </div>
        `
      },
    },
    legend: showLegend ? {
      orient: 'vertical',
      left: 'left',
      top: 'middle',
      textStyle: {
        color: '#6b7280',
      },
      formatter: (name: string) => {
        const item = data.find(d => d.name === name)
        const percentage = item ? ((item.value / total) * 100).toFixed(1) : '0'
        return `${name} (${percentage}%)`
      },
    } : undefined,
    graphic: centerText ? {
      type: 'group',
      left: 'center',
      top: 'middle',
      children: [
        {
          type: 'text',
          style: {
            text: centerText.title || total.toString(),
            fill: '#374151',
            fontSize: 24,
            fontWeight: 'bold',
          } as any,
        },
        {
          type: 'text',
          style: {
            text: centerText.subtitle || 'Total',
            fill: '#6b7280',
            fontSize: 14,
          } as any,
          top: 30,
        },
      ],
    } : undefined,
    series: [
      {
        name: 'Data',
        type: 'pie',
        radius: [innerRadius, outerRadius],
        center: ['50%', '50%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 4,
          borderColor: '#fff',
          borderWidth: 2,
        },
        label: {
          show: false,
        },
        emphasis: {
          label: {
            show: true,
            fontSize: 14,
            fontWeight: 'bold',
          },
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)',
          },
        },
        labelLine: {
          show: false,
        },
        data: data.map((item, index) => ({
          ...item,
          itemStyle: {
            color: item.color || colors[index % colors.length],
          },
        })),
      },
    ],
  }

  return (
    <ECharts
      option={option}
      width={width}
      height={height}
      className={className}
      loading={loading}
    />
  )
}
