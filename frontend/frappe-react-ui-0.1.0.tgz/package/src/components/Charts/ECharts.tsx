import React, { useEffect, useRef } from 'react'
import * as echarts from 'echarts'
import { cn } from '../../utils/cn'

export interface EChartsProps {
  option: echarts.EChartsOption
  width?: number | string
  height?: number | string
  className?: string
  theme?: string
  loading?: boolean
  onChartReady?: (chart: echarts.ECharts) => void
  onEvents?: Record<string, (params: any) => void>
}

export const ECharts: React.FC<EChartsProps> = ({
  option,
  width = '100%',
  height = 400,
  className,
  theme,
  loading = false,
  onChartReady,
  onEvents = {},
}) => {
  const chartRef = useRef<HTMLDivElement>(null)
  const chartInstance = useRef<echarts.ECharts | null>(null)

  useEffect(() => {
    if (!chartRef.current) return

    // Initialize chart
    chartInstance.current = echarts.init(chartRef.current, theme)
    
    // Set option
    chartInstance.current.setOption(option)

    // Handle loading
    if (loading) {
      chartInstance.current.showLoading()
    } else {
      chartInstance.current.hideLoading()
    }

    // Bind events
    Object.entries(onEvents).forEach(([eventName, handler]) => {
      chartInstance.current?.on(eventName, handler)
    })

    // Call onChartReady
    if (onChartReady) {
      onChartReady(chartInstance.current)
    }

    // Handle resize
    const handleResize = () => {
      chartInstance.current?.resize()
    }

    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      chartInstance.current?.dispose()
    }
  }, [])

  useEffect(() => {
    if (chartInstance.current) {
      chartInstance.current.setOption(option, true)
    }
  }, [option])

  useEffect(() => {
    if (chartInstance.current) {
      if (loading) {
        chartInstance.current.showLoading()
      } else {
        chartInstance.current.hideLoading()
      }
    }
  }, [loading])

  return (
    <div
      ref={chartRef}
      className={cn('w-full', className)}
      style={{ width, height }}
    />
  )
}
