import type { Meta, StoryObj } from '@storybook/react'
import { Progress } from './Progress'

const meta: Meta<typeof Progress> = {
  title: 'Components/Progress',
  component: Progress,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'success', 'warning', 'error'],
    },
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
    },
    value: {
      control: { type: 'range', min: 0, max: 100, step: 1 },
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    value: 50,
  },
}

export const WithLabel: Story = {
  args: {
    value: 75,
    label: 'Upload Progress',
  },
}

export const WithValue: Story = {
  args: {
    value: 60,
    label: 'Completion',
    showValue: true,
  },
}

export const Success: Story = {
  args: {
    value: 100,
    variant: 'success',
    label: 'Complete',
    showValue: true,
  },
}

export const Warning: Story = {
  args: {
    value: 85,
    variant: 'warning',
    label: 'Storage Usage',
    showValue: true,
  },
}

export const Error: Story = {
  args: {
    value: 95,
    variant: 'error',
    label: 'Critical Level',
    showValue: true,
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="space-y-4 w-64">
      <Progress value={40} size="sm" label="Small" showValue />
      <Progress value={60} size="md" label="Medium" showValue />
      <Progress value={80} size="lg" label="Large" showValue />
    </div>
  ),
}

export const Variants: Story = {
  render: () => (
    <div className="space-y-4 w-64">
      <Progress value={25} variant="default" label="Default" showValue />
      <Progress value={50} variant="success" label="Success" showValue />
      <Progress value={75} variant="warning" label="Warning" showValue />
      <Progress value={90} variant="error" label="Error" showValue />
    </div>
  ),
}
