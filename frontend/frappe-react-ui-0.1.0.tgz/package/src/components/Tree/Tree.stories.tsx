import type { Meta, StoryObj } from '@storybook/react'
import { Tree, TreeNode } from './Tree'
import { Folder, File, Settings } from 'lucide-react'

const meta: Meta<typeof Tree> = {
  title: 'Components/Tree',
  component: Tree,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

const sampleData: TreeNode = {
  id: '1',
  label: 'Root Folder',
  children: [
    {
      id: '2',
      label: 'Documents',
      children: [
        { id: '3', label: 'Resume.pdf' },
        { id: '4', label: 'Cover Letter.docx' },
        {
          id: '5',
          label: 'Projects',
          children: [
            { id: '6', label: 'Project A.zip' },
            { id: '7', label: 'Project B.zip' },
          ],
        },
      ],
    },
    {
      id: '8',
      label: 'Images',
      children: [
        { id: '9', label: 'vacation.jpg' },
        { id: '10', label: 'profile.png' },
      ],
    },
    { id: '11', label: 'readme.txt' },
  ],
}

export const Default: Story = {
  args: {
    node: sampleData,
  },
}

export const WithCustomIcons: Story = {
  args: {
    node: sampleData,
    renderIcon: ({ hasChildren, isCollapsed }) => {
      if (!hasChildren) return <File className="h-3.5 w-3.5 text-blue-500" />
      return isCollapsed ? (
        <Folder className="h-3.5 w-3.5 text-yellow-600" />
      ) : (
        <Folder className="h-3.5 w-3.5 text-yellow-500" />
      )
    },
  },
}

export const WithCustomLabels: Story = {
  args: {
    node: sampleData,
    renderLabel: ({ node, hasChildren }) => (
      <div className="flex items-center gap-2">
        <span className={hasChildren ? 'font-semibold' : 'font-normal'}>
          {node.label}
        </span>
        {hasChildren && (
          <span className="text-xs text-gray-500">
            ({node.children?.length} items)
          </span>
        )}
      </div>
    ),
  },
}

export const WithoutIndentationGuides: Story = {
  args: {
    node: sampleData,
    options: {
      showIndentationGuides: false,
    },
  },
}

export const CustomSpacing: Story = {
  args: {
    node: sampleData,
    options: {
      rowHeight: '35px',
      indentWidth: '30px',
    },
  },
}

export const ExpandedByDefault: Story = {
  args: {
    node: sampleData,
    options: {
      defaultCollapsed: false,
    },
  },
}

const organizationData: TreeNode = {
  id: 'org',
  label: 'Acme Corporation',
  children: [
    {
      id: 'eng',
      label: 'Engineering',
      children: [
        {
          id: 'frontend',
          label: 'Frontend Team',
          children: [
            { id: 'john', label: 'John Doe - Senior Developer' },
            { id: 'jane', label: 'Jane Smith - UI/UX Designer' },
          ],
        },
        {
          id: 'backend',
          label: 'Backend Team',
          children: [
            { id: 'bob', label: 'Bob Johnson - Tech Lead' },
            { id: 'alice', label: 'Alice Brown - DevOps Engineer' },
          ],
        },
      ],
    },
    {
      id: 'sales',
      label: 'Sales',
      children: [
        { id: 'mike', label: 'Mike Wilson - Sales Manager' },
        { id: 'sarah', label: 'Sarah Davis - Account Executive' },
      ],
    },
  ],
}

export const OrganizationChart: Story = {
  args: {
    node: organizationData,
    renderIcon: ({ hasChildren }) => {
      return hasChildren ? (
        <Settings className="h-3.5 w-3.5 text-gray-600" />
      ) : (
        <div className="h-3.5 w-3.5 rounded-full bg-blue-500" />
      )
    },
    renderLabel: ({ node, hasChildren }) => (
      <span className={hasChildren ? 'font-semibold text-gray-800' : 'text-gray-600'}>
        {node.label}
      </span>
    ),
  },
}
