import React, { useState, useRef, useEffect, ReactNode } from 'react'
import { ChevronDown, ChevronRight } from 'lucide-react'
import { cn } from '../../utils/cn'

export interface TreeNode {
  [key: string]: any
  label: string
  children?: TreeNode[]
}

export interface TreeOptions {
  rowHeight?: string
  indentWidth?: string
  showIndentationGuides?: boolean
  defaultCollapsed?: boolean
}

export interface TreeProps {
  node: TreeNode
  nodeKey?: string
  options?: TreeOptions
  renderNode?: (props: {
    node: TreeNode
    hasChildren: boolean
    isCollapsed: boolean
    toggleCollapsed: (event: React.MouseEvent) => void
  }) => ReactNode
  renderIcon?: (props: {
    hasChildren: boolean
    isCollapsed: boolean
  }) => ReactNode
  renderLabel?: (props: {
    node: TreeNode
    hasChildren: boolean
    isCollapsed: boolean
  }) => ReactNode
  className?: string
}

const Tree: React.FC<TreeProps> = ({
  node,
  nodeKey = 'id',
  options = {},
  renderNode,
  renderIcon,
  renderLabel,
  className,
}) => {
  const {
    rowHeight = '25px',
    indentWidth = '20px',
    showIndentationGuides = true,
    defaultCollapsed = true,
  } = options

  const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed)
  const [linePadding, setLinePadding] = useState('')
  const iconRef = useRef<HTMLDivElement>(null)

  const hasChildren = node.children && node.children.length > 0

  const toggleCollapsed = (event: React.MouseEvent) => {
    event.stopPropagation()
    if (hasChildren) {
      setIsCollapsed(!isCollapsed)
    }
  }

  useEffect(() => {
    if (iconRef.current?.clientWidth) {
      // Set the padding for the LHS line to align with the center of icon
      setLinePadding(`${iconRef.current.clientWidth / 2}px`)
    }
  }, [])

  const nodeProps = {
    node,
    hasChildren: !!hasChildren,
    isCollapsed,
    toggleCollapsed,
  }

  const iconProps = {
    hasChildren: !!hasChildren,
    isCollapsed,
  }

  const labelProps = {
    node,
    hasChildren: !!hasChildren,
    isCollapsed,
  }

  return (
    <div className={className}>
      {/* Current Tree Node */}
      {renderNode ? (
        renderNode(nodeProps)
      ) : (
        <div
          className="flex items-center cursor-pointer gap-1"
          style={{ height: rowHeight }}
          onClick={toggleCollapsed}
        >
          <div ref={iconRef}>
            {renderIcon ? (
              renderIcon(iconProps)
            ) : (
              <>
                {hasChildren && !isCollapsed && (
                  <ChevronDown className="h-3.5 w-3.5" />
                )}
                {hasChildren && isCollapsed && (
                  <ChevronRight className="h-3.5 w-3.5" />
                )}
              </>
            )}
          </div>

          {renderLabel ? (
            renderLabel(labelProps)
          ) : (
            <div className={cn(
              'text-base truncate',
              !hasChildren && 'pl-3.5'
            )}>
              {node.label}
            </div>
          )}
        </div>
      )}

      {/* Recursively render the children */}
      {hasChildren && !isCollapsed && (
        <div className="flex">
          {showIndentationGuides && (
            <div
              style={{ paddingLeft: linePadding }}
              className="border-r border-gray-200"
            />
          )}
          <ul className="w-full" style={{ paddingLeft: indentWidth }}>
            {node.children?.map((child) => (
              <li key={child[nodeKey] as string}>
                <Tree
                  node={child}
                  nodeKey={nodeKey}
                  options={options}
                  renderNode={renderNode}
                  renderIcon={renderIcon}
                  renderLabel={renderLabel}
                />
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )
}

export { Tree }
