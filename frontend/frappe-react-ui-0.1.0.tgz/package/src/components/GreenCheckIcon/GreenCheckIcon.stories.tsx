import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { GreenCheckIcon } from './GreenCheckIcon'

const meta: Meta<typeof GreenCheckIcon> = {
  title: 'Components/GreenCheckIcon',
  component: GreenCheckIcon,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {},
}

export const CustomSize: Story = {
  args: {
    className: 'w-12 h-12',
  },
}

export const Small: Story = {
  args: {
    className: 'w-4 h-4',
  },
}

export const Large: Story = {
  args: {
    className: 'w-16 h-16',
  },
}

export const InSuccessMessage: Story = {
  render: () => (
    <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
      <GreenCheckIcon className="w-6 h-6" />
      <div>
        <h3 className="font-semibold text-green-800">Success!</h3>
        <p className="text-green-700">Your changes have been saved successfully.</p>
      </div>
    </div>
  ),
}

export const InList: Story = {
  render: () => (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        <GreenCheckIcon className="w-5 h-5" />
        <span>Task completed successfully</span>
      </div>
      <div className="flex items-center gap-3">
        <GreenCheckIcon className="w-5 h-5" />
        <span>Email verification confirmed</span>
      </div>
      <div className="flex items-center gap-3">
        <GreenCheckIcon className="w-5 h-5" />
        <span>Payment processed</span>
      </div>
    </div>
  ),
}

export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <GreenCheckIcon className="w-4 h-4" />
      <GreenCheckIcon className="w-6 h-6" />
      <GreenCheckIcon className="w-8 h-8" />
      <GreenCheckIcon className="w-12 h-12" />
      <GreenCheckIcon className="w-16 h-16" />
    </div>
  ),
}
