import React from 'react'
import { cn } from '../../utils/cn'

export interface GreenCheckIconProps extends React.SVGProps<SVGSVGElement> {
  className?: string
}

const GreenCheckIcon: React.FC<GreenCheckIconProps> = ({ 
  className, 
  ...props 
}) => {
  return (
    <svg 
      viewBox="0 0 32 32" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={cn('w-8 h-8', className)}
      {...props}
    >
      <path
        d="M16 32c8.837 0 16-7.163 16-16S24.837 0 16 0 0 7.163 0 16s7.163 16 16 16z"
        fill="#59B179"
      />
      <path
        d="M9.333 17.227l1.333 1.333 2.667 2.667 5.333-5.333 2.667-2.667 1.333-1.333"
        stroke="#fff"
        strokeWidth="2"
        strokeMiterlimit="10"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export { GreenCheckIcon }
