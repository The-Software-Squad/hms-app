import type { Meta, StoryObj } from '@storybook/react'
import { LoadingText } from './LoadingText'

const meta: Meta<typeof LoadingText> = {
  title: 'Components/LoadingText',
  component: LoadingText,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {},
}

export const CustomText: Story = {
  args: {
    text: 'Saving changes...',
  },
}

export const LongText: Story = {
  args: {
    text: 'Processing your request, please wait...',
  },
}

export const WithCustomStyling: Story = {
  args: {
    text: 'Uploading files...',
    className: 'text-blue-600 font-medium',
  },
}

export const InCard: Story = {
  render: () => (
    <div className="p-6 border rounded-lg bg-white shadow-sm max-w-md">
      <h3 className="text-lg font-semibold mb-4">Data Processing</h3>
      <LoadingText text="Analyzing data..." />
      <p className="text-sm text-gray-600 mt-4">
        This may take a few moments depending on the size of your dataset.
      </p>
    </div>
  ),
}

export const MultipleStates: Story = {
  render: () => (
    <div className="space-y-4">
      <div className="p-4 border rounded">
        <LoadingText text="Loading..." />
      </div>
      <div className="p-4 border rounded">
        <LoadingText text="Saving..." />
      </div>
      <div className="p-4 border rounded">
        <LoadingText text="Processing..." />
      </div>
      <div className="p-4 border rounded">
        <LoadingText text="Uploading..." />
      </div>
    </div>
  ),
}
