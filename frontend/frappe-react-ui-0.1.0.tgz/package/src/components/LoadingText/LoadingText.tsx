import React from 'react'
import { LoadingIndicator } from '../LoadingIndicator'
import { cn } from '../../utils/cn'

export interface LoadingTextProps {
  text?: string
  className?: string
}

const LoadingText: React.FC<LoadingTextProps> = ({ 
  text = 'Loading...', 
  className 
}) => {
  return (
    <div className={cn('flex items-center text-base text-ink-gray-4', className)}>
      <LoadingIndicator className="-ml-1 mr-2 h-3 w-3" />
      {text}
    </div>
  )
}

export { LoadingText }
