export { LoadingText } from './LoadingText'
export type { LoadingTextProps } from './LoadingText'
