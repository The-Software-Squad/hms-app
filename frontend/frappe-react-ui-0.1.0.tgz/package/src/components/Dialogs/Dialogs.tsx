import React, { createContext, useContext, useState, ReactNode } from 'react'

export interface DialogItem {
  id: string
  component: React.ComponentType<any>
  props?: any
}

interface DialogsContextType {
  dialogs: DialogItem[]
  addDialog: (dialog: DialogItem) => void
  removeDialog: (id: string) => void
  clearDialogs: () => void
}

const DialogsContext = createContext<DialogsContextType | undefined>(undefined)

export interface DialogsProviderProps {
  children: ReactNode
}

export const DialogsProvider: React.FC<DialogsProviderProps> = ({ children }) => {
  const [dialogs, setDialogs] = useState<DialogItem[]>([])

  const addDialog = (dialog: DialogItem) => {
    setDialogs(prev => [...prev, dialog])
  }

  const removeDialog = (id: string) => {
    setDialogs(prev => prev.filter(dialog => dialog.id !== id))
  }

  const clearDialogs = () => {
    setDialogs([])
  }

  return (
    <DialogsContext.Provider value={{ dialogs, addDialog, removeDialog, clearDialogs }}>
      {children}
    </DialogsContext.Provider>
  )
}

export const useDialogs = () => {
  const context = useContext(DialogsContext)
  if (!context) {
    throw new Error('useDialogs must be used within a DialogsProvider')
  }
  return context
}

export interface DialogsProps {
  className?: string
}

const Dialogs: React.FC<DialogsProps> = ({ className }) => {
  const { dialogs } = useDialogs()

  return (
    <div className={className}>
      {dialogs.map(dialog => {
        const Component = dialog.component
        return <Component key={dialog.id} {...dialog.props} />
      })}
    </div>
  )
}

export { Dialogs }
