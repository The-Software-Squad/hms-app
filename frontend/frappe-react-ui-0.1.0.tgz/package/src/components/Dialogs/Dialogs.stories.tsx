import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { Dialogs, DialogsProvider, useDialogs } from './Dialogs'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../Dialog'

const meta: Meta<typeof Dialogs> = {
  title: 'Components/Dialogs',
  component: Dialogs,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  decorators: [
    (Story) => (
      <DialogsProvider>
        <Story />
      </DialogsProvider>
    ),
  ],
}

export default meta
type Story = StoryObj<typeof meta>

// Sample dialog components
const SampleDialog: React.FC<{ title: string; onClose: () => void }> = ({ title, onClose }) => (
  <Dialog open onOpenChange={onClose}>
    <DialogContent>
      <DialogHeader>
        <DialogTitle>{title}</DialogTitle>
      </DialogHeader>
      <div className="p-4">
        <p>This is a sample dialog: {title}</p>
        <button 
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={onClose}
        >
          Close
        </button>
      </div>
    </DialogContent>
  </Dialog>
)

const ConfirmDialog: React.FC<{ message: string; onConfirm: () => void; onCancel: () => void }> = ({ 
  message, 
  onConfirm, 
  onCancel 
}) => (
  <Dialog open onOpenChange={onCancel}>
    <DialogContent>
      <DialogHeader>
        <DialogTitle>Confirm Action</DialogTitle>
      </DialogHeader>
      <div className="p-4">
        <p>{message}</p>
        <div className="flex gap-2 mt-4">
          <button 
            className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
            onClick={onConfirm}
          >
            Confirm
          </button>
          <button 
            className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
            onClick={onCancel}
          >
            Cancel
          </button>
        </div>
      </div>
    </DialogContent>
  </Dialog>
)

const DialogController: React.FC = () => {
  const { addDialog, removeDialog, clearDialogs } = useDialogs()

  const openSampleDialog = () => {
    const id = `dialog-${Date.now()}`
    addDialog({
      id,
      component: SampleDialog,
      props: {
        title: 'Sample Dialog',
        onClose: () => removeDialog(id)
      }
    })
  }

  const openConfirmDialog = () => {
    const id = `confirm-${Date.now()}`
    addDialog({
      id,
      component: ConfirmDialog,
      props: {
        message: 'Are you sure you want to delete this item?',
        onConfirm: () => {
          alert('Confirmed!')
          removeDialog(id)
        },
        onCancel: () => removeDialog(id)
      }
    })
  }

  const openMultipleDialogs = () => {
    for (let i = 1; i <= 3; i++) {
      const id = `multi-${Date.now()}-${i}`
      addDialog({
        id,
        component: SampleDialog,
        props: {
          title: `Dialog ${i}`,
          onClose: () => removeDialog(id)
        }
      })
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={openSampleDialog}
        >
          Open Sample Dialog
        </button>
        <button 
          className="px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700"
          onClick={openConfirmDialog}
        >
          Open Confirm Dialog
        </button>
        <button 
          className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
          onClick={openMultipleDialogs}
        >
          Open Multiple Dialogs
        </button>
        <button 
          className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
          onClick={clearDialogs}
        >
          Clear All
        </button>
      </div>
      <Dialogs />
    </div>
  )
}

export const Default: Story = {
  render: () => <DialogController />,
}

export const WithCustomStyling: Story = {
  render: () => (
    <div>
      <DialogController />
      <Dialogs className="custom-dialogs-container" />
    </div>
  ),
}
