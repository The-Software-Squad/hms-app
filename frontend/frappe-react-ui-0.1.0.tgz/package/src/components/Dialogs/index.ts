export { Dialogs, DialogsProvider, useDialogs } from './Dialogs'
export type { DialogsProps, DialogsProviderProps, DialogItem } from './Dialogs'
