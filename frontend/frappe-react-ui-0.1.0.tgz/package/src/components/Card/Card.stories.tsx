import type { Meta, StoryObj } from '@storybook/react'
import { Card } from './Card'

const meta: Meta<typeof Card> = {
  title: 'Components/Card',
  component: Card,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'outline', 'ghost'],
    },
    padding: {
      control: 'select',
      options: ['none', 'sm', 'md', 'lg'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    children: (
      <div>
        <h3 className="text-lg font-semibold mb-2">Card Title</h3>
        <p className="text-ink-gray-6">This is a default card with some content inside it.</p>
      </div>
    ),
  },
}

export const Outline: Story = {
  args: {
    variant: 'outline',
    children: (
      <div>
        <h3 className="text-lg font-semibold mb-2">Outline Card</h3>
        <p className="text-ink-gray-6">This card has an outline variant.</p>
      </div>
    ),
  },
}

export const Ghost: Story = {
  args: {
    variant: 'ghost',
    children: (
      <div>
        <h3 className="text-lg font-semibold mb-2">Ghost Card</h3>
        <p className="text-ink-gray-6">This card has a ghost variant with no background.</p>
      </div>
    ),
  },
}

export const NoPadding: Story = {
  args: {
    padding: 'none',
    children: (
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2">No Padding Card</h3>
        <p className="text-ink-gray-6">This card has no default padding, but content has its own padding.</p>
      </div>
    ),
  },
}

export const LargePadding: Story = {
  args: {
    padding: 'lg',
    children: (
      <div>
        <h3 className="text-lg font-semibold mb-2">Large Padding Card</h3>
        <p className="text-ink-gray-6">This card has large padding for more spacious content.</p>
      </div>
    ),
  },
}
