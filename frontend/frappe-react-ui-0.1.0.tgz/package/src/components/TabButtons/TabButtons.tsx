import React from 'react'
import { cn } from '../../utils/cn'

export interface TabButton {
  label: string
  value?: string | number | boolean
  disabled?: boolean
  hideLabel?: boolean
  onClick?: () => void
  [key: string]: any
}

export interface TabButtonsProps {
  buttons: TabButton[]
  value?: string | number | boolean
  onValueChange?: (value: string) => void
  className?: string
}

const TabButtons: React.FC<TabButtonsProps> = ({
  buttons,
  value,
  onValueChange,
  className,
}) => {
  const handleButtonClick = (button: TabButton) => {
    const buttonValue = (button.value ?? button.label).toString()
    onValueChange?.(buttonValue)
    button.onClick?.()
  }

  return (
    <div
      className={cn(
        'flex space-x-0.5 rounded-md bg-surface-gray-2 h-7 items-center px-[1px] text-sm',
        className
      )}
      role="radiogroup"
    >
      {buttons.map((button) => {
        const buttonValue = (button.value ?? button.label).toString()
        const isChecked = value?.toString() === buttonValue
        
        return (
          <button
            key={button.label}
            className={cn(
              'h-6 px-3 py-1 rounded text-sm font-medium transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-outline-gray-2',
              {
                'bg-surface-white text-ink-gray-8 shadow': isChecked && !button.disabled,
                'text-ink-gray-5 hover:text-ink-gray-6': !isChecked && !button.disabled,
                'opacity-50 cursor-not-allowed': button.disabled,
              },
              button.className
            )}
            onClick={() => handleButtonClick(button)}
            disabled={button.disabled}
            role="radio"
            aria-checked={isChecked}
          >
            {button.label && !button.hideLabel && (
              <span className="flex h-4 items-center">
                {button.label}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}

export { TabButtons }
