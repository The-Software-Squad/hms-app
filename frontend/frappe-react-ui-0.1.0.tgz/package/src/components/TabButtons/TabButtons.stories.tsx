import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { TabButtons } from './TabButtons'

const meta: Meta<typeof TabButtons> = {
  title: 'Components/TabButtons',
  component: TabButtons,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  render: () => {
    const [value, setValue] = useState('option1')
    
    return (
      <TabButtons
        value={value}
        onValueChange={setValue}
        buttons={[
          { label: 'Option 1', value: 'option1' },
          { label: 'Option 2', value: 'option2' },
          { label: 'Option 3', value: 'option3' },
        ]}
      />
    )
  },
}

export const WithDisabled: Story = {
  render: () => {
    const [value, setValue] = useState('enabled1')
    
    return (
      <TabButtons
        value={value}
        onValueChange={setValue}
        buttons={[
          { label: 'Enabled 1', value: 'enabled1' },
          { label: 'Disabled', value: 'disabled', disabled: true },
          { label: 'Enabled 2', value: 'enabled2' },
        ]}
      />
    )
  },
}

export const WithClickHandlers: Story = {
  render: () => {
    const [value, setValue] = useState('tab1')
    
    return (
      <TabButtons
        value={value}
        onValueChange={setValue}
        buttons={[
          { 
            label: 'Tab 1', 
            value: 'tab1',
            onClick: () => console.log('Tab 1 clicked')
          },
          { 
            label: 'Tab 2', 
            value: 'tab2',
            onClick: () => console.log('Tab 2 clicked')
          },
          { 
            label: 'Tab 3', 
            value: 'tab3',
            onClick: () => console.log('Tab 3 clicked')
          },
        ]}
      />
    )
  },
}

export const ViewModes: Story = {
  render: () => {
    const [value, setValue] = useState('list')
    
    return (
      <TabButtons
        value={value}
        onValueChange={setValue}
        buttons={[
          { label: 'List', value: 'list' },
          { label: 'Grid', value: 'grid' },
          { label: 'Card', value: 'card' },
        ]}
      />
    )
  },
}
