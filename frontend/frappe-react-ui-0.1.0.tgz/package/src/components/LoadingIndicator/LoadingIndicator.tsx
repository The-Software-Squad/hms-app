import React from 'react'
import { cn } from '../../utils/cn'

export interface LoadingIndicatorProps {
  className?: string
}

export const LoadingIndicator: React.FC<LoadingIndicatorProps> = ({ className }) => {
  return (
    <div
      className={cn(
        'animate-spin rounded-full border-2 border-current border-t-transparent',
        className
      )}
      role="status"
      aria-label="Loading"
    >
      <span className="sr-only">Loading...</span>
    </div>
  )
}
