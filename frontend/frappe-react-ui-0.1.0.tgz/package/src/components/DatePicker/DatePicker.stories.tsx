import type { Meta, StoryObj } from '@storybook/react'
import { DatePicker } from './DatePicker'
import { useState } from 'react'

const meta: Meta<typeof DatePicker> = {
  title: 'Components/DatePicker',
  component: DatePicker,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    format: {
      control: 'select',
      options: ['YYYY-MM-DD', 'MM/DD/YYYY', 'DD/MM/YYYY', 'MMM DD, YYYY'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    placeholder: 'Select date',
  },
}

export const WithLabel: Story = {
  args: {
    label: 'Birth Date',
    placeholder: 'Select your birth date',
  },
}

export const WithHelperText: Story = {
  args: {
    label: 'Event Date',
    placeholder: 'Select event date',
    helperText: 'Choose the date for your event',
  },
}

export const WithError: Story = {
  args: {
    label: 'Required Date',
    placeholder: 'Select date',
    error: 'This field is required',
    required: true,
  },
}

export const Disabled: Story = {
  args: {
    label: 'Disabled Date Picker',
    placeholder: 'Cannot select',
    disabled: true,
  },
}

export const CustomFormat: Story = {
  args: {
    label: 'Custom Format',
    placeholder: 'MM/DD/YYYY',
    format: 'MM/DD/YYYY',
  },
}

export const WithMinMax: Story = {
  render: () => {
    const today = new Date()
    const minDate = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000) // 7 days ago
    const maxDate = new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
    
    return (
      <DatePicker
        label="Appointment Date"
        placeholder="Select appointment date"
        minDate={minDate}
        maxDate={maxDate}
        helperText="Available dates: 7 days ago to 30 days from now"
      />
    )
  },
}

export const Controlled: Story = {
  render: () => {
    const [date, setDate] = useState<Date | null>(null)
    
    return (
      <div className="space-y-4 w-80">
        <DatePicker
          label="Controlled Date Picker"
          value={date}
          onChange={setDate}
          placeholder="Select date"
          helperText={`Selected: ${date ? date.toLocaleDateString() : 'None'}`}
        />
        <div className="flex gap-2">
          <button
            onClick={() => setDate(new Date())}
            className="px-3 py-1 bg-blue-500 text-white rounded text-sm"
          >
            Today
          </button>
          <button
            onClick={() => setDate(null)}
            className="px-3 py-1 bg-gray-500 text-white rounded text-sm"
          >
            Clear
          </button>
        </div>
      </div>
    )
  },
}
