import React, { useState } from 'react'
import * as PopoverPrimitive from '@radix-ui/react-popover'
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Button } from '../Button'
import { Input } from '../Input'
import { dayjs } from '../../utils/dayjs'

export interface DatePickerProps {
  value?: Date | string
  onChange?: (date: Date | null) => void
  placeholder?: string
  disabled?: boolean
  label?: string
  error?: string
  helperText?: string
  required?: boolean
  format?: string
  minDate?: Date
  maxDate?: Date
  className?: string
}

export const DatePicker: React.FC<DatePickerProps> = ({
  value,
  onChange,
  placeholder = 'Select date',
  disabled = false,
  label,
  error,
  helperText,
  required = false,
  format = 'YYYY-MM-DD',
  minDate,
  maxDate,
  className,
}) => {
  const [open, setOpen] = useState(false)
  const [currentMonth, setCurrentMonth] = useState(
    value ? dayjs(value).toDate() : new Date()
  )

  const selectedDate = value ? dayjs(value).toDate() : null

  const handleDateSelect = (date: Date) => {
    onChange?.(date)
    setOpen(false)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value
    if (!inputValue) {
      onChange?.(null)
      return
    }

    const parsed = dayjs(inputValue, format, true)
    if (parsed.isValid()) {
      onChange?.(parsed.toDate())
    }
  }

  const displayValue = selectedDate ? dayjs(selectedDate).format(format) : ''

  return (
    <div className={cn('space-y-2', className)}>
      {label && (
        <label className="block text-sm font-medium text-ink-gray-8">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}

      <PopoverPrimitive.Root open={open} onOpenChange={setOpen}>
        <PopoverPrimitive.Trigger asChild>
          <Button
            variant="outline"
            className={cn(
              'w-full justify-start text-left font-normal',
              !selectedDate && 'text-ink-gray-4',
              error && 'border-red-500'
            )}
            disabled={disabled}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {displayValue || placeholder}
          </Button>
        </PopoverPrimitive.Trigger>

        <PopoverPrimitive.Portal>
          <PopoverPrimitive.Content
            className="w-auto p-0 bg-surface-white border border-outline-gray-2 rounded-lg shadow-lg"
            align="start"
          >
            <Calendar
              selected={selectedDate}
              onSelect={handleDateSelect}
              currentMonth={currentMonth}
              onMonthChange={setCurrentMonth}
              minDate={minDate}
              maxDate={maxDate}
            />
          </PopoverPrimitive.Content>
        </PopoverPrimitive.Portal>
      </PopoverPrimitive.Root>

      {/* Alternative input for manual entry */}
      <Input
        type="text"
        value={displayValue}
        onChange={handleInputChange}
        placeholder={format}
        disabled={disabled}
        error={error}
        helperText={helperText}
        className="mt-1"
      />
    </div>
  )
}

interface CalendarProps {
  selected?: Date | null
  onSelect?: (date: Date) => void
  currentMonth: Date
  onMonthChange: (date: Date) => void
  minDate?: Date
  maxDate?: Date
}

const Calendar: React.FC<CalendarProps> = ({
  selected,
  onSelect,
  currentMonth,
  onMonthChange,
  minDate,
  maxDate,
}) => {
  const today = new Date()
  const monthStart = dayjs(currentMonth).startOf('month')
  const monthEnd = dayjs(currentMonth).endOf('month')
  const calendarStart = monthStart.startOf('week')
  const calendarEnd = monthEnd.endOf('week')

  const days = []
  let current = calendarStart

  while (current.isBefore(calendarEnd) || current.isSame(calendarEnd, 'day')) {
    days.push(current.toDate())
    current = current.add(1, 'day')
  }

  const isDateDisabled = (date: Date) => {
    if (minDate && dayjs(date).isBefore(minDate, 'day')) return true
    if (maxDate && dayjs(date).isAfter(maxDate, 'day')) return true
    return false
  }

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newMonth = dayjs(currentMonth).add(direction === 'next' ? 1 : -1, 'month').toDate()
    onMonthChange(newMonth)
  }

  return (
    <div className="p-3">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateMonth('prev')}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        
        <h2 className="text-sm font-semibold">
          {dayjs(currentMonth).format('MMMM YYYY')}
        </h2>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateMonth('next')}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Days of week */}
      <div className="grid grid-cols-7 gap-1 mb-2">
        {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((day) => (
          <div key={day} className="text-center text-xs font-medium text-ink-gray-5 p-2">
            {day}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7 gap-1">
        {days.map((date) => {
          const isSelected = selected && dayjs(date).isSame(selected, 'day')
          const isToday = dayjs(date).isSame(today, 'day')
          const isCurrentMonth = dayjs(date).isSame(currentMonth, 'month')
          const isDisabled = isDateDisabled(date)

          return (
            <Button
              key={date.toISOString()}
              variant={isSelected ? 'solid' : 'ghost'}
              size="sm"
              className={cn(
                'h-8 w-8 p-0 font-normal',
                !isCurrentMonth && 'text-ink-gray-4',
                isToday && !isSelected && 'bg-surface-gray-2',
                isSelected && 'bg-blue-500 text-white hover:bg-blue-600'
              )}
              disabled={isDisabled}
              onClick={() => onSelect?.(date)}
            >
              {dayjs(date).format('D')}
            </Button>
          )
        })}
      </div>
    </div>
  )
}
