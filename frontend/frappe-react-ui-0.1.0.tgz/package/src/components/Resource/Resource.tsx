import React from 'react'
import { useCall } from '../../data-fetching/useCall'

export interface ResourceOptions {
  url: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE'
  params?: Record<string, any>
  auto?: boolean
  onSuccess?: (data: any) => void
  onError?: (error: any) => void
}

export interface ResourceProps {
  options: ResourceOptions
  children: (props: {
    resource: {
      data: any
      error: any
      loading: boolean
      reload: () => void
      submit: (params?: any) => void
      fetch: () => void
    }
    data: any
    error: any
    loading: boolean
    fetch: () => void
    submit: (params?: any) => void
  }) => React.ReactNode
}

const Resource: React.FC<ResourceProps> = ({ options, children }) => {
  const {
    data,
    error,
    loading,
    execute,
    submit
  } = useCall(options)

  const resource = {
    data,
    error,
    loading,
    reload: execute,
    submit,
    fetch: execute
  }

  return (
    <>
      {children({
        resource,
        data,
        error,
        loading,
        fetch: execute,
        submit
      })}
    </>
  )
}

export { Resource }
