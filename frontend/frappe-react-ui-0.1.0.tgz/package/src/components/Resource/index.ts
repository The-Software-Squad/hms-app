export { Resource } from './Resource'
export type { ResourceProps, ResourceOptions } from './Resource'
