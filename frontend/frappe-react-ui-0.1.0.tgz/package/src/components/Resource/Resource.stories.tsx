import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { Resource } from './Resource'

const meta: Meta<typeof Resource> = {
  title: 'Components/Resource',
  component: Resource,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  render: () => (
    <Resource
      options={{
        url: '/api/users',
        method: 'GET',
        auto: true
      }}
    >
      {({ data, loading, error, fetch }) => (
        <div className="p-4 border rounded-lg">
          <h3 className="text-lg font-semibold mb-2">User Data</h3>
          {loading && <p>Loading...</p>}
          {error && <p className="text-red-600">Error: {error.message}</p>}
          {data && (
            <div>
              <pre className="bg-gray-100 p-2 rounded text-sm">
                {JSON.stringify(data, null, 2)}
              </pre>
              <button 
                className="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                onClick={() => fetch()}
              >
                Refresh
              </button>
            </div>
          )}
        </div>
      )}
    </Resource>
  ),
}

export const WithSubmit: Story = {
  render: () => (
    <Resource
      options={{
        url: '/api/users',
        method: 'POST'
      }}
    >
      {({ data, loading, error, submit }) => (
        <div className="p-4 border rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Create User</h3>
          {loading && <p>Submitting...</p>}
          {error && <p className="text-red-600">Error: {error.message}</p>}
          {data && <p className="text-green-600">Success: User created!</p>}
          <button 
            className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50"
            onClick={() => submit({ name: 'John Doe', email: 'john@example.com' })}
            disabled={loading}
          >
            Create User
          </button>
        </div>
      )}
    </Resource>
  ),
}

export const RenderProp: Story = {
  render: () => (
    <Resource
      options={{
        url: '/api/posts',
        method: 'GET'
      }}
    >
      {({ resource }) => (
        <div className="p-4 border rounded-lg">
          <h3 className="text-lg font-semibold mb-2">Posts</h3>
          <div className="space-y-2">
            <p>Loading: {resource.loading ? 'Yes' : 'No'}</p>
            <p>Has Error: {resource.error ? 'Yes' : 'No'}</p>
            <p>Has Data: {resource.data ? 'Yes' : 'No'}</p>
            <div className="flex gap-2">
              <button 
                className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700"
                onClick={() => resource.fetch()}
              >
                Fetch
              </button>
              <button 
                className="px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                onClick={() => resource.submit({ title: 'New Post' })}
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      )}
    </Resource>
  ),
}
