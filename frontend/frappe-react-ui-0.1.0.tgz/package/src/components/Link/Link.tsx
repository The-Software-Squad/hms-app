import React, { ReactNode } from 'react'
import { cn } from '../../utils/cn'

export interface LinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string
  children: ReactNode
  className?: string
}

const Link: React.FC<LinkProps> = ({ 
  to, 
  children, 
  className, 
  ...props 
}) => {
  const isExternal = to.startsWith('http')
  
  const linkProps = {
    ...props,
    href: to,
    target: isExternal ? '_blank' : undefined,
    rel: isExternal ? 'noopener noreferrer' : undefined,
  }

  return (
    <a
      {...linkProps}
      className={cn(
        'cursor-pointer text-blue-500 hover:text-blue-600 transition-colors',
        className
      )}
    >
      {children}
    </a>
  )
}

export { Link }
