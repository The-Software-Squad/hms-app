import type { Meta, StoryObj } from '@storybook/react'
import { Link } from './Link'

const meta: Meta<typeof Link> = {
  title: 'Components/Link',
  component: Link,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    to: '/dashboard',
    children: 'Go to Dashboard',
  },
}

export const ExternalLink: Story = {
  args: {
    to: 'https://github.com/frappe/frappe-ui',
    children: 'Visit Frappe UI on GitHub',
  },
}

export const WithCustomStyling: Story = {
  args: {
    to: '/profile',
    children: 'View Profile',
    className: 'font-semibold underline decoration-2',
  },
}

export const InParagraph: Story = {
  render: () => (
    <p className="text-gray-700 max-w-md">
      Welcome to our application! You can{' '}
      <Link to="/signup" className="font-medium">
        create an account
      </Link>{' '}
      or{' '}
      <Link to="/login" className="font-medium">
        sign in
      </Link>{' '}
      to get started. For more information, visit our{' '}
      <Link to="https://docs.example.com" className="font-medium">
        documentation
      </Link>
      .
    </p>
  ),
}

export const LinkTypes: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold mb-2">Internal Links</h3>
        <div className="space-y-2">
          <div><Link to="/home">Home Page</Link></div>
          <div><Link to="/about">About Us</Link></div>
          <div><Link to="/contact">Contact</Link></div>
        </div>
      </div>
      
      <div>
        <h3 className="font-semibold mb-2">External Links</h3>
        <div className="space-y-2">
          <div><Link to="https://google.com">Google</Link></div>
          <div><Link to="https://github.com">GitHub</Link></div>
          <div><Link to="https://stackoverflow.com">Stack Overflow</Link></div>
        </div>
      </div>
    </div>
  ),
}
