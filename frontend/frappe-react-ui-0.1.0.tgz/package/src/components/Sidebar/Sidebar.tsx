import React, { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Button } from '../Button'

export interface SidebarItem {
  id: string
  label: string
  icon?: React.ReactNode
  href?: string
  onClick?: () => void
  active?: boolean
  disabled?: boolean
  children?: SidebarItem[]
}

export interface SidebarProps {
  items: SidebarItem[]
  collapsed?: boolean
  onCollapsedChange?: (collapsed: boolean) => void
  collapsible?: boolean
  variant?: 'default' | 'floating'
  position?: 'left' | 'right'
  overlay?: boolean
  onOverlayClick?: () => void
  header?: React.ReactNode
  footer?: React.ReactNode
  className?: string
  width?: number
  collapsedWidth?: number
}

export const Sidebar: React.FC<SidebarProps> = ({
  items,
  collapsed = false,
  onCollapsedChange,
  collapsible = true,
  variant = 'default',
  position = 'left',
  overlay = false,
  onOverlayClick,
  header,
  footer,
  className,
  width = 256,
  collapsedWidth = 64,
}) => {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set())

  const toggleExpanded = (itemId: string) => {
    const newExpanded = new Set(expandedItems)
    if (newExpanded.has(itemId)) {
      newExpanded.delete(itemId)
    } else {
      newExpanded.add(itemId)
    }
    setExpandedItems(newExpanded)
  }

  const renderItem = (item: SidebarItem, level = 0) => {
    const hasChildren = item.children && item.children.length > 0
    const isExpanded = expandedItems.has(item.id)
    const showChildren = hasChildren && isExpanded && !collapsed

    return (
      <div key={item.id}>
        <div
          className={cn(
            'flex items-center w-full px-3 py-2 text-sm transition-colors rounded-md group',
            item.active && 'bg-surface-blue-2 text-ink-blue-3',
            !item.active && 'text-ink-gray-7 hover:bg-surface-gray-2 hover:text-ink-gray-9',
            item.disabled && 'opacity-50 cursor-not-allowed',
            level > 0 && 'ml-4'
          )}
          style={{ paddingLeft: collapsed ? '12px' : `${12 + level * 16}px` }}
        >
          {item.icon && (
            <div className="mr-3 h-4 w-4 shrink-0">
              {item.icon}
            </div>
          )}
          
          {!collapsed && (
            <>
              <span className="flex-1 truncate">{item.label}</span>
              
              {hasChildren && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-4 w-4 p-0 ml-2"
                  onClick={(e) => {
                    e.stopPropagation()
                    toggleExpanded(item.id)
                  }}
                >
                  {isExpanded ? (
                    <ChevronLeft className="h-3 w-3" />
                  ) : (
                    <ChevronRight className="h-3 w-3" />
                  )}
                </Button>
              )}
            </>
          )}
          
          {/* Click handler */}
          <button
            className="absolute inset-0 w-full h-full"
            onClick={() => {
              if (item.disabled) return
              
              if (hasChildren && !collapsed) {
                toggleExpanded(item.id)
              } else if (item.onClick) {
                item.onClick()
              } else if (item.href) {
                window.location.href = item.href
              }
            }}
            disabled={item.disabled}
          />
        </div>
        
        {/* Children */}
        {showChildren && (
          <div className="mt-1">
            {item.children!.map(child => renderItem(child, level + 1))}
          </div>
        )}
      </div>
    )
  }

  const sidebarContent = (
    <div
      className={cn(
        'flex flex-col h-full bg-surface-white border-r border-outline-gray-2 transition-all duration-200',
        variant === 'floating' && 'rounded-lg shadow-lg border',
        className
      )}
      style={{ 
        width: collapsed ? collapsedWidth : width,
        minWidth: collapsed ? collapsedWidth : width,
      }}
    >
      {/* Header */}
      {header && (
        <div className={cn(
          'flex items-center justify-between p-4 border-b border-outline-gray-2',
          collapsed && 'justify-center'
        )}>
          {!collapsed && header}
          {collapsible && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onCollapsedChange?.(!collapsed)}
              className="h-6 w-6 p-0"
            >
              {collapsed ? (
                position === 'left' ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />
              ) : (
                position === 'left' ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />
              )}
            </Button>
          )}
        </div>
      )}
      
      {/* Navigation Items */}
      <nav className="flex-1 overflow-y-auto p-2">
        <div className="space-y-1">
          {items.map(item => renderItem(item))}
        </div>
      </nav>
      
      {/* Footer */}
      {footer && !collapsed && (
        <div className="p-4 border-t border-outline-gray-2">
          {footer}
        </div>
      )}
    </div>
  )

  if (overlay) {
    return (
      <>
        {/* Overlay */}
        <div
          className="fixed inset-0 bg-black/50 z-40"
          onClick={onOverlayClick}
        />
        
        {/* Sidebar */}
        <div
          className={cn(
            'fixed top-0 z-50 h-full',
            position === 'left' ? 'left-0' : 'right-0'
          )}
        >
          {sidebarContent}
        </div>
      </>
    )
  }

  return sidebarContent
}

// Mobile Sidebar Hook
export const useMobileSidebar = () => {
  const [isOpen, setIsOpen] = useState(false)

  const toggle = () => setIsOpen(!isOpen)
  const open = () => setIsOpen(true)
  const close = () => setIsOpen(false)

  return {
    isOpen,
    toggle,
    open,
    close,
  }
}
