import React, { ReactNode } from 'react'
import { cn } from '../../utils/cn'
import { FormLabel } from '../FormLabel'
import { TextInput } from '../TextInput'
import { Select } from '../Select'
import { Textarea } from '../Textarea'
import { Checkbox } from '../Checkbox'
import { Autocomplete } from '../Autocomplete'

export interface FormControlProps {
  label?: string
  description?: string
  type?: 'text' | 'email' | 'password' | 'number' | 'url' | 'tel' | 'search' | 'textarea' | 'select' | 'checkbox' | 'autocomplete'
  size?: 'sm' | 'md'
  variant?: 'subtle' | 'outline'
  required?: boolean
  id?: string
  className?: string
  style?: React.CSSProperties
  prefix?: ReactNode
  suffix?: ReactNode
  children?: ReactNode
  // Pass through props for the underlying input component
  [key: string]: any
}

const FormControl: React.FC<FormControlProps> = ({
  label,
  description,
  type = 'text',
  size = 'sm',
  variant = 'subtle',
  required,
  id,
  className,
  style,
  prefix,
  suffix,
  children,
  ...controlProps
}) => {
  const descriptionClasses = cn(
    'text-ink-gray-5',
    {
      'text-xs': size === 'sm',
      'text-base': size === 'md',
    }
  )

  // For checkbox, render differently
  if (type === 'checkbox') {
    return (
      <Checkbox
        id={id}
        label={label}
        size={size}
        className={className}
        {...controlProps}
      />
    )
  }

  // For other types, render with label and description
  return (
    <div className={cn('space-y-1.5', className)} style={style}>
      {label && (
        <FormLabel
          label={label}
          size={size}
          htmlFor={id}
          required={required}
        />
      )}
      
      {type === 'select' ? (
        <Select
          {...controlProps}
        >
          {controlProps.children || <option>No options</option>}
        </Select>
      ) : type === 'autocomplete' ? (
        <Autocomplete
          options={[]}
          {...controlProps}
        />
      ) : type === 'textarea' ? (
        <Textarea
          {...controlProps}
        />
      ) : (
        <TextInput
          id={id}
          type={type}
          size={size}
          variant={variant}
          required={required}
          prefix={prefix}
          suffix={suffix}
          {...controlProps}
        />
      )}
      
      {children || (description && (
        <p className={descriptionClasses}>{description}</p>
      ))}
    </div>
  )
}

export { FormControl }
