import type { Meta, StoryObj } from '@storybook/react'
import { FormControl } from './FormControl'
import { Search, User } from 'lucide-react'

const meta: Meta<typeof FormControl> = {
  title: 'Components/FormControl',
  component: FormControl,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    type: {
      control: { type: 'select' },
      options: ['text', 'email', 'password', 'number', 'textarea', 'select', 'checkbox', 'autocomplete'],
    },
    size: {
      control: { type: 'select' },
      options: ['sm', 'md'],
    },
    variant: {
      control: { type: 'select' },
      options: ['subtle', 'outline'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    label: 'Email',
    type: 'email',
    placeholder: 'Enter your email',
    description: 'We will never share your email with anyone else.',
  },
}

export const Required: Story = {
  args: {
    label: 'Full Name',
    type: 'text',
    placeholder: 'Enter your full name',
    required: true,
    description: 'This field is required.',
  },
}

export const WithPrefix: Story = {
  args: {
    label: 'Search',
    type: 'text',
    placeholder: 'Search users...',
    prefix: <Search size={16} />,
  },
}

export const WithSuffix: Story = {
  args: {
    label: 'Username',
    type: 'text',
    placeholder: 'Enter username',
    suffix: <User size={16} />,
  },
}

export const Textarea: Story = {
  args: {
    label: 'Message',
    type: 'textarea',
    placeholder: 'Enter your message...',
    description: 'Please provide as much detail as possible.',
    rows: 4,
  },
}

export const Checkbox: Story = {
  args: {
    label: 'I agree to the terms and conditions',
    type: 'checkbox',
  },
}

export const Select: Story = {
  args: {
    label: 'Country',
    type: 'select',
    placeholder: 'Select a country',
    options: [
      { label: 'United States', value: 'us' },
      { label: 'Canada', value: 'ca' },
      { label: 'United Kingdom', value: 'uk' },
      { label: 'Germany', value: 'de' },
    ],
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="space-y-6 w-80">
      <FormControl
        label="Small Size"
        size="sm"
        placeholder="Small input"
        description="This is a small form control"
      />
      <FormControl
        label="Medium Size"
        size="md"
        placeholder="Medium input"
        description="This is a medium form control"
      />
    </div>
  ),
}

export const Variants: Story = {
  render: () => (
    <div className="space-y-6 w-80">
      <FormControl
        label="Subtle Variant"
        variant="subtle"
        placeholder="Subtle input"
        description="This uses the subtle variant"
      />
      <FormControl
        label="Outline Variant"
        variant="outline"
        placeholder="Outline input"
        description="This uses the outline variant"
      />
    </div>
  ),
}
