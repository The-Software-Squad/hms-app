import React from 'react'
import { cn } from '../../utils/cn'

export interface ErrorMessageProps {
  message?: string | Error | null
  className?: string
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, className }) => {
  if (!message) return null

  const errorMessage = React.useMemo(() => {
    if (message instanceof Error) {
      // Handle Frappe-style error objects with messages array
      return (message as any).messages || message.message
    }
    return message
  }, [message])

  return (
    <div
      className={cn(
        'whitespace-pre-line text-sm text-ink-red-4',
        className
      )}
      role="alert"
      dangerouslySetInnerHTML={{ __html: errorMessage }}
    />
  )
}

export { ErrorMessage }
