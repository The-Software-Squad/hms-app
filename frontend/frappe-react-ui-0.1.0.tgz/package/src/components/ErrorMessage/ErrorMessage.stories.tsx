import type { Meta, StoryObj } from '@storybook/react'
import { ErrorMessage } from './ErrorMessage'

const meta: Meta<typeof ErrorMessage> = {
  title: 'Components/ErrorMessage',
  component: ErrorMessage,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    message: 'This is an error message',
  },
}

export const WithError: Story = {
  args: {
    message: new Error('Something went wrong'),
  },
}

export const WithFrappeError: Story = {
  args: {
    message: {
      message: 'Validation Error',
      messages: 'Email is required<br>Password must be at least 8 characters',
    } as any,
  },
}

export const MultilineError: Story = {
  args: {
    message: 'This is a multiline error message.\nIt spans multiple lines.\nEach line is displayed separately.',
  },
}

export const NoMessage: Story = {
  args: {
    message: null,
  },
}
