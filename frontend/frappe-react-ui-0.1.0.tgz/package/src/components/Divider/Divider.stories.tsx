import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { Divider } from './Divider'

const meta: Meta<typeof Divider> = {
  title: 'Components/Divider',
  component: Divider,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  render: () => (
    <div className="w-80">
      <p>Content above the divider</p>
      <Divider />
      <p>Content below the divider</p>
    </div>
  ),
}

export const WithText: Story = {
  render: () => (
    <div className="w-80">
      <p>Section 1 content</p>
      <Divider>OR</Divider>
      <p>Section 2 content</p>
    </div>
  ),
}

export const Vertical: Story = {
  render: () => (
    <div className="flex items-center h-20 space-x-4">
      <span>Left content</span>
      <Divider orientation="vertical" />
      <span>Right content</span>
    </div>
  ),
}

export const InForm: Story = {
  render: () => (
    <div className="w-80 space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">Email</label>
        <input className="w-full px-3 py-2 border rounded-md" type="email" />
      </div>
      
      <Divider>or continue with</Divider>
      
      <div className="flex space-x-2">
        <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded">Google</button>
        <button className="flex-1 px-4 py-2 bg-gray-800 text-white rounded">GitHub</button>
      </div>
    </div>
  ),
}
