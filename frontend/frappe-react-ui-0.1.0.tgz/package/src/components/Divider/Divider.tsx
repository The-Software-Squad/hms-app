import React from 'react'
import { cn } from '../../utils/cn'

export interface DividerProps {
  orientation?: 'horizontal' | 'vertical'
  variant?: 'solid' | 'dashed' | 'dotted'
  thickness?: 'thin' | 'medium' | 'thick'
  color?: 'default' | 'light' | 'dark'
  className?: string
  children?: React.ReactNode
}

export const Divider: React.FC<DividerProps> = ({
  orientation = 'horizontal',
  variant = 'solid',
  thickness = 'thin',
  color = 'default',
  className,
  children,
}) => {
  const isHorizontal = orientation === 'horizontal'
  
  const baseClasses = cn(
    'border-0',
    {
      // Orientation
      'w-full h-px': isHorizontal,
      'h-full w-px': !isHorizontal,
      
      // Variant
      'bg-current': variant === 'solid',
      'border-dashed border-t': variant === 'dashed' && isHorizontal,
      'border-dashed border-l': variant === 'dashed' && !isHorizontal,
      'border-dotted border-t': variant === 'dotted' && isHorizontal,
      'border-dotted border-l': variant === 'dotted' && !isHorizontal,
      
      // Thickness
      'border-t': (variant === 'dashed' || variant === 'dotted') && isHorizontal && thickness === 'thin',
      'border-t-2': (variant === 'dashed' || variant === 'dotted') && isHorizontal && thickness === 'medium',
      'border-t-4': (variant === 'dashed' || variant === 'dotted') && isHorizontal && thickness === 'thick',
      'border-l': (variant === 'dashed' || variant === 'dotted') && !isHorizontal && thickness === 'thin',
      'border-l-2': (variant === 'dashed' || variant === 'dotted') && !isHorizontal && thickness === 'medium',
      'border-l-4': (variant === 'dashed' || variant === 'dotted') && !isHorizontal && thickness === 'thick',
      
      // Color
      'text-outline-gray-2': color === 'default',
      'text-outline-gray-1': color === 'light',
      'text-outline-gray-3': color === 'dark',
    },
    className
  )

  if (children) {
    return (
      <div className={cn(
        'flex items-center',
        isHorizontal ? 'w-full' : 'h-full flex-col'
      )}>
        <div className={baseClasses} />
        <div className={cn(
          'flex-shrink-0 text-sm text-ink-gray-5',
          isHorizontal ? 'px-3' : 'py-3'
        )}>
          {children}
        </div>
        <div className={baseClasses} />
      </div>
    )
  }

  return <div className={baseClasses} />
}
