import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { CommandPalette } from './CommandPalette'
import { 
  Search, 
  Settings, 
  User, 
  Mail, 
  Calendar, 
  FileText, 
  Home, 
  Plus, 
  Edit, 
  Trash2,
  Copy,
  Download,
  Upload,
  Star,
  Heart,
  Bookmark
} from 'lucide-react'

const meta: Meta<typeof CommandPalette> = {
  title: 'Components/CommandPalette',
  component: CommandPalette,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

// Sample commands
const basicCommands = [
  {
    id: 'search',
    label: 'Search',
    description: 'Search through all content',
    icon: <Search className="h-4 w-4" />,
    action: () => alert('Opening search...'),
  },
  {
    id: 'settings',
    label: 'Settings',
    description: 'Open application settings',
    icon: <Settings className="h-4 w-4" />,
    action: () => alert('Opening settings...'),
  },
  {
    id: 'profile',
    label: 'Profile',
    description: 'View your profile',
    icon: <User className="h-4 w-4" />,
    action: () => alert('Opening profile...'),
  },
]

const fullCommands = [
  // Navigation
  {
    id: 'home',
    label: 'Go to Home',
    description: 'Navigate to the home page',
    icon: <Home className="h-4 w-4" />,
    group: 'Navigation',
    keywords: ['dashboard', 'main'],
    action: () => alert('Navigating to home...'),
  },
  {
    id: 'profile',
    label: 'Go to Profile',
    description: 'View and edit your profile',
    icon: <User className="h-4 w-4" />,
    group: 'Navigation',
    keywords: ['user', 'account'],
    action: () => alert('Opening profile...'),
  },
  {
    id: 'settings',
    label: 'Open Settings',
    description: 'Configure application preferences',
    icon: <Settings className="h-4 w-4" />,
    group: 'Navigation',
    keywords: ['config', 'preferences'],
    action: () => alert('Opening settings...'),
  },
  
  // Actions
  {
    id: 'new-document',
    label: 'New Document',
    description: 'Create a new document',
    icon: <Plus className="h-4 w-4" />,
    group: 'Actions',
    keywords: ['create', 'add'],
    action: () => alert('Creating new document...'),
  },
  {
    id: 'edit-document',
    label: 'Edit Document',
    description: 'Edit the current document',
    icon: <Edit className="h-4 w-4" />,
    group: 'Actions',
    keywords: ['modify', 'change'],
    action: () => alert('Editing document...'),
  },
  {
    id: 'delete-document',
    label: 'Delete Document',
    description: 'Delete the current document',
    icon: <Trash2 className="h-4 w-4" />,
    group: 'Actions',
    keywords: ['remove', 'trash'],
    action: () => alert('Deleting document...'),
  },
  
  // Tools
  {
    id: 'copy',
    label: 'Copy to Clipboard',
    description: 'Copy current selection',
    icon: <Copy className="h-4 w-4" />,
    group: 'Tools',
    keywords: ['clipboard'],
    action: () => alert('Copied to clipboard!'),
  },
  {
    id: 'download',
    label: 'Download',
    description: 'Download current file',
    icon: <Download className="h-4 w-4" />,
    group: 'Tools',
    keywords: ['save', 'export'],
    action: () => alert('Starting download...'),
  },
  {
    id: 'upload',
    label: 'Upload File',
    description: 'Upload a new file',
    icon: <Upload className="h-4 w-4" />,
    group: 'Tools',
    keywords: ['import'],
    action: () => alert('Opening file picker...'),
  },
  
  // Favorites
  {
    id: 'favorite',
    label: 'Add to Favorites',
    description: 'Mark as favorite',
    icon: <Star className="h-4 w-4" />,
    group: 'Favorites',
    action: () => alert('Added to favorites!'),
  },
  {
    id: 'like',
    label: 'Like',
    description: 'Like this item',
    icon: <Heart className="h-4 w-4" />,
    group: 'Favorites',
    action: () => alert('Liked!'),
  },
  {
    id: 'bookmark',
    label: 'Bookmark',
    description: 'Save for later',
    icon: <Bookmark className="h-4 w-4" />,
    group: 'Favorites',
    action: () => alert('Bookmarked!'),
  },
]

export const Default: Story = {
  render: () => {
    const [open, setOpen] = useState(false)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={() => setOpen(true)}
        >
          Open Command Palette
        </button>
        
        <CommandPalette
          open={open}
          onOpenChange={setOpen}
          items={basicCommands}
        />
      </div>
    )
  },
}

export const WithGroups: Story = {
  render: () => {
    const [open, setOpen] = useState(false)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={() => setOpen(true)}
        >
          Open Command Palette (Grouped)
        </button>
        
        <CommandPalette
          open={open}
          onOpenChange={setOpen}
          items={fullCommands}
          placeholder="Search commands..."
        />
      </div>
    )
  },
}

export const WithKeyboardShortcut: Story = {
  render: () => {
    const [open, setOpen] = useState(false)
    
    // Handle Cmd+K / Ctrl+K
    React.useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
          e.preventDefault()
          setOpen(true)
        }
      }
      
      document.addEventListener('keydown', handleKeyDown)
      return () => document.removeEventListener('keydown', handleKeyDown)
    }, [])
    
    return (
      <div className="space-y-4">
        <div className="text-center">
          <p className="text-gray-600 mb-4">
            Press <kbd className="px-2 py-1 bg-gray-100 rounded text-sm">⌘K</kbd> or{' '}
            <kbd className="px-2 py-1 bg-gray-100 rounded text-sm">Ctrl+K</kbd> to open
          </p>
          <button 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
            onClick={() => setOpen(true)}
          >
            Or Click Here
          </button>
        </div>
        
        <CommandPalette
          open={open}
          onOpenChange={setOpen}
          items={fullCommands}
          placeholder="Type a command or search... (⌘K)"
        />
      </div>
    )
  },
}

export const CustomStyling: Story = {
  render: () => {
    const [open, setOpen] = useState(false)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
          onClick={() => setOpen(true)}
        >
          Open Custom Palette
        </button>
        
        <CommandPalette
          open={open}
          onOpenChange={setOpen}
          items={fullCommands}
          placeholder="🔍 What would you like to do?"
          emptyMessage="🤷‍♂️ No commands found. Try a different search."
          maxHeight={300}
          className="custom-command-palette"
        />
      </div>
    )
  },
}

export const WithDisabledItems: Story = {
  render: () => {
    const [open, setOpen] = useState(false)
    
    const commandsWithDisabled = [
      ...fullCommands.slice(0, 5),
      {
        id: 'disabled-action',
        label: 'Disabled Action',
        description: 'This action is currently unavailable',
        icon: <Settings className="h-4 w-4" />,
        group: 'Actions',
        disabled: true,
        action: () => alert('This should not fire'),
      },
      ...fullCommands.slice(5),
    ]
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={() => setOpen(true)}
        >
          Open Palette (With Disabled Items)
        </button>
        
        <CommandPalette
          open={open}
          onOpenChange={setOpen}
          items={commandsWithDisabled}
        />
      </div>
    )
  },
}

export const SearchExample: Story = {
  render: () => {
    const [open, setOpen] = useState(false)
    
    const searchCommands = [
      {
        id: 'search-users',
        label: 'Search Users',
        description: 'Find users by name or email',
        icon: <User className="h-4 w-4" />,
        keywords: ['people', 'contacts'],
        action: () => alert('Searching users...'),
      },
      {
        id: 'search-documents',
        label: 'Search Documents',
        description: 'Find documents by title or content',
        icon: <FileText className="h-4 w-4" />,
        keywords: ['files', 'docs'],
        action: () => alert('Searching documents...'),
      },
      {
        id: 'search-emails',
        label: 'Search Emails',
        description: 'Find emails by subject or sender',
        icon: <Mail className="h-4 w-4" />,
        keywords: ['messages', 'inbox'],
        action: () => alert('Searching emails...'),
      },
      {
        id: 'search-calendar',
        label: 'Search Calendar',
        description: 'Find events and meetings',
        icon: <Calendar className="h-4 w-4" />,
        keywords: ['events', 'meetings', 'appointments'],
        action: () => alert('Searching calendar...'),
      },
    ]
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
          onClick={() => setOpen(true)}
        >
          Open Search Palette
        </button>
        
        <CommandPalette
          open={open}
          onOpenChange={setOpen}
          items={searchCommands}
          placeholder="What are you looking for?"
          emptyMessage="No search options found. Try different keywords."
        />
      </div>
    )
  },
}
