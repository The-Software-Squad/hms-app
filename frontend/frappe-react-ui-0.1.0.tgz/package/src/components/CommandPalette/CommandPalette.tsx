import React, { useState, useEffect, useRef } from 'react'
import { Search } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Dialog, DialogContent } from '../Dialog'
import { Input } from '../Input'

export interface CommandItem {
  id: string
  label: string
  description?: string
  icon?: React.ReactNode
  keywords?: string[]
  group?: string
  action: () => void
  disabled?: boolean
}

export interface CommandPaletteProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  items: CommandItem[]
  placeholder?: string
  emptyMessage?: string
  className?: string
  maxHeight?: number
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  open,
  onOpenChange,
  items,
  placeholder = 'Type a command or search...',
  emptyMessage = 'No results found.',
  className,
  maxHeight = 400,
}) => {
  const [query, setQuery] = useState('')
  const [selectedIndex, setSelectedIndex] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const listRef = useRef<HTMLDivElement>(null)

  // Filter items based on query
  const filteredItems = React.useMemo(() => {
    if (!query) return items
    
    const searchTerm = query.toLowerCase()
    return items.filter(item => {
      const labelMatch = item.label.toLowerCase().includes(searchTerm)
      const descriptionMatch = item.description?.toLowerCase().includes(searchTerm)
      const keywordMatch = item.keywords?.some(keyword => 
        keyword.toLowerCase().includes(searchTerm)
      )
      
      return labelMatch || descriptionMatch || keywordMatch
    })
  }, [items, query])

  // Group filtered items
  const groupedItems = React.useMemo(() => {
    const groups: Record<string, CommandItem[]> = {}
    
    filteredItems.forEach(item => {
      const group = item.group || 'Commands'
      if (!groups[group]) {
        groups[group] = []
      }
      groups[group].push(item)
    })
    
    return groups
  }, [filteredItems])

  // Reset selection when items change
  useEffect(() => {
    setSelectedIndex(0)
  }, [filteredItems])

  // Focus input when dialog opens
  useEffect(() => {
    if (open) {
      setQuery('')
      setSelectedIndex(0)
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }, [open])

  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!open) return

      switch (e.key) {
        case 'ArrowDown':
          e.preventDefault()
          setSelectedIndex(prev => 
            prev < filteredItems.length - 1 ? prev + 1 : 0
          )
          break
        case 'ArrowUp':
          e.preventDefault()
          setSelectedIndex(prev => 
            prev > 0 ? prev - 1 : filteredItems.length - 1
          )
          break
        case 'Enter':
          e.preventDefault()
          const selectedItem = filteredItems[selectedIndex]
          if (selectedItem && !selectedItem.disabled) {
            selectedItem.action()
            onOpenChange(false)
          }
          break
        case 'Escape':
          onOpenChange(false)
          break
      }
    }

    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [open, filteredItems, selectedIndex, onOpenChange])

  // Scroll selected item into view
  useEffect(() => {
    if (listRef.current) {
      const selectedElement = listRef.current.children[selectedIndex] as HTMLElement
      if (selectedElement) {
        selectedElement.scrollIntoView({
          block: 'nearest',
          behavior: 'smooth'
        })
      }
    }
  }, [selectedIndex])

  const handleItemClick = (item: CommandItem) => {
    if (!item.disabled) {
      item.action()
      onOpenChange(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className={cn('p-0 overflow-hidden', className)}
        showClose={false}
      >
        <div className="flex items-center border-b border-outline-gray-2 px-3">
          <Search className="mr-2 h-4 w-4 shrink-0 text-ink-gray-5" />
          <Input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={placeholder}
            className="border-0 shadow-none focus:ring-0"
          />
          <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-outline-gray-2 bg-surface-gray-1 px-1.5 font-mono text-[10px] font-medium text-ink-gray-5 ml-auto">
            <span className="text-xs">ESC</span>
          </kbd>
        </div>

        <div 
          ref={listRef}
          className="overflow-y-auto p-1"
          style={{ maxHeight }}
        >
          {Object.keys(groupedItems).length === 0 ? (
            <div className="py-6 text-center text-sm text-ink-gray-5">
              {emptyMessage}
            </div>
          ) : (
            Object.entries(groupedItems).map(([group, groupItems]) => (
              <div key={group} className="mb-2">
                <div className="px-2 py-1.5 text-xs font-medium text-ink-gray-5 uppercase tracking-wider">
                  {group}
                </div>
                {groupItems.map((item, _itemIndex) => {
                  const globalIndex = filteredItems.indexOf(item)
                  const isSelected = globalIndex === selectedIndex
                  
                  return (
                    <button
                      key={item.id}
                      className={cn(
                        'w-full flex items-center px-2 py-2 text-left text-sm rounded-md transition-colors',
                        isSelected && 'bg-surface-blue-2 text-ink-blue-3',
                        !isSelected && 'hover:bg-surface-gray-2',
                        item.disabled && 'opacity-50 cursor-not-allowed'
                      )}
                      onClick={() => handleItemClick(item)}
                      disabled={item.disabled}
                    >
                      {item.icon && (
                        <div className="mr-2 h-4 w-4 shrink-0">
                          {item.icon}
                        </div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="font-medium">{item.label}</div>
                        {item.description && (
                          <div className="text-xs text-ink-gray-5 truncate">
                            {item.description}
                          </div>
                        )}
                      </div>
                      {isSelected && (
                        <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-outline-gray-2 bg-surface-gray-1 px-1.5 font-mono text-[10px] font-medium text-ink-gray-5">
                          <span className="text-xs">↵</span>
                        </kbd>
                      )}
                    </button>
                  )
                })}
              </div>
            ))
          )}
        </div>

        <div className="border-t border-outline-gray-2 px-3 py-2 text-xs text-ink-gray-5">
          <div className="flex items-center justify-between">
            <span>Navigate with ↑↓ arrows</span>
            <div className="flex items-center space-x-2">
              <kbd className="inline-flex h-5 select-none items-center gap-1 rounded border border-outline-gray-2 bg-surface-gray-1 px-1.5 font-mono text-[10px] font-medium">
                ↵
              </kbd>
              <span>to select</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
