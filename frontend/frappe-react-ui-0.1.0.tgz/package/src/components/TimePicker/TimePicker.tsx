import React, { useState, useRef } from 'react'
import { Clock } from 'lucide-react'
// import { cn } from '../../utils/cn' // Unused
import { Input } from '../Input'
import { Popover, PopoverContent, PopoverTrigger } from '../Popover'
import { Button } from '../Button'

export interface TimePickerProps {
  value?: string // Format: "HH:mm" or "HH:mm:ss"
  onChange?: (time: string) => void
  format?: '12' | '24'
  showSeconds?: boolean
  disabled?: boolean
  label?: string
  error?: string
  helperText?: string
  required?: boolean
  placeholder?: string
  className?: string
  step?: number // Minutes step
}

export const TimePicker: React.FC<TimePickerProps> = ({
  value,
  onChange,
  format = '24',
  showSeconds = false,
  disabled = false,
  label,
  error,
  helperText,
  required = false,
  placeholder = 'Select time',
  className,
  step = 15,
}) => {
  const [open, setOpen] = useState(false)
  const [inputValue, setInputValue] = useState(value || '')
  const inputRef = useRef<HTMLInputElement>(null)

  // Parse time string to components
  const parseTime = (timeStr: string) => {
    if (!timeStr) return { hours: 0, minutes: 0, seconds: 0, period: 'AM' }
    
    const [time, period] = timeStr.split(' ')
    const [hours, minutes, seconds = '0'] = time.split(':')
    
    return {
      hours: parseInt(hours) || 0,
      minutes: parseInt(minutes) || 0,
      seconds: parseInt(seconds) || 0,
      period: period || 'AM'
    }
  }

  // Format time components to string
  const formatTime = (hours: number, minutes: number, seconds: number, period?: string) => {
    const h = format === '12' ? (hours === 0 ? 12 : hours > 12 ? hours - 12 : hours) : hours
    const m = minutes.toString().padStart(2, '0')
    const s = seconds.toString().padStart(2, '0')
    const hStr = h.toString().padStart(2, '0')
    
    let timeStr = `${hStr}:${m}`
    if (showSeconds) timeStr += `:${s}`
    if (format === '12') timeStr += ` ${period}`
    
    return timeStr
  }

  const { hours, minutes, seconds, period } = parseTime(inputValue)

  // Generate hour options
  const hourOptions = format === '12' 
    ? Array.from({ length: 12 }, (_, i) => i + 1)
    : Array.from({ length: 24 }, (_, i) => i)

  // Generate minute options based on step
  const minuteOptions = Array.from({ length: 60 / step }, (_, i) => i * step)

  // Generate second options
  const secondOptions = Array.from({ length: 60 }, (_, i) => i)

  const handleTimeChange = (newHours: number, newMinutes: number, newSeconds: number, newPeriod: string) => {
    let adjustedHours = newHours
    
    if (format === '12') {
      if (newPeriod === 'PM' && newHours !== 12) {
        adjustedHours = newHours + 12
      } else if (newPeriod === 'AM' && newHours === 12) {
        adjustedHours = 0
      }
    }
    
    const timeString = formatTime(adjustedHours, newMinutes, newSeconds, newPeriod)
    setInputValue(timeString)
    onChange?.(timeString)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value
    setInputValue(newValue)
    
    // Validate and parse input
    const timeRegex = format === '12' 
      ? /^(0?[1-9]|1[0-2]):([0-5]?[0-9])(?::([0-5]?[0-9]))?\s?(AM|PM)$/i
      : /^([01]?[0-9]|2[0-3]):([0-5]?[0-9])(?::([0-5]?[0-9]))?$/
    
    if (timeRegex.test(newValue)) {
      onChange?.(newValue)
    }
  }

  const handleInputBlur = () => {
    // Try to format the input value
    const parsed = parseTime(inputValue)
    const formatted = formatTime(parsed.hours, parsed.minutes, parsed.seconds, parsed.period)
    setInputValue(formatted)
  }

  return (
    <div className={className}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <div>
            <Input
              ref={inputRef}
              label={label}
              value={inputValue}
              onChange={handleInputChange}
              onBlur={handleInputBlur}
              placeholder={placeholder}
              error={error}
              helperText={helperText}
              required={required}
              disabled={disabled}
              iconRight={<Clock className="h-4 w-4" />}
            />
          </div>
        </PopoverTrigger>
        
        <PopoverContent className="w-auto p-4" align="start">
          <div className="space-y-4">
            <div className="text-sm font-medium text-ink-gray-8">Select Time</div>
            
            <div className="flex items-center space-x-2">
              {/* Hours */}
              <div className="space-y-1">
                <label className="text-xs text-ink-gray-6">Hour</label>
                <select
                  value={format === '12' ? (hours === 0 ? 12 : hours > 12 ? hours - 12 : hours) : hours}
                  onChange={(e) => {
                    const newHours = parseInt(e.target.value)
                    handleTimeChange(newHours, minutes, seconds, period)
                  }}
                  className="w-16 px-2 py-1 border border-outline-gray-2 rounded text-sm"
                >
                  {hourOptions.map(hour => (
                    <option key={hour} value={hour}>
                      {hour.toString().padStart(2, '0')}
                    </option>
                  ))}
                </select>
              </div>
              
              <span className="text-ink-gray-5 mt-5">:</span>
              
              {/* Minutes */}
              <div className="space-y-1">
                <label className="text-xs text-ink-gray-6">Min</label>
                <select
                  value={minutes}
                  onChange={(e) => {
                    const newMinutes = parseInt(e.target.value)
                    handleTimeChange(hours, newMinutes, seconds, period)
                  }}
                  className="w-16 px-2 py-1 border border-outline-gray-2 rounded text-sm"
                >
                  {minuteOptions.map(minute => (
                    <option key={minute} value={minute}>
                      {minute.toString().padStart(2, '0')}
                    </option>
                  ))}
                </select>
              </div>
              
              {showSeconds && (
                <>
                  <span className="text-ink-gray-5 mt-5">:</span>
                  
                  {/* Seconds */}
                  <div className="space-y-1">
                    <label className="text-xs text-ink-gray-6">Sec</label>
                    <select
                      value={seconds}
                      onChange={(e) => {
                        const newSeconds = parseInt(e.target.value)
                        handleTimeChange(hours, minutes, newSeconds, period)
                      }}
                      className="w-16 px-2 py-1 border border-outline-gray-2 rounded text-sm"
                    >
                      {secondOptions.map(second => (
                        <option key={second} value={second}>
                          {second.toString().padStart(2, '0')}
                        </option>
                      ))}
                    </select>
                  </div>
                </>
              )}
              
              {format === '12' && (
                <div className="space-y-1">
                  <label className="text-xs text-ink-gray-6">Period</label>
                  <select
                    value={period}
                    onChange={(e) => {
                      const newPeriod = e.target.value
                      handleTimeChange(hours, minutes, seconds, newPeriod)
                    }}
                    className="w-16 px-2 py-1 border border-outline-gray-2 rounded text-sm"
                  >
                    <option value="AM">AM</option>
                    <option value="PM">PM</option>
                  </select>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="solid"
                theme="blue"
                size="sm"
                onClick={() => setOpen(false)}
              >
                Done
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
