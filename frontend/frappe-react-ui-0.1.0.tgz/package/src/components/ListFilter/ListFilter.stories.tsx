import type { Meta, StoryObj } from '@storybook/react'
import { ListFilter, FilterField, FilterCondition } from './ListFilter'
import { useState } from 'react'

const meta: Meta<typeof ListFilter> = {
  title: 'Components/ListFilter',
  component: ListFilter,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

const sampleFields: FilterField[] = [
  { label: 'Name', value: 'name', fieldtype: 'Data' },
  { label: 'Email', value: 'email', fieldtype: 'Data' },
  { label: 'Status', value: 'status', fieldtype: 'Select' },
  { label: 'Created Date', value: 'creation', fieldtype: 'Date' },
  { label: 'Modified Date', value: 'modified', fieldtype: 'Datetime' },
  { label: 'Age', value: 'age', fieldtype: 'Int' },
  { label: 'Salary', value: 'salary', fieldtype: 'Currency' },
  { label: 'Department', value: 'department', fieldtype: 'Link', options: 'Department' },
]

export const Default: Story = {
  render: () => {
    const [filters, setFilters] = useState<FilterCondition[]>([])
    
    return (
      <div className="w-full max-w-2xl">
        <ListFilter
          fields={sampleFields}
          filters={filters}
          onFiltersChange={setFilters}
        />
        
        {filters.length > 0 && (
          <div className="mt-4 p-4 bg-gray-50 rounded">
            <h3 className="font-semibold mb-2">Current Filters:</h3>
            <pre className="text-sm">
              {JSON.stringify(filters, null, 2)}
            </pre>
          </div>
        )}
      </div>
    )
  },
}

export const WithInitialFilters: Story = {
  render: () => {
    const [filters, setFilters] = useState<FilterCondition[]>([
      {
        fieldname: 'status',
        operator: '=',
        value: 'Active',
        field: sampleFields.find(f => f.value === 'status'),
      },
      {
        fieldname: 'age',
        operator: '>=',
        value: '18',
        field: sampleFields.find(f => f.value === 'age'),
      },
    ])
    
    return (
      <div className="w-full max-w-2xl">
        <ListFilter
          fields={sampleFields}
          filters={filters}
          onFiltersChange={setFilters}
        />
        
        <div className="mt-4 p-4 bg-gray-50 rounded">
          <h3 className="font-semibold mb-2">Current Filters:</h3>
          <pre className="text-sm">
            {JSON.stringify(filters, null, 2)}
          </pre>
        </div>
      </div>
    )
  },
}

export const SimpleFields: Story = {
  render: () => {
    const simpleFields: FilterField[] = [
      { label: 'Title', value: 'title' },
      { label: 'Description', value: 'description' },
      { label: 'Priority', value: 'priority' },
    ]
    
    const [filters, setFilters] = useState<FilterCondition[]>([])
    
    return (
      <ListFilter
        fields={simpleFields}
        filters={filters}
        onFiltersChange={setFilters}
      />
    )
  },
}
