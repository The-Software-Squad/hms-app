import React, { useState } from 'react'
import { Filter, X } from 'lucide-react'
import { cn } from '../../utils/cn'

export interface FilterField {
  label: string
  value: string
  fieldtype?: string
  options?: string
}

export interface FilterCondition {
  fieldname: string
  operator: string
  value: any
  field?: FilterField
}

export interface ListFilterProps {
  fields: FilterField[]
  filters: FilterCondition[]
  onFiltersChange: (filters: FilterCondition[]) => void
  className?: string
}

const ListFilter: React.FC<ListFilterProps> = ({
  fields,
  filters,
  onFiltersChange,
  className,
}) => {
  const [isOpen, setIsOpen] = useState(false)

  const getOperators = (fieldtype?: string) => {
    const baseOperators = [
      { label: 'Equals', value: '=' },
      { label: 'Not Equals', value: '!=' },
      { label: 'Like', value: 'like' },
      { label: 'Not Like', value: 'not like' },
    ]

    if (['Int', 'Float', 'Currency', 'Date', 'Datetime'].includes(fieldtype || '')) {
      return [
        ...baseOperators,
        { label: 'Greater Than', value: '>' },
        { label: 'Less Than', value: '<' },
        { label: 'Greater Than or Equal', value: '>=' },
        { label: 'Less Than or Equal', value: '<=' },
      ]
    }

    return baseOperators
  }

  const addFilter = (fieldname: string) => {
    const field = fields.find(f => f.value === fieldname)
    if (!field) return

    const newFilter: FilterCondition = {
      fieldname,
      operator: '=',
      value: '',
      field,
    }

    onFiltersChange([...filters, newFilter])
  }

  const removeFilter = (index: number) => {
    const newFilters = filters.filter((_, i) => i !== index)
    onFiltersChange(newFilters)
  }

  const updateFilter = (index: number, updates: Partial<FilterCondition>) => {
    const newFilters = filters.map((filter, i) => 
      i === index ? { ...filter, ...updates } : filter
    )
    onFiltersChange(newFilters)
  }

  return (
    <div className="relative">
      <button
        className={cn(
          'inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500',
          className
        )}
        onClick={() => setIsOpen(!isOpen)}
      >
        <Filter className="h-4 w-4 mr-2" />
        Filter
        {filters.length > 0 && (
          <div className="ml-2 flex h-5 w-5 items-center justify-center rounded bg-blue-600 text-xs font-medium text-white">
            {filters.length}
          </div>
        )}
      </button>
      
      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-[500px] p-4 bg-white border border-gray-200 rounded-lg shadow-lg z-10">
          <div className="space-y-3">
            {filters.length > 0 ? (
              filters.map((filter, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-12 flex-shrink-0 text-sm text-gray-500">
                    {i === 0 ? 'Where' : 'And'}
                  </div>
                  
                  <select
                    className="min-w-[120px] flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm"
                    value={filter.fieldname}
                    onChange={(e) => {
                      const field = fields.find(f => f.value === e.target.value)
                      updateFilter(i, { fieldname: e.target.value, field })
                    }}
                  >
                    <option value="">Filter by...</option>
                    {fields.map(field => (
                      <option key={field.value} value={field.value}>
                        {field.label}
                      </option>
                    ))}
                  </select>
                  
                  <select
                    className="min-w-[120px] px-3 py-2 border border-gray-300 rounded-md text-sm"
                    value={filter.operator}
                    onChange={(e) => updateFilter(i, { operator: e.target.value })}
                  >
                    {getOperators(filter.field?.fieldtype).map(op => (
                      <option key={op.value} value={op.value}>
                        {op.label}
                      </option>
                    ))}
                  </select>
                  
                  <input
                    type="text"
                    className="min-w-[120px] flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm"
                    value={filter.value}
                    onChange={(e) => updateFilter(i, { value: e.target.value })}
                    placeholder="Value"
                  />
                  
                  <button
                    className="p-2 text-gray-400 hover:text-gray-600"
                    onClick={() => removeFilter(i)}
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))
            ) : (
              <div className="flex h-8 items-center px-3 text-sm text-gray-500">
                Empty - Choose a field to filter by
              </div>
            )}
            
            <div className="flex items-center justify-between pt-2 border-t">
              <select
                className="px-3 py-2 border border-gray-300 rounded-md text-sm"
                value=""
                onChange={(e) => e.target.value && addFilter(e.target.value)}
              >
                <option value="">Add filter...</option>
                {fields.map(field => (
                  <option key={field.value} value={field.value}>
                    {field.label}
                  </option>
                ))}
              </select>
              
              {filters.length > 0 && (
                <button
                  className="px-3 py-2 text-sm text-gray-500 hover:text-gray-700"
                  onClick={() => onFiltersChange([])}
                >
                  Clear all
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export { ListFilter }
