import type { Meta, StoryObj } from '@storybook/react'
import { Textarea } from './Textarea'
import { useState } from 'react'

const meta: Meta<typeof Textarea> = {
  title: 'Components/Textarea',
  component: Textarea,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    resize: {
      control: 'select',
      options: ['none', 'vertical', 'horizontal', 'both'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    placeholder: 'Enter your message...',
  },
}

export const WithLabel: Story = {
  args: {
    label: 'Message',
    placeholder: 'Enter your message...',
  },
}

export const WithHelperText: Story = {
  args: {
    label: 'Description',
    placeholder: 'Enter description...',
    helperText: 'Provide a detailed description of the item.',
  },
}

export const WithError: Story = {
  args: {
    label: 'Comments',
    placeholder: 'Enter comments...',
    error: 'This field is required',
    value: '',
  },
}

export const Required: Story = {
  args: {
    label: 'Required Field',
    placeholder: 'This field is required...',
    required: true,
  },
}

export const Disabled: Story = {
  args: {
    label: 'Disabled Textarea',
    placeholder: 'This is disabled',
    disabled: true,
    value: 'This content cannot be edited',
  },
}

export const ResizeOptions: Story = {
  render: () => (
    <div className="space-y-4 w-80">
      <Textarea
        label="No Resize"
        resize="none"
        placeholder="Cannot be resized"
      />
      <Textarea
        label="Vertical Resize"
        resize="vertical"
        placeholder="Can be resized vertically"
      />
      <Textarea
        label="Horizontal Resize"
        resize="horizontal"
        placeholder="Can be resized horizontally"
      />
      <Textarea
        label="Both Directions"
        resize="both"
        placeholder="Can be resized in both directions"
      />
    </div>
  ),
}

export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState('')
    
    return (
      <div className="space-y-4 w-80">
        <Textarea
          label="Controlled Textarea"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Type something..."
          helperText={`Character count: ${value.length}`}
        />
        <button
          onClick={() => setValue('')}
          className="px-3 py-1 bg-blue-500 text-white rounded text-sm"
        >
          Clear
        </button>
      </div>
    )
  },
}
