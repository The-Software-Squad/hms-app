import { ComponentProps, ReactNode } from 'react'

export type Theme = 'gray' | 'blue' | 'green' | 'red'
export type Size = 'sm' | 'md' | 'lg' | 'xl' | '2xl'
export type Variant = 'solid' | 'subtle' | 'outline' | 'ghost'

export interface ButtonProps extends ComponentProps<'button'> {
  theme?: Theme
  size?: Size
  variant?: Variant
  label?: string
  icon?: ReactNode
  iconLeft?: ReactNode
  iconRight?: ReactNode
  tooltip?: string
  loading?: boolean
  loadingText?: string
  disabled?: boolean
  route?: string
  link?: string
  asChild?: boolean
}

export type ThemeVariant = `${Theme}-${Variant}`
