import type { Meta, StoryObj } from '@storybook/react'
import { fn } from '@storybook/test'
import { Button } from './Button'
import { Heart, Download, Plus } from 'lucide-react'

const meta: Meta<typeof Button> = {
  title: 'Components/Button',
  component: Button,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['solid', 'subtle', 'outline', 'ghost'],
    },
    theme: {
      control: 'select',
      options: ['gray', 'blue', 'green', 'red'],
    },
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg', 'xl', '2xl'],
    },
    onClick: { action: 'clicked' },
  },
  args: {
    onClick: fn(),
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    children: 'Button',
  },
}

export const Primary: Story = {
  args: {
    variant: 'solid',
    theme: 'blue',
    children: 'Primary Button',
  },
}

export const Secondary: Story = {
  args: {
    variant: 'outline',
    theme: 'gray',
    children: 'Secondary Button',
  },
}

export const Destructive: Story = {
  args: {
    variant: 'solid',
    theme: 'red',
    children: 'Delete',
  },
}

export const Success: Story = {
  args: {
    variant: 'solid',
    theme: 'green',
    children: 'Success',
  },
}

export const Ghost: Story = {
  args: {
    variant: 'ghost',
    children: 'Ghost Button',
  },
}

export const WithIcon: Story = {
  args: {
    variant: 'solid',
    theme: 'blue',
    iconLeft: <Download className="h-4 w-4" />,
    children: 'Download',
  },
}

export const IconOnly: Story = {
  args: {
    variant: 'outline',
    icon: <Heart className="h-4 w-4" />,
    label: 'Like',
  },
}

export const Loading: Story = {
  args: {
    variant: 'solid',
    theme: 'blue',
    loading: true,
    children: 'Loading...',
  },
}

export const LoadingWithText: Story = {
  args: {
    variant: 'solid',
    theme: 'blue',
    loading: true,
    loadingText: 'Saving...',
    children: 'Save',
  },
}

export const Disabled: Story = {
  args: {
    variant: 'solid',
    theme: 'blue',
    disabled: true,
    children: 'Disabled',
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <Button size="sm">Small</Button>
      <Button size="md">Medium</Button>
      <Button size="lg">Large</Button>
      <Button size="xl">Extra Large</Button>
      <Button size="2xl">2X Large</Button>
    </div>
  ),
}

export const Variants: Story = {
  render: () => (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <Button variant="solid" theme="blue">Solid</Button>
        <Button variant="subtle" theme="blue">Subtle</Button>
        <Button variant="outline" theme="blue">Outline</Button>
        <Button variant="ghost" theme="blue">Ghost</Button>
      </div>
      <div className="flex items-center gap-4">
        <Button variant="solid" theme="green">Success</Button>
        <Button variant="solid" theme="red">Danger</Button>
        <Button variant="solid" theme="gray">Gray</Button>
      </div>
    </div>
  ),
}

export const WithTooltip: Story = {
  args: {
    variant: 'outline',
    tooltip: 'This is a helpful tooltip',
    children: 'Hover me',
  },
}
