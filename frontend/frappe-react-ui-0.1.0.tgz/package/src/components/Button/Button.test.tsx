import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { Button } from './Button'

// Mock react-router-dom
const mockNavigate = vi.fn()
vi.mock('react-router-dom', () => ({
  useNavigate: () => mockNavigate,
}))

describe('Button', () => {
  it('renders correctly', () => {
    render(<Button>Click me</Button>)
    expect(screen.getByRole('button', { name: /click me/i })).toBeInTheDocument()
  })

  it('applies correct variant classes', () => {
    render(<Button variant="solid" theme="blue">Solid Button</Button>)
    const button = screen.getByRole('button')
    expect(button).toHaveClass('bg-blue-500')
  })

  it('shows loading state', () => {
    render(<Button loading>Loading Button</Button>)
    const button = screen.getByRole('button')
    expect(button).toBeDisabled()
    expect(screen.getByRole('status', { name: /loading/i })).toBeInTheDocument()
  })

  it('handles click events', () => {
    const handleClick = vi.fn()
    render(<Button onClick={handleClick}>Click me</Button>)
    
    fireEvent.click(screen.getByRole('button'))
    expect(handleClick).toHaveBeenCalledTimes(1)
  })

  it('navigates when route prop is provided', () => {
    render(<Button route="/test">Navigate</Button>)
    
    fireEvent.click(screen.getByRole('button'))
    expect(mockNavigate).toHaveBeenCalledWith('/test')
  })

  it('opens link when link prop is provided', () => {
    const originalOpen = window.open
    window.open = vi.fn()
    
    render(<Button link="https://example.com">Open Link</Button>)
    
    fireEvent.click(screen.getByRole('button'))
    expect(window.open).toHaveBeenCalledWith('https://example.com', '_blank')
    
    window.open = originalOpen
  })

  it('is disabled when disabled prop is true', () => {
    render(<Button disabled>Disabled Button</Button>)
    expect(screen.getByRole('button')).toBeDisabled()
  })

  it('renders with different sizes', () => {
    const { rerender } = render(<Button size="sm">Small</Button>)
    expect(screen.getByRole('button')).toHaveClass('h-7')
    
    rerender(<Button size="lg">Large</Button>)
    expect(screen.getByRole('button')).toHaveClass('h-10')
  })

  it('renders icon button correctly', () => {
    render(<Button icon={<span data-testid="icon">Icon</span>} label="Icon Button" />)
    const button = screen.getByRole('button')
    expect(button).toHaveAttribute('aria-label', 'Icon Button')
    expect(screen.getByTestId('icon')).toBeInTheDocument()
  })

  it('shows tooltip when provided', () => {
    render(<Button tooltip="This is a tooltip">Hover me</Button>)
    // Note: Testing tooltip visibility would require more complex setup
    // This test just ensures the component renders without error
    expect(screen.getByRole('button')).toBeInTheDocument()
  })

  it('renders loading text when loading', () => {
    render(<Button loading loadingText="Saving...">Save</Button>)
    expect(screen.getByText('Saving...')).toBeInTheDocument()
  })
})
