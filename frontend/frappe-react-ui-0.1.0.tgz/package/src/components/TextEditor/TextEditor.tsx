import React, { useEffect } from 'react'
import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Placeholder from '@tiptap/extension-placeholder'
import Link from '@tiptap/extension-link'
import Image from '@tiptap/extension-image'
import Table from '@tiptap/extension-table'
import TableRow from '@tiptap/extension-table-row'
import TableHeader from '@tiptap/extension-table-header'
import TableCell from '@tiptap/extension-table-cell'
import TextAlign from '@tiptap/extension-text-align'
import Highlight from '@tiptap/extension-highlight'
import Typography from '@tiptap/extension-typography'
import { 
  Bold, 
  Italic, 
  Underline, 
  Strikethrough, 
  Code, 
  Link as LinkIcon,
  Image as ImageIcon,
  List,
  ListOrdered,
  Quote,
  Undo,
  Redo,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Table as TableIcon
} from 'lucide-react'
import { cn } from '../../utils/cn'
import { Button } from '../Button'
import { Tooltip } from '../Tooltip'

export interface TextEditorProps {
  content?: string
  onChange?: (content: string) => void
  placeholder?: string
  editable?: boolean
  className?: string
  label?: string
  error?: string
  helperText?: string
  required?: boolean
  minHeight?: number
  maxHeight?: number
  showToolbar?: boolean
  toolbarItems?: string[]
}

export const TextEditor: React.FC<TextEditorProps> = ({
  content = '',
  onChange,
  placeholder = 'Start typing...',
  editable = true,
  className,
  label,
  error,
  helperText,
  required = false,
  minHeight = 200,
  maxHeight,
  showToolbar = true,
  toolbarItems = [
    'bold',
    'italic',
    'underline',
    'strikethrough',
    'code',
    '|',
    'link',
    'image',
    '|',
    'bulletList',
    'orderedList',
    'blockquote',
    '|',
    'alignLeft',
    'alignCenter',
    'alignRight',
    '|',
    'table',
    '|',
    'undo',
    'redo'
  ],
}) => {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Placeholder.configure({
        placeholder,
      }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: {
          class: 'text-blue-500 underline',
        },
      }),
      Image.configure({
        HTMLAttributes: {
          class: 'max-w-full h-auto rounded-lg',
        },
      }),
      Table.configure({
        resizable: true,
      }),
      TableRow,
      TableHeader,
      TableCell,
      TextAlign.configure({
        types: ['heading', 'paragraph'],
      }),
      Highlight.configure({
        multicolor: true,
      }),
      Typography,
    ],
    content,
    editable,
    onUpdate: ({ editor }) => {
      onChange?.(editor.getHTML())
    },
  })

  useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      editor.commands.setContent(content)
    }
  }, [content, editor])

  if (!editor) {
    return null
  }

  const ToolbarButton: React.FC<{
    onClick: () => void
    isActive?: boolean
    disabled?: boolean
    icon: React.ReactNode
    tooltip: string
  }> = ({ onClick, isActive, disabled, icon, tooltip }) => (
    <Tooltip content={tooltip}>
      <Button
        variant={isActive ? 'solid' : 'ghost'}
        size="sm"
        onClick={onClick}
        disabled={disabled}
        className="h-8 w-8 p-0"
      >
        {icon}
      </Button>
    </Tooltip>
  )

  const Separator = () => <div className="w-px h-6 bg-outline-gray-2 mx-1" />

  const renderToolbarItem = (item: string) => {
    switch (item) {
      case '|':
        return <Separator key={item} />
      case 'bold':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleBold().run()}
            isActive={editor.isActive('bold')}
            icon={<Bold className="h-4 w-4" />}
            tooltip="Bold"
          />
        )
      case 'italic':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleItalic().run()}
            isActive={editor.isActive('italic')}
            icon={<Italic className="h-4 w-4" />}
            tooltip="Italic"
          />
        )
      case 'underline':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleMark('underline').run()}
            isActive={editor.isActive('underline')}
            icon={<Underline className="h-4 w-4" />}
            tooltip="Underline"
          />
        )
      case 'strikethrough':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleStrike().run()}
            isActive={editor.isActive('strike')}
            icon={<Strikethrough className="h-4 w-4" />}
            tooltip="Strikethrough"
          />
        )
      case 'code':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleCode().run()}
            isActive={editor.isActive('code')}
            icon={<Code className="h-4 w-4" />}
            tooltip="Inline Code"
          />
        )
      case 'link':
        return (
          <ToolbarButton
            key={item}
            onClick={() => {
              const url = window.prompt('Enter URL:')
              if (url) {
                editor.chain().focus().setLink({ href: url }).run()
              }
            }}
            isActive={editor.isActive('link')}
            icon={<LinkIcon className="h-4 w-4" />}
            tooltip="Add Link"
          />
        )
      case 'image':
        return (
          <ToolbarButton
            key={item}
            onClick={() => {
              const url = window.prompt('Enter image URL:')
              if (url) {
                editor.chain().focus().setImage({ src: url }).run()
              }
            }}
            icon={<ImageIcon className="h-4 w-4" />}
            tooltip="Add Image"
          />
        )
      case 'bulletList':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleBulletList().run()}
            isActive={editor.isActive('bulletList')}
            icon={<List className="h-4 w-4" />}
            tooltip="Bullet List"
          />
        )
      case 'orderedList':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleOrderedList().run()}
            isActive={editor.isActive('orderedList')}
            icon={<ListOrdered className="h-4 w-4" />}
            tooltip="Numbered List"
          />
        )
      case 'blockquote':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().toggleBlockquote().run()}
            isActive={editor.isActive('blockquote')}
            icon={<Quote className="h-4 w-4" />}
            tooltip="Quote"
          />
        )
      case 'alignLeft':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().setTextAlign('left').run()}
            isActive={editor.isActive({ textAlign: 'left' })}
            icon={<AlignLeft className="h-4 w-4" />}
            tooltip="Align Left"
          />
        )
      case 'alignCenter':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().setTextAlign('center').run()}
            isActive={editor.isActive({ textAlign: 'center' })}
            icon={<AlignCenter className="h-4 w-4" />}
            tooltip="Align Center"
          />
        )
      case 'alignRight':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().setTextAlign('right').run()}
            isActive={editor.isActive({ textAlign: 'right' })}
            icon={<AlignRight className="h-4 w-4" />}
            tooltip="Align Right"
          />
        )
      case 'table':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run()}
            icon={<TableIcon className="h-4 w-4" />}
            tooltip="Insert Table"
          />
        )
      case 'undo':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().undo().run()}
            disabled={!editor.can().undo()}
            icon={<Undo className="h-4 w-4" />}
            tooltip="Undo"
          />
        )
      case 'redo':
        return (
          <ToolbarButton
            key={item}
            onClick={() => editor.chain().focus().redo().run()}
            disabled={!editor.can().redo()}
            icon={<Redo className="h-4 w-4" />}
            tooltip="Redo"
          />
        )
      default:
        return null
    }
  }

  return (
    <div className={cn('space-y-2', className)}>
      {label && (
        <label className="block text-sm font-medium text-ink-gray-8">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div
        className={cn(
          'border border-outline-gray-2 rounded-lg overflow-hidden',
          error && 'border-red-500',
          !editable && 'bg-surface-gray-1'
        )}
      >
        {showToolbar && editable && (
          <div className="border-b border-outline-gray-1 p-2 bg-surface-gray-1">
            <div className="flex items-center gap-1 flex-wrap">
              {toolbarItems.map((item, index) => (
                <React.Fragment key={`${item}-${index}`}>
                  {renderToolbarItem(item)}
                </React.Fragment>
              ))}
            </div>
          </div>
        )}

        <div
          className="prose prose-sm max-w-none p-4 focus-within:outline-none"
          style={{
            minHeight,
            maxHeight,
            overflowY: maxHeight ? 'auto' : 'visible',
          }}
        >
          <EditorContent editor={editor} />
        </div>
      </div>

      {(error || helperText) && (
        <p className={cn(
          'text-sm',
          error ? 'text-red-600' : 'text-ink-gray-5'
        )}>
          {error || helperText}
        </p>
      )}
    </div>
  )
}
