import React, { forwardRef, ReactNode } from 'react'
import { cn } from '../../utils/cn'

export interface TextInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size' | 'prefix'> {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  variant?: 'subtle' | 'outline' | 'ghost'
  debounce?: number
  prefix?: ReactNode
  suffix?: ReactNode
}

const TextInput = forwardRef<HTMLInputElement, TextInputProps>(
  ({ 
    size = 'sm', 
    variant = 'subtle', 
    disabled, 
    className, 
    prefix, 
    suffix, 
    debounce,
    onChange,
    ...props 
  }, ref) => {
    const textColor = disabled ? 'text-ink-gray-5' : 'text-ink-gray-8'

    const sizeClasses = {
      sm: 'text-base rounded h-7',
      md: 'text-base rounded h-8',
      lg: 'text-lg rounded-md h-10',
      xl: 'text-xl rounded-md h-10',
    }[size]

    const paddingClasses = {
      sm: [
        'py-1.5',
        prefix ? 'pl-8' : 'pl-2',
        suffix ? 'pr-8' : 'pr-2',
      ],
      md: [
        'py-1.5',
        prefix ? 'pl-9' : 'pl-2.5',
        suffix ? 'pr-9' : 'pr-2.5',
      ],
      lg: [
        'py-1.5',
        prefix ? 'pl-10' : 'pl-3',
        suffix ? 'pr-10' : 'pr-3',
      ],
      xl: [
        'py-1.5',
        prefix ? 'pl-10' : 'pl-3',
        suffix ? 'pr-10' : 'pr-3',
      ],
    }[size]

    const currentVariant = disabled ? 'disabled' : variant
    const variantClasses = {
      subtle:
        'border border-[--surface-gray-2] bg-surface-gray-2 placeholder-ink-gray-4 hover:border-outline-gray-modals hover:bg-surface-gray-3 focus:bg-surface-white focus:border-outline-gray-4 focus:shadow-sm focus:ring-0 focus-visible:ring-2 focus-visible:ring-outline-gray-3',
      outline:
        'border border-outline-gray-2 bg-surface-white placeholder-ink-gray-4 hover:border-outline-gray-3 hover:shadow-sm focus:bg-surface-white focus:border-outline-gray-4 focus:shadow-sm focus:ring-0 focus-visible:ring-2 focus-visible:ring-outline-gray-3',
      disabled: [
        'border bg-surface-gray-1 placeholder-ink-gray-3',
        variant === 'outline' ? 'border-outline-gray-2' : 'border-transparent',
      ],
      ghost: 'border-0 focus:ring-0 focus-visible:ring-0',
    }[currentVariant]

    const prefixClasses = {
      sm: 'pl-2',
      md: 'pl-2.5',
      lg: 'pl-3',
      xl: 'pl-3',
    }[size]

    const suffixClasses = {
      sm: 'pr-2',
      md: 'pr-2.5',
      lg: 'pr-3',
      xl: 'pr-3',
    }[size]

    const inputClasses = cn(
      sizeClasses,
      paddingClasses,
      variantClasses,
      textColor,
      'transition-colors w-full dark:[color-scheme:dark]',
      className
    )

    // Handle debounced onChange
    const handleChange = React.useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
      if (onChange) {
        if (debounce) {
          // Simple debounce implementation
          const timeoutId = setTimeout(() => {
            onChange(e)
          }, debounce)
          return () => clearTimeout(timeoutId)
        } else {
          onChange(e)
        }
      }
    }, [onChange, debounce])

    return (
      <div className="relative flex items-center">
        {prefix && (
          <div className={cn(
            'absolute inset-y-0 left-0 flex items-center',
            textColor,
            prefixClasses
          )}>
            {prefix}
          </div>
        )}
        <input
          ref={ref}
          className={inputClasses}
          disabled={disabled}
          onChange={handleChange}
          {...props}
        />
        {suffix && (
          <div className={cn(
            'absolute inset-y-0 right-0 flex items-center',
            textColor,
            suffixClasses
          )}>
            {suffix}
          </div>
        )}
      </div>
    )
  }
)

TextInput.displayName = 'TextInput'

export { TextInput }
