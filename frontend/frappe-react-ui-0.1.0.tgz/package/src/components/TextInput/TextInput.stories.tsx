import type { Meta, StoryObj } from '@storybook/react'
import { TextInput } from './TextInput'
import { Search, User } from 'lucide-react'

const meta: Meta<typeof TextInput> = {
  title: 'Components/TextInput',
  component: TextInput,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: { type: 'select' },
      options: ['sm', 'md', 'lg', 'xl'],
    },
    variant: {
      control: { type: 'select' },
      options: ['subtle', 'outline', 'ghost'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    placeholder: 'Enter text...',
  },
}

export const WithPrefix: Story = {
  args: {
    placeholder: 'Search...',
    prefix: <Search size={16} />,
  },
}

export const WithSuffix: Story = {
  args: {
    placeholder: 'Username',
    suffix: <User size={16} />,
  },
}

export const WithPrefixAndSuffix: Story = {
  args: {
    placeholder: 'Search users...',
    prefix: <Search size={16} />,
    suffix: <User size={16} />,
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="space-y-4">
      <TextInput size="sm" placeholder="Small" />
      <TextInput size="md" placeholder="Medium" />
      <TextInput size="lg" placeholder="Large" />
      <TextInput size="xl" placeholder="Extra Large" />
    </div>
  ),
}

export const Variants: Story = {
  render: () => (
    <div className="space-y-4">
      <TextInput variant="subtle" placeholder="Subtle variant" />
      <TextInput variant="outline" placeholder="Outline variant" />
      <TextInput variant="ghost" placeholder="Ghost variant" />
    </div>
  ),
}

export const Disabled: Story = {
  args: {
    placeholder: 'Disabled input',
    disabled: true,
  },
}
