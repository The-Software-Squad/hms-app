import React from 'react'
import { cn } from '../../utils/cn'

export interface FormLabelProps extends React.LabelHTMLAttributes<HTMLLabelElement> {
  label: string
  size?: 'sm' | 'md'
  required?: boolean
}

const FormLabel: React.FC<FormLabelProps> = ({ 
  label, 
  size = 'sm', 
  required, 
  className,
  ...props 
}) => {
  const labelClasses = cn(
    'block text-ink-gray-5',
    {
      'text-xs': size === 'sm',
      'text-base': size === 'md',
    },
    className
  )

  return (
    <label className={labelClasses} {...props}>
      {label}
      {required && (
        <>
          <span className="text-ink-red-3 select-none ml-1" aria-hidden="true">*</span>
          <span className="sr-only">(required)</span>
        </>
      )}
    </label>
  )
}

export { FormLabel }
