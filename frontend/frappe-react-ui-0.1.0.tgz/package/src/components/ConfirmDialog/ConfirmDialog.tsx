import { useState, forwardRef, useImperativeHandle } from 'react'
import { Dialog } from '../Dialog'
import { cn } from '../../utils/cn'

export interface ConfirmDialogProps {
  title?: string
  message?: string
  onConfirm?: (options: { hideDialog: () => void }) => void
  onCancel?: () => void
}

export interface ConfirmDialogRef {
  show: () => void
  hide: () => void
}

const ConfirmDialog = forwardRef<ConfirmDialogRef, ConfirmDialogProps>(
  ({ title, message, onConfirm, onCancel }, ref) => {
    const [showDialog, setShowDialog] = useState(true)
    const [isLoading, setIsLoading] = useState(false)

    const show = () => {
      setShowDialog(true)
    }

    const hide = () => {
      setShowDialog(false)
    }

    const closeDialog = () => {
      hide()
      onCancel?.()
    }

    const handleConfirmation = async () => {
      setIsLoading(true)
      try {
        await onConfirm?.({
          hideDialog: hide,
        })
      } finally {
        setIsLoading(false)
      }
    }

    useImperativeHandle(ref, () => ({
      show,
      hide,
    }))

    return (
      <Dialog
        open={showDialog}
        onOpenChange={setShowDialog}
      >
        {title && (
          <div className="mb-4">
            <h2 className="text-lg font-semibold text-gray-900">{title}</h2>
          </div>
        )}
        
        <div className="space-y-4">
          {message && (
            <p 
              className="text-base text-gray-800"
              dangerouslySetInnerHTML={{ __html: message }}
            />
          )}
        </div>
        
        <div className="flex justify-end gap-2 mt-6">
          <button
            className={cn(
              'px-4 py-2 text-sm font-medium rounded-md border border-gray-300 bg-white text-gray-700',
              'hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
            )}
            onClick={closeDialog}
          >
            Cancel
          </button>
          <button
            className={cn(
              'px-4 py-2 text-sm font-medium rounded-md border border-transparent bg-blue-600 text-white',
              'hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500',
              'disabled:opacity-50 disabled:cursor-not-allowed'
            )}
            onClick={handleConfirmation}
            disabled={isLoading}
          >
            {isLoading ? 'Loading...' : 'Confirm'}
          </button>
        </div>
      </Dialog>
    )
  }
)

ConfirmDialog.displayName = 'ConfirmDialog'

export { ConfirmDialog }
