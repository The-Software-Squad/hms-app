import React, { useRef } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { ConfirmDialog, ConfirmDialogRef } from './ConfirmDialog'

const meta: Meta<typeof ConfirmDialog> = {
  title: 'Components/ConfirmDialog',
  component: ConfirmDialog,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  render: () => {
    const dialogRef = useRef<ConfirmDialogRef>(null)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          onClick={() => dialogRef.current?.show()}
        >
          Show Confirm Dialog
        </button>
        
        <ConfirmDialog
          ref={dialogRef}
          title="Confirm Action"
          message="Are you sure you want to proceed with this action?"
          onConfirm={({ hideDialog }) => {
            console.log('Confirmed!')
            hideDialog()
          }}
          onCancel={() => console.log('Cancelled!')}
        />
      </div>
    )
  },
}

export const DeleteConfirmation: Story = {
  render: () => {
    const dialogRef = useRef<ConfirmDialogRef>(null)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
          onClick={() => dialogRef.current?.show()}
        >
          Delete Item
        </button>
        
        <ConfirmDialog
          ref={dialogRef}
          title="Delete Item"
          message="Are you sure you want to delete this item? This action cannot be undone."
          onConfirm={({ hideDialog }) => {
            // Simulate async operation
            setTimeout(() => {
              console.log('Item deleted!')
              hideDialog()
            }, 1000)
          }}
          onCancel={() => console.log('Delete cancelled')}
        />
      </div>
    )
  },
}

export const WithHTMLMessage: Story = {
  render: () => {
    const dialogRef = useRef<ConfirmDialogRef>(null)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          onClick={() => dialogRef.current?.show()}
        >
          Show Rich Message
        </button>
        
        <ConfirmDialog
          ref={dialogRef}
          title="Important Notice"
          message="This will affect <strong>multiple records</strong>.<br><br>Please review the following:<br>• All related data will be updated<br>• This action is <em>irreversible</em>"
          onConfirm={({ hideDialog }) => {
            console.log('Confirmed with HTML message!')
            hideDialog()
          }}
        />
      </div>
    )
  },
}

export const AsyncConfirmation: Story = {
  render: () => {
    const dialogRef = useRef<ConfirmDialogRef>(null)
    
    return (
      <div>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          onClick={() => dialogRef.current?.show()}
        >
          Save Changes
        </button>
        
        <ConfirmDialog
          ref={dialogRef}
          title="Save Changes"
          message="Do you want to save your changes before leaving?"
          onConfirm={async ({ hideDialog }) => {
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000))
            console.log('Changes saved!')
            hideDialog()
          }}
          onCancel={() => console.log('Changes discarded')}
        />
      </div>
    )
  },
}

export const MultipleDialogs: Story = {
  render: () => {
    const dialog1Ref = useRef<ConfirmDialogRef>(null)
    const dialog2Ref = useRef<ConfirmDialogRef>(null)
    const dialog3Ref = useRef<ConfirmDialogRef>(null)
    
    return (
      <div className="space-x-4">
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 mr-2"
          onClick={() => dialog1Ref.current?.show()}
        >
          Logout
        </button>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 mr-2"
          onClick={() => dialog2Ref.current?.show()}
        >
          Reset Settings
        </button>
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
          onClick={() => dialog3Ref.current?.show()}
        >
          Clear Cache
        </button>
        
        <ConfirmDialog
          ref={dialog1Ref}
          title="Logout"
          message="Are you sure you want to logout?"
          onConfirm={({ hideDialog }) => {
            console.log('Logged out!')
            hideDialog()
          }}
        />
        
        <ConfirmDialog
          ref={dialog2Ref}
          title="Reset Settings"
          message="This will reset all your preferences to default values."
          onConfirm={({ hideDialog }) => {
            console.log('Settings reset!')
            hideDialog()
          }}
        />
        
        <ConfirmDialog
          ref={dialog3Ref}
          title="Clear Cache"
          message="This will clear all cached data and may slow down the application temporarily."
          onConfirm={({ hideDialog }) => {
            console.log('Cache cleared!')
            hideDialog()
          }}
        />
      </div>
    )
  },
}
