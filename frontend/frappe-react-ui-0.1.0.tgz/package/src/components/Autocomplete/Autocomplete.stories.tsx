import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { Autocomplete } from './Autocomplete'

const meta: Meta<typeof Autocomplete> = {
  title: 'Components/Autocomplete',
  component: Autocomplete,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

// Sample data
const countries = [
  { value: 'us', label: 'United States' },
  { value: 'ca', label: 'Canada' },
  { value: 'uk', label: 'United Kingdom' },
  { value: 'de', label: 'Germany' },
  { value: 'fr', label: 'France' },
  { value: 'jp', label: 'Japan' },
  { value: 'au', label: 'Australia' },
  { value: 'in', label: 'India' },
  { value: 'br', label: 'Brazil' },
  { value: 'mx', label: 'Mexico' },
]

const users = [
  { value: 'john', label: 'John Doe' },
  { value: 'jane', label: 'Jane Smith' },
  { value: 'bob', label: 'Bob Johnson' },
  { value: 'alice', label: 'Alice Brown' },
  { value: 'charlie', label: 'Charlie Wilson' },
  { value: 'diana', label: 'Diana Davis' },
  { value: 'edward', label: 'Edward Miller' },
  { value: 'fiona', label: 'Fiona Garcia' },
]

const technologies = [
  { value: 'react', label: 'React' },
  { value: 'vue', label: 'Vue.js' },
  { value: 'angular', label: 'Angular' },
  { value: 'svelte', label: 'Svelte' },
  { value: 'nodejs', label: 'Node.js' },
  { value: 'python', label: 'Python' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
]

export const Default: Story = {
  args: {
    options: countries,
    placeholder: 'Select a country...',
  },
}

export const WithLabel: Story = {
  args: {
    options: countries,
    label: 'Country',
    placeholder: 'Select your country',
    helperText: 'Choose the country you are located in',
  },
}

export const WithValue: Story = {
  args: {
    options: countries,
    value: 'us',
    label: 'Country',
    placeholder: 'Select a country...',
  },
}

export const WithError: Story = {
  args: {
    options: countries,
    label: 'Country',
    placeholder: 'Select a country...',
    error: 'Please select a valid country',
    required: true,
  },
}

export const Disabled: Story = {
  args: {
    options: countries,
    value: 'us',
    label: 'Country',
    placeholder: 'Select a country...',
    disabled: true,
  },
}

export const Loading: Story = {
  args: {
    options: [],
    label: 'Country',
    placeholder: 'Loading...',
    loading: true,
  },
}

export const Empty: Story = {
  args: {
    options: [],
    label: 'Country',
    placeholder: 'Search countries...',
    emptyMessage: 'No countries found',
  },
}

export const CustomFilter: Story = {
  args: {
    options: technologies,
    label: 'Technology',
    placeholder: 'Search technologies...',
    filterFunction: (option, query) => {
      // Custom filter that matches both value and label
      return (
        option.label.toLowerCase().includes(query.toLowerCase()) ||
        option.value.toLowerCase().includes(query.toLowerCase())
      )
    },
    helperText: 'Try searching for "js" or "script"',
  },
}

export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState('')
    
    return (
      <div className="w-80 space-y-4">
        <Autocomplete
          options={users}
          value={value}
          onValueChange={setValue}
          label="Assign to User"
          placeholder="Search users..."
          helperText="Start typing to search for users"
        />
        
        <div className="text-sm text-gray-600">
          Selected value: <code>{value || 'None'}</code>
        </div>
        
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={() => setValue('')}
        >
          Clear Selection
        </button>
      </div>
    )
  },
}

export const MultipleAutocompletes: Story = {
  render: () => {
    const [country, setCountry] = useState('')
    const [user, setUser] = useState('')
    const [tech, setTech] = useState('')
    
    return (
      <div className="w-80 space-y-6">
        <Autocomplete
          options={countries}
          value={country}
          onValueChange={setCountry}
          label="Country"
          placeholder="Select country..."
        />
        
        <Autocomplete
          options={users}
          value={user}
          onValueChange={setUser}
          label="User"
          placeholder="Select user..."
        />
        
        <Autocomplete
          options={technologies}
          value={tech}
          onValueChange={setTech}
          label="Technology"
          placeholder="Select technology..."
        />
        
        <div className="p-4 bg-gray-50 rounded-lg">
          <h4 className="font-medium mb-2">Selected Values:</h4>
          <div className="text-sm space-y-1">
            <div>Country: <code>{country || 'None'}</code></div>
            <div>User: <code>{user || 'None'}</code></div>
            <div>Technology: <code>{tech || 'None'}</code></div>
          </div>
        </div>
      </div>
    )
  },
}

export const WithDisabledOptions: Story = {
  args: {
    options: [
      { value: 'option1', label: 'Available Option 1' },
      { value: 'option2', label: 'Disabled Option 2', disabled: true },
      { value: 'option3', label: 'Available Option 3' },
      { value: 'option4', label: 'Disabled Option 4', disabled: true },
      { value: 'option5', label: 'Available Option 5' },
    ],
    label: 'Options',
    placeholder: 'Select an option...',
    helperText: 'Some options are disabled',
  },
}

export const LargeDataset: Story = {
  args: {
    options: Array.from({ length: 100 }, (_, i) => ({
      value: `item-${i + 1}`,
      label: `Item ${i + 1}`,
    })),
    label: 'Large Dataset',
    placeholder: 'Search through 100 items...',
    helperText: 'Try searching for specific numbers',
  },
}
