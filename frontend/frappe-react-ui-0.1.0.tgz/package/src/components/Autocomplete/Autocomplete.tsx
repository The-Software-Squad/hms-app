import React, { useState, useRef, useEffect } from 'react'
import { cn } from '../../utils/cn'
import { Input } from '../Input'
import { Popover, PopoverContent, PopoverTrigger } from '../Popover'
import { Check, ChevronDown } from 'lucide-react'

export interface AutocompleteOption {
  value: string
  label: string
  disabled?: boolean
}

export interface AutocompleteProps {
  options: AutocompleteOption[]
  value?: string
  onValueChange?: (value: string) => void
  placeholder?: string
  label?: string
  error?: string
  helperText?: string
  required?: boolean
  disabled?: boolean
  loading?: boolean
  emptyMessage?: string
  filterFunction?: (option: AutocompleteOption, query: string) => boolean
  className?: string
}

export const Autocomplete: React.FC<AutocompleteProps> = ({
  options,
  value,
  onValueChange,
  placeholder = 'Search...',
  label,
  error,
  helperText,
  required = false,
  disabled = false,
  loading = false,
  emptyMessage = 'No options found',
  filterFunction = (option, query) => 
    option.label.toLowerCase().includes(query.toLowerCase()),
  className,
}) => {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  const selectedOption = options.find(option => option.value === value)
  const filteredOptions = query 
    ? options.filter(option => filterFunction(option, query))
    : options

  useEffect(() => {
    if (selectedOption && !query) {
      setQuery(selectedOption.label)
    }
  }, [selectedOption, query])

  const handleSelect = (optionValue: string) => {
    const option = options.find(opt => opt.value === optionValue)
    if (option) {
      setQuery(option.label)
      onValueChange?.(optionValue)
      setOpen(false)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newQuery = e.target.value
    setQuery(newQuery)
    setOpen(true)
    
    // If query matches an option exactly, select it
    const exactMatch = options.find(
      option => option.label.toLowerCase() === newQuery.toLowerCase()
    )
    if (exactMatch) {
      onValueChange?.(exactMatch.value)
    } else if (value) {
      onValueChange?.('')
    }
  }

  const handleInputFocus = () => {
    setOpen(true)
  }

  const handleInputBlur = () => {
    // Delay closing to allow for option selection
    setTimeout(() => setOpen(false), 150)
  }

  return (
    <div className={cn('relative', className)}>
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <div className="relative">
            <Input
              ref={inputRef}
              label={label}
              value={query}
              onChange={handleInputChange}
              onFocus={handleInputFocus}
              onBlur={handleInputBlur}
              placeholder={placeholder}
              error={error}
              helperText={helperText}
              required={required}
              disabled={disabled}
              iconRight={
                <ChevronDown 
                  className={cn(
                    'h-4 w-4 transition-transform',
                    open && 'rotate-180'
                  )} 
                />
              }
            />
          </div>
        </PopoverTrigger>
        
        <PopoverContent 
          className="w-full p-0" 
          align="start"
          style={{ width: inputRef.current?.offsetWidth }}
        >
          <div className="max-h-60 overflow-auto">
            {loading ? (
              <div className="p-3 text-center text-sm text-ink-gray-5">
                Loading...
              </div>
            ) : filteredOptions.length === 0 ? (
              <div className="p-3 text-center text-sm text-ink-gray-5">
                {emptyMessage}
              </div>
            ) : (
              filteredOptions.map((option) => (
                <button
                  key={option.value}
                  className={cn(
                    'w-full px-3 py-2 text-left text-sm hover:bg-surface-gray-2 focus:bg-surface-gray-2 focus:outline-none flex items-center justify-between',
                    option.disabled && 'opacity-50 cursor-not-allowed',
                    value === option.value && 'bg-surface-blue-2 text-ink-blue-3'
                  )}
                  onClick={() => !option.disabled && handleSelect(option.value)}
                  disabled={option.disabled}
                >
                  <span>{option.label}</span>
                  {value === option.value && (
                    <Check className="h-4 w-4" />
                  )}
                </button>
              ))
            )}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  )
}
