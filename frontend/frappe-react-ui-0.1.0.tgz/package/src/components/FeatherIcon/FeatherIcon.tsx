import React from 'react'
import * as LucideIcons from 'lucide-react'
import { cn } from '../../utils/cn'

export interface FeatherIconProps extends React.SVGProps<SVGSVGElement> {
  name: string
  size?: number
  color?: string
  strokeWidth?: number
  className?: string
}

const FeatherIcon: React.FC<FeatherIconProps> = ({
  name,
  size = 24,
  color,
  strokeWidth = 1.5,
  className,
  ...props
}) => {
  // Convert kebab-case to PascalCase for Lucide icon names
  const iconName = name
    .split('-')
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join('')

  // Get the icon component from Lucide
  const IconComponent = (LucideIcons as any)[iconName] || LucideIcons.Circle

  return (
    <IconComponent
      size={size}
      color={color || 'currentColor'}
      strokeWidth={strokeWidth}
      className={cn('shrink-0', className)}
      {...props}
    />
  )
}

export { FeatherIcon }
