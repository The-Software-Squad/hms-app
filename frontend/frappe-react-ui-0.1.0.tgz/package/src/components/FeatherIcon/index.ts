export { FeatherIcon } from './FeatherIcon'
export type { FeatherIconProps } from './FeatherIcon'
