import type { Meta, StoryObj } from '@storybook/react'
import { FeatherIcon } from './FeatherIcon'

const meta: Meta<typeof FeatherIcon> = {
  title: 'Components/FeatherIcon',
  component: FeatherIcon,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    name: {
      control: { type: 'text' },
    },
    size: {
      control: { type: 'number' },
    },
    strokeWidth: {
      control: { type: 'number' },
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    name: 'heart',
  },
}

export const CustomSize: Story = {
  args: {
    name: 'star',
    size: 32,
  },
}

export const CustomColor: Story = {
  args: {
    name: 'check',
    color: '#22C55E',
    size: 28,
  },
}

export const CustomStrokeWidth: Story = {
  args: {
    name: 'circle',
    strokeWidth: 3,
    size: 32,
  },
}

export const CommonIcons: Story = {
  render: () => (
    <div className="flex gap-4 items-center">
      <FeatherIcon name="home" />
      <FeatherIcon name="user" />
      <FeatherIcon name="settings" />
      <FeatherIcon name="search" />
      <FeatherIcon name="bell" />
      <FeatherIcon name="mail" />
      <FeatherIcon name="calendar" />
      <FeatherIcon name="file" />
    </div>
  ),
}

export const Sizes: Story = {
  render: () => (
    <div className="flex gap-4 items-center">
      <FeatherIcon name="star" size={16} />
      <FeatherIcon name="star" size={20} />
      <FeatherIcon name="star" size={24} />
      <FeatherIcon name="star" size={32} />
      <FeatherIcon name="star" size={40} />
    </div>
  ),
}
