import React, { useState, useRef } from 'react'
import { Check, ChevronDown, Search } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Button } from '../Button'
import { Popover, PopoverContent, PopoverTrigger } from '../Popover'
import { Input } from '../Input'

export interface ComboboxOption {
  value: string
  label: string
  disabled?: boolean
  description?: string
}

export interface ComboboxProps {
  options: ComboboxOption[]
  value?: string
  onValueChange?: (value: string) => void
  placeholder?: string
  searchPlaceholder?: string
  emptyMessage?: string
  disabled?: boolean
  label?: string
  error?: string
  helperText?: string
  required?: boolean
  className?: string
  multiple?: boolean
  maxSelected?: number
}

export const Combobox: React.FC<ComboboxProps> = ({
  options,
  value,
  onValueChange,
  placeholder = 'Select option...',
  searchPlaceholder = 'Search options...',
  emptyMessage = 'No options found',
  disabled = false,
  label,
  error,
  helperText,
  required = false,
  className,
  multiple = false,
  maxSelected,
}) => {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const buttonRef = useRef<HTMLButtonElement>(null)

  const selectedValues = multiple 
    ? (Array.isArray(value) ? value : value ? [value] : [])
    : value ? [value] : []

  const selectedOptions = options.filter(option => selectedValues.includes(option.value))
  
  const filteredOptions = options.filter(option =>
    option.label.toLowerCase().includes(search.toLowerCase()) ||
    option.description?.toLowerCase().includes(search.toLowerCase())
  )

  const handleSelect = (optionValue: string) => {
    if (multiple) {
      const currentValues = Array.isArray(value) ? value : value ? [value] : []
      let newValues: string[]
      
      if (currentValues.includes(optionValue)) {
        newValues = currentValues.filter(v => v !== optionValue)
      } else {
        if (maxSelected && currentValues.length >= maxSelected) {
          return // Don't add if max limit reached
        }
        newValues = [...currentValues, optionValue]
      }
      
      onValueChange?.(newValues as any)
    } else {
      onValueChange?.(optionValue)
      setOpen(false)
    }
  }

  const getDisplayValue = () => {
    if (selectedOptions.length === 0) {
      return placeholder
    }
    
    if (multiple) {
      if (selectedOptions.length === 1) {
        return selectedOptions[0].label
      }
      return `${selectedOptions.length} selected`
    }
    
    return selectedOptions[0]?.label || placeholder
  }

  return (
    <div className={className}>
      {label && (
        <label className="block text-sm font-medium text-ink-gray-8 mb-1">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}
      
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            ref={buttonRef}
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className={cn(
              'w-full justify-between',
              !selectedValues.length && 'text-ink-gray-5',
              error && 'border-red-500'
            )}
            disabled={disabled}
          >
            <span className="truncate">{getDisplayValue()}</span>
            <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        
        <PopoverContent 
          className="w-full p-0" 
          align="start"
          style={{ width: buttonRef.current?.offsetWidth }}
        >
          <div className="p-2 border-b border-outline-gray-2">
            <Input
              placeholder={searchPlaceholder}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              iconLeft={<Search className="h-4 w-4" />}
              className="h-8"
            />
          </div>
          
          <div className="max-h-60 overflow-auto">
            {filteredOptions.length === 0 ? (
              <div className="p-4 text-center text-sm text-ink-gray-5">
                {emptyMessage}
              </div>
            ) : (
              filteredOptions.map((option) => (
                <button
                  key={option.value}
                  className={cn(
                    'w-full flex items-center px-3 py-2 text-left text-sm hover:bg-surface-gray-2 focus:bg-surface-gray-2 focus:outline-none',
                    option.disabled && 'opacity-50 cursor-not-allowed',
                    selectedValues.includes(option.value) && 'bg-surface-blue-2 text-ink-blue-3'
                  )}
                  onClick={() => !option.disabled && handleSelect(option.value)}
                  disabled={option.disabled}
                >
                  <div className="flex-1 min-w-0">
                    <div className="font-medium">{option.label}</div>
                    {option.description && (
                      <div className="text-xs text-ink-gray-5 truncate">
                        {option.description}
                      </div>
                    )}
                  </div>
                  
                  {selectedValues.includes(option.value) && (
                    <Check className="h-4 w-4 ml-2 shrink-0" />
                  )}
                </button>
              ))
            )}
          </div>
          
          {multiple && selectedValues.length > 0 && (
            <div className="p-2 border-t border-outline-gray-2">
              <div className="flex flex-wrap gap-1">
                {selectedOptions.map((option) => (
                  <span
                    key={option.value}
                    className="inline-flex items-center px-2 py-1 text-xs bg-surface-blue-2 text-ink-blue-3 rounded"
                  >
                    {option.label}
                    <button
                      className="ml-1 hover:text-ink-blue-4"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleSelect(option.value)
                      }}
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>
            </div>
          )}
        </PopoverContent>
      </Popover>
      
      {(error || helperText) && (
        <div className="mt-1 text-sm">
          {error ? (
            <span className="text-red-500">{error}</span>
          ) : (
            <span className="text-ink-gray-5">{helperText}</span>
          )}
        </div>
      )}
    </div>
  )
}
