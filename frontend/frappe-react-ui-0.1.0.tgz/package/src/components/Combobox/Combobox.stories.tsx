import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { Combobox } from './Combobox'

const meta: Meta<typeof Combobox> = {
  title: 'Components/Combobox',
  component: Combobox,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

const frameworks = [
  { value: 'react', label: 'React' },
  { value: 'vue', label: 'Vue.js' },
  { value: 'angular', label: 'Angular' },
  { value: 'svelte', label: 'Svelte' },
  { value: 'nextjs', label: 'Next.js' },
  { value: 'nuxtjs', label: 'Nuxt.js' },
]

const languages = [
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'csharp', label: 'C#' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
  { value: 'php', label: 'PHP' },
]

export const Default: Story = {
  args: {
    options: frameworks,
    placeholder: 'Select framework...',
  },
}

export const WithValue: Story = {
  args: {
    options: frameworks,
    value: 'react',
    placeholder: 'Select framework...',
  },
}

export const Searchable: Story = {
  args: {
    options: languages,
    placeholder: 'Search languages...',
    searchable: true,
  },
}

export const Disabled: Story = {
  args: {
    options: frameworks,
    value: 'react',
    placeholder: 'Select framework...',
    disabled: true,
  },
}

export const Controlled: Story = {
  render: () => {
    const [value, setValue] = useState('')
    
    return (
      <div className="w-80 space-y-4">
        <Combobox
          options={frameworks}
          value={value}
          onValueChange={setValue}
          placeholder="Choose a framework..."
          searchable
        />
        
        <div className="text-sm text-gray-600">
          Selected: <code>{value || 'None'}</code>
        </div>
        
        <button 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          onClick={() => setValue('vue')}
        >
          Select Vue.js
        </button>
      </div>
    )
  },
}
