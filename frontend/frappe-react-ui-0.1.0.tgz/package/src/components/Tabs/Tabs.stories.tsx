import type { Meta, StoryObj } from '@storybook/react'
import { Tabs, TabsList, TabsTrigger, TabsContent } from './Tabs'
import { Card } from '../Card'

const meta: Meta<typeof Tabs> = {
  title: 'Components/Tabs',
  component: Tabs,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  render: () => (
    <Tabs defaultValue="account" className="w-[400px]">
      <TabsList>
        <TabsTrigger value="account">Account</TabsTrigger>
        <TabsTrigger value="password">Password</TabsTrigger>
      </TabsList>
      <TabsContent value="account">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Account</h3>
          <p className="text-ink-gray-6">
            Make changes to your account here. Click save when you're done.
          </p>
        </Card>
      </TabsContent>
      <TabsContent value="password">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Password</h3>
          <p className="text-ink-gray-6">
            Change your password here. After saving, you'll be logged out.
          </p>
        </Card>
      </TabsContent>
    </Tabs>
  ),
}

export const WithMultipleTabs: Story = {
  render: () => (
    <Tabs defaultValue="overview" className="w-[500px]">
      <TabsList>
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="analytics">Analytics</TabsTrigger>
        <TabsTrigger value="reports">Reports</TabsTrigger>
        <TabsTrigger value="notifications">Notifications</TabsTrigger>
      </TabsList>
      <TabsContent value="overview">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Overview</h3>
          <p className="text-ink-gray-6">
            Get a high-level view of your account activity and performance metrics.
          </p>
        </Card>
      </TabsContent>
      <TabsContent value="analytics">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Analytics</h3>
          <p className="text-ink-gray-6">
            Detailed analytics and insights about your data and user behavior.
          </p>
        </Card>
      </TabsContent>
      <TabsContent value="reports">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Reports</h3>
          <p className="text-ink-gray-6">
            Generate and download various reports for your records.
          </p>
        </Card>
      </TabsContent>
      <TabsContent value="notifications">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Notifications</h3>
          <p className="text-ink-gray-6">
            Manage your notification preferences and settings.
          </p>
        </Card>
      </TabsContent>
    </Tabs>
  ),
}

export const WithDisabledTab: Story = {
  render: () => (
    <Tabs defaultValue="tab1" className="w-[400px]">
      <TabsList>
        <TabsTrigger value="tab1">Available</TabsTrigger>
        <TabsTrigger value="tab2" disabled>Disabled</TabsTrigger>
        <TabsTrigger value="tab3">Another Tab</TabsTrigger>
      </TabsList>
      <TabsContent value="tab1">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Available Tab</h3>
          <p className="text-ink-gray-6">This tab is available and can be clicked.</p>
        </Card>
      </TabsContent>
      <TabsContent value="tab2">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Disabled Tab</h3>
          <p className="text-ink-gray-6">This tab is disabled and cannot be accessed.</p>
        </Card>
      </TabsContent>
      <TabsContent value="tab3">
        <Card className="p-4">
          <h3 className="text-lg font-semibold mb-2">Another Tab</h3>
          <p className="text-ink-gray-6">This is another available tab.</p>
        </Card>
      </TabsContent>
    </Tabs>
  ),
}
