import React, { useState, useEffect, ReactNode } from 'react'
// @ts-ignore - react-grid-layout doesn't have proper TypeScript definitions
import RGL, { WidthProvider, Layout as RGLLayout } from 'react-grid-layout'
import { cn } from '../../utils/cn'
import 'react-grid-layout/css/styles.css'
import 'react-resizable/css/styles.css'

const ReactGridLayout = WidthProvider(RGL)

export interface LayoutItemRequired {
  w: number
  h: number
  x: number
  y: number
  i: string
}

export interface LayoutItem extends LayoutItemRequired {
  minW?: number
  minH?: number
  maxW?: number
  maxH?: number
  moved?: boolean
  static?: boolean
  isDraggable?: boolean
  isResizable?: boolean
}

export type Layout = Array<LayoutItem>

export interface GridLayoutProps {
  layout: Layout
  onLayoutChange?: (layout: Layout) => void
  cols?: number
  rowHeight?: number
  disabled?: boolean
  className?: string
  renderItem?: (props: {
    index: number
    i: string
    x: number
    y: number
    w: number
    h: number
  }) => ReactNode
  children?: ReactNode
}

const GridLayout: React.FC<GridLayoutProps> = ({
  layout,
  onLayoutChange,
  cols = 12,
  rowHeight = 52,
  disabled = false,
  className,
  renderItem,
  children,
}) => {
  const [layoutReady, setLayoutReady] = useState(false)

  useEffect(() => {
    // Simulate layout ready after a short delay
    const timer = setTimeout(() => setLayoutReady(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const handleLayoutChange = (newLayout: RGLLayout) => {
    if (onLayoutChange) {
      const convertedLayout: Layout = newLayout.map((item: any) => ({
        i: item.i,
        x: item.x,
        y: item.y,
        w: item.w,
        h: item.h,
        minW: item.minW,
        minH: item.minH,
        maxW: item.maxW,
        maxH: item.maxH,
        moved: item.moved,
        static: item.static,
        isDraggable: item.isDraggable,
        isResizable: item.isResizable,
      }))
      onLayoutChange(convertedLayout)
    }
  }

  const gridProps = {
    className: cn('grid-layout', className),
    layout: layout as RGLLayout,
    onLayoutChange: handleLayoutChange,
    cols,
    rowHeight,
    isDraggable: !disabled,
    isResizable: !disabled,
    margin: [0, 0] as [number, number],
    containerPadding: [0, 0] as [number, number],
    verticalCompact: true,
    preventCollision: false,
    useCSSTransforms: true,
    compactType: 'vertical' as const,
    breakpoints: { lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 },
    // Responsive column configuration
    ...({ cols: { lg: cols, md: cols, sm: cols, xs: 1, xxs: 1 } } as any),
  }

  return (
    <div className="grid-layout-wrapper">
      <ReactGridLayout {...gridProps}>
        {layout.map((item, index) => (
          <div key={item.i} className="grid-layout-item">
            {layoutReady && renderItem ? (
              renderItem({
                index,
                i: item.i,
                x: item.x,
                y: item.y,
                w: item.w,
                h: item.h,
              })
            ) : layoutReady && children ? (
              children
            ) : layoutReady ? (
              <pre className="h-full w-full rounded bg-surface-white p-4 shadow text-xs overflow-auto">
                {JSON.stringify(
                  { i: item.i, x: item.x, y: item.y, w: item.w, h: item.h },
                  null,
                  2
                )}
              </pre>
            ) : null}
          </div>
        ))}
      </ReactGridLayout>
    </div>
  )
}

export { GridLayout }
