import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { GridLayout, Layout } from './GridLayout'

const meta: Meta<typeof GridLayout> = {
  title: 'Components/GridLayout',
  component: GridLayout,
  parameters: {
    layout: 'fullscreen',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

const initialLayout: Layout = [
  { i: 'a', x: 0, y: 0, w: 1, h: 2 },
  { i: 'b', x: 1, y: 0, w: 3, h: 2 },
  { i: 'c', x: 4, y: 0, w: 1, h: 2 },
  { i: 'd', x: 0, y: 2, w: 2, h: 1 },
  { i: 'e', x: 2, y: 2, w: 2, h: 1 },
  { i: 'f', x: 4, y: 2, w: 1, h: 1 },
]

export const Default: Story = {
  render: () => {
    const [layout, setLayout] = useState<Layout>(initialLayout)
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Interactive Grid Layout</h2>
        <p className="text-gray-600 mb-4">
          Drag items around and resize them. The layout state is managed by React.
        </p>
        
        <GridLayout
          layout={layout}
          onLayoutChange={setLayout}
          className="min-h-[400px]"
        />
        
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Current Layout:</h3>
          <pre className="bg-gray-100 p-3 rounded text-sm overflow-auto">
            {JSON.stringify(layout, null, 2)}
          </pre>
        </div>
      </div>
    )
  },
}

export const CustomItems: Story = {
  render: () => {
    const [layout, setLayout] = useState<Layout>([
      { i: 'chart', x: 0, y: 0, w: 6, h: 4 },
      { i: 'stats', x: 6, y: 0, w: 6, h: 2 },
      { i: 'table', x: 6, y: 2, w: 6, h: 2 },
      { i: 'sidebar', x: 0, y: 4, w: 3, h: 3 },
      { i: 'content', x: 3, y: 4, w: 9, h: 3 },
    ])
    
    const renderItem = ({ i }: { i: string }) => {
      const itemStyles = {
        chart: 'bg-blue-100 border-blue-300',
        stats: 'bg-green-100 border-green-300',
        table: 'bg-yellow-100 border-yellow-300',
        sidebar: 'bg-purple-100 border-purple-300',
        content: 'bg-pink-100 border-pink-300',
      }
      
      const itemTitles = {
        chart: '📊 Chart Widget',
        stats: '📈 Statistics',
        table: '📋 Data Table',
        sidebar: '🔧 Sidebar',
        content: '📝 Main Content',
      }
      
      return (
        <div className={`h-full w-full rounded border-2 p-4 ${itemStyles[i as keyof typeof itemStyles]}`}>
          <h3 className="font-semibold text-lg mb-2">
            {itemTitles[i as keyof typeof itemTitles]}
          </h3>
          <p className="text-sm text-gray-600">
            This is a custom rendered item with ID: {i}
          </p>
        </div>
      )
    }
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Dashboard Layout</h2>
        <p className="text-gray-600 mb-4">
          A dashboard-style layout with custom rendered components.
        </p>
        
        <GridLayout
          layout={layout}
          onLayoutChange={setLayout}
          renderItem={renderItem}
          className="min-h-[500px]"
        />
      </div>
    )
  },
}

export const StaticItems: Story = {
  render: () => {
    const staticLayout: Layout = [
      { i: 'header', x: 0, y: 0, w: 12, h: 1, static: true },
      { i: 'sidebar', x: 0, y: 1, w: 2, h: 4, static: true },
      { i: 'main', x: 2, y: 1, w: 8, h: 4 },
      { i: 'aside', x: 10, y: 1, w: 2, h: 4 },
      { i: 'footer', x: 0, y: 5, w: 12, h: 1, static: true },
    ]
    
    const [layout, setLayout] = useState<Layout>(staticLayout)
    
    const renderItem = ({ i }: { i: string }) => {
      const isStatic = staticLayout.find(item => item.i === i)?.static
      
      return (
        <div className={`h-full w-full rounded border-2 p-4 ${
          isStatic 
            ? 'bg-gray-100 border-gray-300' 
            : 'bg-blue-100 border-blue-300'
        }`}>
          <h3 className="font-semibold">
            {i.charAt(0).toUpperCase() + i.slice(1)}
            {isStatic && ' (Static)'}
          </h3>
          <p className="text-sm text-gray-600 mt-2">
            {isStatic ? 'This item cannot be moved or resized' : 'Drag and resize me!'}
          </p>
        </div>
      )
    }
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Static vs Dynamic Items</h2>
        <p className="text-gray-600 mb-4">
          Some items are static (header, sidebar, footer) while others can be moved.
        </p>
        
        <GridLayout
          layout={layout}
          onLayoutChange={setLayout}
          renderItem={renderItem}
          className="min-h-[400px]"
        />
      </div>
    )
  },
}

export const Disabled: Story = {
  render: () => {
    const [layout] = useState<Layout>(initialLayout)
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Disabled Grid Layout</h2>
        <p className="text-gray-600 mb-4">
          This grid layout is disabled - items cannot be moved or resized.
        </p>
        
        <GridLayout
          layout={layout}
          disabled={true}
          className="min-h-[400px]"
        />
      </div>
    )
  },
}

export const CustomRowHeight: Story = {
  render: () => {
    const [layout, setLayout] = useState<Layout>([
      { i: 'a', x: 0, y: 0, w: 4, h: 1 },
      { i: 'b', x: 4, y: 0, w: 4, h: 1 },
      { i: 'c', x: 8, y: 0, w: 4, h: 1 },
      { i: 'd', x: 0, y: 1, w: 6, h: 2 },
      { i: 'e', x: 6, y: 1, w: 6, h: 2 },
    ])
    
    return (
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">Custom Row Height</h2>
        <p className="text-gray-600 mb-4">
          This grid uses a custom row height of 80px instead of the default 52px.
        </p>
        
        <GridLayout
          layout={layout}
          onLayoutChange={setLayout}
          rowHeight={80}
          className="min-h-[400px]"
        />
      </div>
    )
  },
}
