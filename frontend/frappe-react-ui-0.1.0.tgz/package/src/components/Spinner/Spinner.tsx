import React from 'react'
import { cn } from '../../utils/cn'

export interface SpinnerProps extends React.HTMLAttributes<HTMLDivElement> {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  variant?: 'default' | 'primary' | 'secondary'
  text?: string
}

const Spinner = React.forwardRef<HTMLDivElement, SpinnerProps>(
  ({ className, size = 'md', variant = 'default', text, ...props }, ref) => {
    const sizeClasses = {
      xs: 'h-3 w-3',
      sm: 'h-4 w-4',
      md: 'h-6 w-6',
      lg: 'h-8 w-8',
      xl: 'h-12 w-12',
    }

    const variantClasses = {
      default: 'text-ink-gray-6',
      primary: 'text-blue-500',
      secondary: 'text-ink-gray-4',
    }

    const borderWidthClasses = {
      xs: 'border',
      sm: 'border',
      md: 'border-2',
      lg: 'border-2',
      xl: 'border-4',
    }

    if (text) {
      return (
        <div
          ref={ref}
          className={cn('flex items-center gap-3', className)}
          {...props}
        >
          <div
            className={cn(
              'animate-spin rounded-full border-current border-t-transparent',
              sizeClasses[size],
              variantClasses[variant],
              borderWidthClasses[size]
            )}
            role="status"
            aria-label="Loading"
          />
          <span className={cn('text-sm', variantClasses[variant])}>
            {text}
          </span>
        </div>
      )
    }

    return (
      <div
        ref={ref}
        className={cn(
          'animate-spin rounded-full border-current border-t-transparent',
          sizeClasses[size],
          variantClasses[variant],
          borderWidthClasses[size],
          className
        )}
        role="status"
        aria-label="Loading"
        {...props}
      >
        <span className="sr-only">Loading...</span>
      </div>
    )
  }
)

Spinner.displayName = 'Spinner'

export { Spinner }
