import React, { useState } from 'react'
import { Star } from 'lucide-react'
import { cn } from '../../utils/cn'

export interface RatingProps {
  value?: number
  onChange?: (value: number) => void
  max?: number
  size?: 'sm' | 'md' | 'lg'
  readonly?: boolean
  disabled?: boolean
  allowHalf?: boolean
  showValue?: boolean
  className?: string
  color?: 'yellow' | 'blue' | 'green' | 'red'
}

export const Rating: React.FC<RatingProps> = ({
  value = 0,
  onChange,
  max = 5,
  size = 'md',
  readonly = false,
  disabled = false,
  allowHalf = false,
  showValue = false,
  className,
  color = 'yellow',
}) => {
  const [hoverValue, setHoverValue] = useState<number | null>(null)
  const [hoverHalf, setHoverHalf] = useState(false)

  const sizeClasses = {
    sm: 'h-4 w-4',
    md: 'h-5 w-5',
    lg: 'h-6 w-6',
  }

  const colorClasses = {
    yellow: 'text-yellow-400',
    blue: 'text-blue-400',
    green: 'text-green-400',
    red: 'text-red-400',
  }

  const handleMouseEnter = (index: number, isHalf: boolean = false) => {
    if (readonly || disabled) return
    setHoverValue(index)
    setHoverHalf(isHalf)
  }

  const handleMouseLeave = () => {
    if (readonly || disabled) return
    setHoverValue(null)
    setHoverHalf(false)
  }

  const handleClick = (index: number, isHalf: boolean = false) => {
    if (readonly || disabled || !onChange) return
    const newValue = isHalf ? index - 0.5 : index
    onChange(newValue)
  }

  const getStarFill = (index: number) => {
    const currentValue = hoverValue !== null ? hoverValue : value
    const isHalf = hoverValue !== null ? hoverHalf : value % 1 !== 0

    if (index <= Math.floor(currentValue)) {
      return 'full'
    } else if (index === Math.ceil(currentValue) && (currentValue % 1 !== 0 || isHalf)) {
      return 'half'
    }
    return 'empty'
  }

  return (
    <div className={cn('flex items-center gap-1', className)}>
      <div className="flex items-center">
        {Array.from({ length: max }, (_, i) => {
          const index = i + 1
          const fill = getStarFill(index)
          
          return (
            <div
              key={index}
              className={cn(
                'relative cursor-pointer',
                (readonly || disabled) && 'cursor-default',
                disabled && 'opacity-50'
              )}
              onMouseEnter={() => handleMouseEnter(index)}
              onMouseLeave={handleMouseLeave}
              onClick={() => handleClick(index)}
            >
              {allowHalf && !readonly && !disabled && (
                <>
                  <div
                    className="absolute inset-0 w-1/2 z-10"
                    onMouseEnter={() => handleMouseEnter(index, true)}
                    onClick={(e) => {
                      e.stopPropagation()
                      handleClick(index, true)
                    }}
                  />
                  <div
                    className="absolute inset-0 left-1/2 w-1/2 z-10"
                    onMouseEnter={() => handleMouseEnter(index, false)}
                    onClick={(e) => {
                      e.stopPropagation()
                      handleClick(index, false)
                    }}
                  />
                </>
              )}
              
              <Star
                className={cn(
                  sizeClasses[size],
                  'transition-colors',
                  fill === 'full' && [colorClasses[color], 'fill-current'],
                  fill === 'empty' && 'text-ink-gray-3',
                  fill === 'half' && [colorClasses[color], 'fill-current']
                )}
                style={fill === 'half' ? {
                  background: `linear-gradient(90deg, currentColor 50%, #d1d5db 50%)`,
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                } : undefined}
              />
            </div>
          )
        })}
      </div>
      
      {showValue && (
        <span className="text-sm text-ink-gray-6 ml-2">
          {value.toFixed(allowHalf ? 1 : 0)} / {max}
        </span>
      )}
    </div>
  )
}
