import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { ListView } from './ListView'
import { Badge } from '../Badge'
import { MoreHorizontal, Edit, Trash2, Eye } from 'lucide-react'

const meta: Meta<typeof ListView> = {
  title: 'Components/ListView',
  component: ListView,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

// Sample data
const sampleUsers = [
  { id: 1, name: 'John Doe', email: 'john@example.com', role: 'Admin', status: 'Active', lastLogin: '2024-01-15' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', role: 'Editor', status: 'Active', lastLogin: '2024-01-14' },
  { id: 3, name: 'Bob Johnson', email: 'bob@example.com', role: 'Viewer', status: 'Inactive', lastLogin: '2024-01-10' },
  { id: 4, name: 'Alice Brown', email: 'alice@example.com', role: 'Admin', status: 'Active', lastLogin: '2024-01-16' },
  { id: 5, name: 'Charlie Wilson', email: 'charlie@example.com', role: 'Editor', status: 'Active', lastLogin: '2024-01-13' },
]

const sampleProducts = [
  { id: 1, name: 'MacBook Pro', category: 'Laptops', price: 1299, stock: 15, rating: 4.8 },
  { id: 2, name: 'iPhone 15', category: 'Phones', price: 999, stock: 25, rating: 4.7 },
  { id: 3, name: 'iPad Air', category: 'Tablets', price: 599, stock: 8, rating: 4.6 },
  { id: 4, name: 'AirPods Pro', category: 'Audio', price: 249, stock: 50, rating: 4.9 },
  { id: 5, name: 'Apple Watch', category: 'Wearables', price: 399, stock: 12, rating: 4.5 },
]

const userColumns = [
  { key: 'name', label: 'Name', sortable: true },
  { key: 'email', label: 'Email', sortable: true },
  { 
    key: 'role', 
    label: 'Role', 
    sortable: true,
    render: (value: string) => (
      <Badge variant={value === 'Admin' ? 'solid' : 'subtle'} theme="blue">
        {value}
      </Badge>
    )
  },
  { 
    key: 'status', 
    label: 'Status',
    render: (value: string) => (
      <Badge variant="subtle" theme={value === 'Active' ? 'green' : 'gray'}>
        {value}
      </Badge>
    )
  },
  { key: 'lastLogin', label: 'Last Login', sortable: true },
]

const productColumns = [
  { key: 'name', label: 'Product Name', sortable: true },
  { 
    key: 'category', 
    label: 'Category', 
    sortable: true,
    render: (value: string) => (
      <Badge variant="outline" theme="blue">{value}</Badge>
    )
  },
  { 
    key: 'price', 
    label: 'Price', 
    sortable: true, 
    align: 'right' as const,
    render: (value: number) => `$${value.toLocaleString()}`
  },
  { 
    key: 'stock', 
    label: 'Stock', 
    sortable: true, 
    align: 'center' as const,
    render: (value: number) => (
      <Badge variant="subtle" theme={value < 10 ? 'red' : 'green'}>
        {value}
      </Badge>
    )
  },
  { 
    key: 'rating', 
    label: 'Rating', 
    sortable: true, 
    align: 'center' as const,
    render: (value: number) => `⭐ ${value}`
  },
]

export const Default: Story = {
  args: {
    columns: userColumns,
    data: sampleUsers,
  },
}

export const WithSearch: Story = {
  args: {
    columns: userColumns,
    data: sampleUsers,
    searchable: true,
    searchPlaceholder: 'Search users...',
  },
}

export const WithSelection: Story = {
  render: () => {
    const [selectedRows, setSelectedRows] = useState<(string | number)[]>([])
    
    return (
      <div>
        <div className="mb-4 text-sm text-gray-600">
          Selected: {selectedRows.length} users
        </div>
        <ListView
          columns={userColumns}
          data={sampleUsers}
          selectable
          selectedRows={selectedRows}
          onSelectionChange={setSelectedRows}
          searchable
        />
      </div>
    )
  },
}

export const WithRowActions: Story = {
  args: {
    columns: userColumns,
    data: sampleUsers,
    searchable: true,
    rowActions: (row) => (
      <div className="flex items-center gap-1">
        <button className="p-1 text-gray-500 hover:text-blue-600">
          <Eye className="h-4 w-4" />
        </button>
        <button className="p-1 text-gray-500 hover:text-green-600">
          <Edit className="h-4 w-4" />
        </button>
        <button className="p-1 text-gray-500 hover:text-red-600">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    ),
  },
}

export const ProductCatalog: Story = {
  args: {
    columns: productColumns,
    data: sampleProducts,
    searchable: true,
    searchPlaceholder: 'Search products...',
    onRowClick: (row) => alert(`Clicked on ${row.name}`),
  },
}

export const Loading: Story = {
  args: {
    columns: userColumns,
    data: [],
    loading: true,
  },
}

export const Empty: Story = {
  args: {
    columns: userColumns,
    data: [],
    emptyMessage: 'No users found. Add some users to get started.',
    searchable: true,
  },
}

export const CustomRendering: Story = {
  args: {
    columns: [
      { key: 'name', label: 'Name', sortable: true },
      { 
        key: 'email', 
        label: 'Contact', 
        render: (value: string, row: any) => (
          <div>
            <div className="font-medium">{value}</div>
            <div className="text-sm text-gray-500">{row.role}</div>
          </div>
        )
      },
      { 
        key: 'status', 
        label: 'Status & Login',
        render: (value: string, row: any) => (
          <div>
            <Badge variant="subtle" theme={value === 'Active' ? 'green' : 'gray'}>
              {value}
            </Badge>
            <div className="text-xs text-gray-500 mt-1">
              Last: {row.lastLogin}
            </div>
          </div>
        )
      },
    ],
    data: sampleUsers,
    searchable: true,
  },
}

export const InteractiveExample: Story = {
  render: () => {
    const [selectedRows, setSelectedRows] = useState<(string | number)[]>([])
    const [data, setData] = useState(sampleUsers)
    
    const handleDelete = (id: string | number) => {
      setData(prev => prev.filter(item => item.id !== id))
      setSelectedRows(prev => prev.filter(rowId => rowId !== id))
    }
    
    const handleBulkDelete = () => {
      setData(prev => prev.filter(item => !selectedRows.includes(item.id)))
      setSelectedRows([])
    }
    
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">User Management</h3>
          {selectedRows.length > 0 && (
            <button 
              className="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
              onClick={handleBulkDelete}
            >
              Delete Selected ({selectedRows.length})
            </button>
          )}
        </div>
        
        <ListView
          columns={userColumns}
          data={data}
          selectable
          selectedRows={selectedRows}
          onSelectionChange={setSelectedRows}
          searchable
          searchPlaceholder="Search users..."
          rowActions={(row) => (
            <button 
              className="p-1 text-gray-500 hover:text-red-600"
              onClick={() => handleDelete(row.id)}
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
          onRowClick={(row) => console.log('Row clicked:', row)}
        />
      </div>
    )
  },
}
