import React, { useState, useMemo } from 'react'
import { ChevronDown, ChevronUp, Search, Filter } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Input } from '../Input'
import { Button } from '../Button'
import { Checkbox } from '../Checkbox'
import { Badge } from '../Badge'
// import { Dropdown, DropdownContent, DropdownItem, DropdownTrigger } from '../Dropdown' // Unused

export interface ListViewColumn {
  key: string
  label: string
  sortable?: boolean
  filterable?: boolean
  width?: string | number
  render?: (value: any, row: any) => React.ReactNode
  align?: 'left' | 'center' | 'right'
}

export interface ListViewRow {
  id: string | number
  [key: string]: any
}

export interface ListViewProps {
  columns: ListViewColumn[]
  data: ListViewRow[]
  loading?: boolean
  selectable?: boolean
  selectedRows?: (string | number)[]
  onSelectionChange?: (selectedRows: (string | number)[]) => void
  onRowClick?: (row: ListViewRow) => void
  searchable?: boolean
  searchPlaceholder?: string
  filterable?: boolean
  sortable?: boolean
  pagination?: boolean
  pageSize?: number
  emptyMessage?: string
  className?: string
  rowActions?: (row: ListViewRow) => React.ReactNode
}

export const ListView: React.FC<ListViewProps> = ({
  columns,
  data,
  loading = false,
  selectable = false,
  selectedRows = [],
  onSelectionChange,
  onRowClick,
  searchable = true,
  searchPlaceholder = 'Search...',
  filterable = false,
  sortable = true,
  pagination = true,
  pageSize = 10,
  emptyMessage = 'No data available',
  className,
  rowActions,
}) => {
  const [searchQuery, setSearchQuery] = useState('')
  const [sortColumn, setSortColumn] = useState<string | null>(null)
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc')
  const [currentPage, setCurrentPage] = useState(1)

  // Filter and search data
  const filteredData = useMemo(() => {
    let filtered = data

    // Apply search
    if (searchQuery) {
      filtered = filtered.filter(row =>
        Object.values(row).some(value =>
          String(value).toLowerCase().includes(searchQuery.toLowerCase())
        )
      )
    }

    // Apply sorting
    if (sortColumn) {
      filtered = [...filtered].sort((a, b) => {
        const aVal = a[sortColumn]
        const bVal = b[sortColumn]
        
        if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1
        if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1
        return 0
      })
    }

    return filtered
  }, [data, searchQuery, sortColumn, sortDirection])

  // Paginate data
  const paginatedData = useMemo(() => {
    if (!pagination) return filteredData
    
    const startIndex = (currentPage - 1) * pageSize
    return filteredData.slice(startIndex, startIndex + pageSize)
  }, [filteredData, currentPage, pageSize, pagination])

  const totalPages = Math.ceil(filteredData.length / pageSize)

  const handleSort = (columnKey: string) => {
    if (!sortable) return
    
    const column = columns.find(col => col.key === columnKey)
    if (!column?.sortable) return

    if (sortColumn === columnKey) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc')
    } else {
      setSortColumn(columnKey)
      setSortDirection('asc')
    }
  }

  const handleSelectAll = (checked: boolean) => {
    if (!onSelectionChange) return
    
    if (checked) {
      const allIds = paginatedData.map(row => row.id)
      onSelectionChange([...new Set([...selectedRows, ...allIds])])
    } else {
      const pageIds = paginatedData.map(row => row.id)
      onSelectionChange(selectedRows.filter(id => !pageIds.includes(id)))
    }
  }

  const handleRowSelect = (rowId: string | number, checked: boolean) => {
    if (!onSelectionChange) return
    
    if (checked) {
      onSelectionChange([...selectedRows, rowId])
    } else {
      onSelectionChange(selectedRows.filter(id => id !== rowId))
    }
  }

  const isAllSelected = paginatedData.length > 0 && 
    paginatedData.every(row => selectedRows.includes(row.id))

  return (
    <div className={cn('space-y-4', className)}>
      {/* Header */}
      {(searchable || filterable) && (
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {searchable && (
              <Input
                placeholder={searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                iconLeft={<Search className="h-4 w-4" />}
                className="w-64"
              />
            )}
            {filterable && (
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            )}
          </div>
          
          {selectedRows.length > 0 && (
            <Badge variant="secondary" theme="blue">
              {selectedRows.length} selected
            </Badge>
          )}
        </div>
      )}

      {/* Table */}
      <div className="border border-outline-gray-2 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-surface-gray-1">
              <tr>
                {selectable && (
                  <th className="w-12 px-4 py-3">
                    <Checkbox
                      checked={isAllSelected}
                      onCheckedChange={handleSelectAll}
                    />
                  </th>
                )}
                {columns.map((column) => (
                  <th
                    key={column.key}
                    className={cn(
                      'px-4 py-3 text-left text-sm font-medium text-ink-gray-8',
                      column.sortable && sortable && 'cursor-pointer hover:bg-surface-gray-2',
                      column.align === 'center' && 'text-center',
                      column.align === 'right' && 'text-right'
                    )}
                    style={{ width: column.width }}
                    onClick={() => handleSort(column.key)}
                  >
                    <div className="flex items-center space-x-1">
                      <span>{column.label}</span>
                      {column.sortable && sortable && (
                        <div className="flex flex-col">
                          <ChevronUp 
                            className={cn(
                              'h-3 w-3',
                              sortColumn === column.key && sortDirection === 'asc'
                                ? 'text-blue-500' 
                                : 'text-ink-gray-4'
                            )} 
                          />
                          <ChevronDown 
                            className={cn(
                              'h-3 w-3 -mt-1',
                              sortColumn === column.key && sortDirection === 'desc'
                                ? 'text-blue-500' 
                                : 'text-ink-gray-4'
                            )} 
                          />
                        </div>
                      )}
                    </div>
                  </th>
                ))}
                {rowActions && (
                  <th className="w-12 px-4 py-3"></th>
                )}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td 
                    colSpan={columns.length + (selectable ? 1 : 0) + (rowActions ? 1 : 0)}
                    className="px-4 py-8 text-center text-ink-gray-5"
                  >
                    Loading...
                  </td>
                </tr>
              ) : paginatedData.length === 0 ? (
                <tr>
                  <td 
                    colSpan={columns.length + (selectable ? 1 : 0) + (rowActions ? 1 : 0)}
                    className="px-4 py-8 text-center text-ink-gray-5"
                  >
                    {emptyMessage}
                  </td>
                </tr>
              ) : (
                paginatedData.map((row, _index) => (
                  <tr
                    key={row.id}
                    className={cn(
                      'border-t border-outline-gray-1 hover:bg-surface-gray-1',
                      onRowClick && 'cursor-pointer',
                      selectedRows.includes(row.id) && 'bg-surface-blue-1'
                    )}
                    onClick={() => onRowClick?.(row)}
                  >
                    {selectable && (
                      <td className="px-4 py-3">
                        <Checkbox
                          checked={selectedRows.includes(row.id)}
                          onCheckedChange={(checked) => handleRowSelect(row.id, checked as boolean)}
                          onClick={(e) => e.stopPropagation()}
                        />
                      </td>
                    )}
                    {columns.map((column) => (
                      <td
                        key={column.key}
                        className={cn(
                          'px-4 py-3 text-sm text-ink-gray-8',
                          column.align === 'center' && 'text-center',
                          column.align === 'right' && 'text-right'
                        )}
                      >
                        {column.render 
                          ? column.render(row[column.key], row)
                          : row[column.key]
                        }
                      </td>
                    ))}
                    {rowActions && (
                      <td className="px-4 py-3">
                        <div onClick={(e) => e.stopPropagation()}>
                          {rowActions(row)}
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {pagination && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <div className="text-sm text-ink-gray-6">
            Showing {((currentPage - 1) * pageSize) + 1} to{' '}
            {Math.min(currentPage * pageSize, filteredData.length)} of{' '}
            {filteredData.length} results
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(currentPage - 1)}
            >
              Previous
            </Button>
            
            <div className="flex items-center space-x-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? 'solid' : 'ghost'}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className="w-8 h-8 p-0"
                >
                  {page}
                </Button>
              ))}
            </div>
            
            <Button
              variant="outline"
              size="sm"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(currentPage + 1)}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
