import type { Meta, StoryObj } from '@storybook/react'
import React, { useState } from 'react'
import { Checkbox } from './Checkbox'

const meta: Meta<typeof Checkbox> = {
  title: 'Components/Checkbox',
  component: Checkbox,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {},
}

export const WithLabel: Story = {
  args: {
    label: 'Accept terms and conditions',
  },
}

export const WithDescription: Story = {
  args: {
    label: 'Email notifications',
    description: 'Receive email notifications about your account activity.',
  },
}

export const WithError: Story = {
  args: {
    label: 'Required field',
    error: 'This field is required',
  },
}

export const Disabled: Story = {
  args: {
    label: 'Disabled checkbox',
    disabled: true,
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="space-y-4">
      <Checkbox size="sm" label="Small checkbox" />
      <Checkbox size="md" label="Medium checkbox" />
      <Checkbox size="lg" label="Large checkbox" />
    </div>
  ),
}

export const Controlled: Story = {
  render: () => {
    const [checked, setChecked] = useState(false)
    
    return (
      <div className="space-y-4">
        <Checkbox
          checked={checked}
          onCheckedChange={setChecked}
          label="Controlled checkbox"
          description={`Current state: ${checked ? 'checked' : 'unchecked'}`}
        />
        <button
          onClick={() => setChecked(!checked)}
          className="px-3 py-1 bg-blue-500 text-white rounded text-sm"
        >
          Toggle
        </button>
      </div>
    )
  },
}
