import React from 'react'
import { Check } from 'lucide-react'
import { cn } from '../../utils/cn'

export interface CircularProgressBarProps {
  step?: number
  totalSteps?: number
  showPercentage?: boolean
  theme?: 'black' | 'red' | 'green' | 'blue' | 'orange' | { primary: string; secondary: string }
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
  themeComplete?: string
  variant?: 'solid' | 'outline'
  className?: string
}

interface SizeProps {
  ringSize: string
  ringBarWidth: string
  innerTextFontSize: string
  checkIconSize: number
}

const CircularProgressBar: React.FC<CircularProgressBarProps> = ({
  step = 1,
  totalSteps = 4,
  showPercentage = false,
  theme = 'black',
  size = 'md',
  themeComplete = '#22C55E',
  variant = 'solid',
  className,
}) => {
  // Predefined sizes for the circular progress bar
  const sizeMap: Record<string, SizeProps> = {
    xs: {
      ringSize: '30px',
      ringBarWidth: '6px',
      innerTextFontSize: showPercentage ? '8px' : '12px',
      checkIconSize: 16,
    },
    sm: {
      ringSize: '42px',
      ringBarWidth: '10px',
      innerTextFontSize: showPercentage ? '12px' : '16px',
      checkIconSize: 20,
    },
    md: {
      ringSize: '60px',
      ringBarWidth: '14px',
      innerTextFontSize: showPercentage ? '16px' : '20px',
      checkIconSize: 24,
    },
    lg: {
      ringSize: '84px',
      ringBarWidth: '18px',
      innerTextFontSize: showPercentage ? '20px' : '24px',
      checkIconSize: 40,
    },
    xl: {
      ringSize: '108px',
      ringBarWidth: '22px',
      innerTextFontSize: showPercentage ? '24px' : '28px',
      checkIconSize: 48,
    },
  }

  // Predefined themes for the circular progress bar
  const themeMap = {
    black: {
      primary: '#333',
      secondary: '#888',
    },
    red: {
      primary: '#FF0000',
      secondary: '#FFD7D7',
    },
    green: {
      primary: '#22C55E',
      secondary: '#b1ffda',
    },
    blue: {
      primary: '#2376f5',
      secondary: '#D7D7FF',
    },
    orange: {
      primary: '#FFA500',
      secondary: '#FFE5CC',
    },
  }

  const sizeProps = sizeMap[size] || sizeMap['md']
  const themeProps = typeof theme === 'string' ? themeMap[theme] || themeMap['black'] : theme
  const progress = (step / totalSteps) * 100
  const isCompleted = step === totalSteps

  const progressBarStyle: React.CSSProperties = {
    width: sizeProps.ringSize,
    height: sizeProps.ringSize,
    fontSize: sizeProps.innerTextFontSize,
    background: `conic-gradient(${themeProps.primary} ${progress}%, ${themeProps.secondary} 0%)`,
  }

  const innerCircleStyle: React.CSSProperties = {
    width: `calc(100% - ${sizeProps.ringBarWidth})`,
    height: `calc(100% - ${sizeProps.ringBarWidth})`,
    background: isCompleted && variant !== 'outline' ? themeComplete : 'white',
  }

  const outerStyle: React.CSSProperties = isCompleted && variant === 'outline' 
    ? { background: themeComplete } 
    : progressBarStyle

  return (
    <div
      className={cn(
        'relative grid place-items-center rounded-full transition-all duration-500',
        className
      )}
      style={outerStyle}
      role="progressbar"
      aria-valuenow={step}
      aria-valuemin={0}
      aria-valuemax={totalSteps}
    >
      <div
        className="relative z-10 grid place-items-center rounded-full"
        style={innerCircleStyle}
      >
        {!isCompleted ? (
          <p className="font-medium">
            {showPercentage ? `${Math.round(progress)}%` : step}
          </p>
        ) : (
          <Check size={sizeProps.checkIconSize} className="text-white" />
        )}
      </div>
    </div>
  )
}

export { CircularProgressBar }
