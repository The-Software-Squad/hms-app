import type { Meta, StoryObj } from '@storybook/react'
import { CircularProgressBar } from './CircularProgressBar'

const meta: Meta<typeof CircularProgressBar> = {
  title: 'Components/CircularProgressBar',
  component: CircularProgressBar,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: { type: 'select' },
      options: ['xs', 'sm', 'md', 'lg', 'xl'],
    },
    theme: {
      control: { type: 'select' },
      options: ['black', 'red', 'green', 'blue', 'orange'],
    },
    variant: {
      control: { type: 'select' },
      options: ['solid', 'outline'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    step: 2,
    totalSteps: 4,
  },
}

export const WithPercentage: Story = {
  args: {
    step: 3,
    totalSteps: 4,
    showPercentage: true,
  },
}

export const Completed: Story = {
  args: {
    step: 4,
    totalSteps: 4,
  },
}

export const CompletedOutline: Story = {
  args: {
    step: 4,
    totalSteps: 4,
    variant: 'outline',
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-8">
      <CircularProgressBar size="xs" step={2} totalSteps={4} />
      <CircularProgressBar size="sm" step={2} totalSteps={4} />
      <CircularProgressBar size="md" step={2} totalSteps={4} />
      <CircularProgressBar size="lg" step={2} totalSteps={4} />
      <CircularProgressBar size="xl" step={2} totalSteps={4} />
    </div>
  ),
}

export const Themes: Story = {
  render: () => (
    <div className="flex items-center gap-8">
      <CircularProgressBar theme="black" step={2} totalSteps={4} />
      <CircularProgressBar theme="red" step={2} totalSteps={4} />
      <CircularProgressBar theme="green" step={2} totalSteps={4} />
      <CircularProgressBar theme="blue" step={2} totalSteps={4} />
      <CircularProgressBar theme="orange" step={2} totalSteps={4} />
    </div>
  ),
}

export const CustomTheme: Story = {
  args: {
    step: 3,
    totalSteps: 4,
    theme: {
      primary: '#8B5CF6',
      secondary: '#E9D5FF',
    },
    themeComplete: '#7C3AED',
  },
}
