import React, { forwardRef } from 'react'
import { cn } from '../../utils/cn'
import { InputProps } from './types'

const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      type = 'text',
      label,
      error,
      helperText,
      iconLeft,
      iconRight,
      disabled = false,
      required = false,
      ...props
    },
    ref
  ) => {
    const inputId = React.useId()

    return (
      <div className={cn('space-y-2', className)}>
        {label && (
          <label
            htmlFor={inputId}
            className="block text-sm font-medium text-ink-gray-8"
          >
            {label}
            {required && <span className="text-red-500 ml-1">*</span>}
          </label>
        )}
        
        <div className="relative">
          {iconLeft && (
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              {React.isValidElement(iconLeft) ? (
                React.cloneElement(iconLeft as React.ReactElement, {
                  className: cn('h-4 w-4 text-ink-gray-5', (iconLeft as any).props?.className),
                })
              ) : (
                <span className="h-4 w-4 text-ink-gray-5">{iconLeft}</span>
              )}
            </div>
          )}
          
          <input
            id={inputId}
            type={type}
            className={cn(
              'form-input block w-full',
              {
                'pl-10': iconLeft,
                'pr-10': iconRight,
                'border-red-500 focus:border-red-500 focus:ring-red-500': error,
              }
            )}
            disabled={disabled}
            ref={ref}
            {...props}
          />
          
          {iconRight && (
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
              {React.isValidElement(iconRight) ? (
                React.cloneElement(iconRight as React.ReactElement, {
                  className: cn('h-4 w-4 text-ink-gray-5', (iconRight as any).props?.className),
                })
              ) : (
                <span className="h-4 w-4 text-ink-gray-5">{iconRight}</span>
              )}
            </div>
          )}
        </div>
        
        {(error || helperText) && (
          <p className={cn(
            'text-sm',
            error ? 'text-red-600' : 'text-ink-gray-5'
          )}>
            {error || helperText}
          </p>
        )}
      </div>
    )
  }
)

Input.displayName = 'Input'

export { Input }
