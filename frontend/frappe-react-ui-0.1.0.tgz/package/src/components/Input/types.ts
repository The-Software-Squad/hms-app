import { ComponentProps, ReactNode } from 'react'

export interface InputProps extends Omit<ComponentProps<'input'>, 'size'> {
  label?: string
  error?: string
  helperText?: string
  iconLeft?: ReactNode
  iconRight?: ReactNode
  required?: boolean
}
