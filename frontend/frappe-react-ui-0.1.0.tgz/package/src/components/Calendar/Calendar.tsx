import React, { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Button } from '../Button'
import { dayjs } from '../../utils/dayjs'

export interface CalendarProps {
  value?: Date
  onChange?: (date: Date) => void
  minDate?: Date
  maxDate?: Date
  disabled?: boolean
  disabledDates?: Date[]
  highlightedDates?: Date[]
  showWeekNumbers?: boolean
  firstDayOfWeek?: 0 | 1 // 0 = Sunday, 1 = Monday
  className?: string
  locale?: string
}

export const Calendar: React.FC<CalendarProps> = ({
  value,
  onChange,
  minDate,
  maxDate,
  disabled = false,
  disabledDates = [],
  highlightedDates = [],
  showWeekNumbers = false,
  firstDayOfWeek = 1, // Monday
  className,
  // locale = 'en', // Future feature
}) => {
  const [currentMonth, setCurrentMonth] = useState(
    value ? dayjs(value) : dayjs()
  )

  const today = dayjs()
  const selectedDate = value ? dayjs(value) : null

  // Get days of the week based on first day preference
  const weekDays = React.useMemo(() => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
    if (firstDayOfWeek === 1) {
      return [...days.slice(1), days[0]] // Move Sunday to end
    }
    return days
  }, [firstDayOfWeek])

  // Generate calendar grid
  const calendarDays = React.useMemo(() => {
    const startOfMonth = currentMonth.startOf('month')
    const endOfMonth = currentMonth.endOf('month')
    const startOfCalendar = startOfMonth.startOf('week').add(firstDayOfWeek, 'day')
    const endOfCalendar = endOfMonth.endOf('week').add(firstDayOfWeek, 'day')

    const days = []
    let current = startOfCalendar

    while (current.isBefore(endOfCalendar) || current.isSame(endOfCalendar, 'day')) {
      days.push(current)
      current = current.add(1, 'day')
    }

    return days
  }, [currentMonth, firstDayOfWeek])

  const isDateDisabled = (date: dayjs.Dayjs) => {
    if (disabled) return true
    if (minDate && date.isBefore(dayjs(minDate), 'day')) return true
    if (maxDate && date.isAfter(dayjs(maxDate), 'day')) return true
    if (disabledDates.some(d => date.isSame(dayjs(d), 'day'))) return true
    return false
  }

  const isDateHighlighted = (date: dayjs.Dayjs) => {
    return highlightedDates.some(d => date.isSame(dayjs(d), 'day'))
  }

  const handleDateClick = (date: dayjs.Dayjs) => {
    if (isDateDisabled(date)) return
    onChange?.(date.toDate())
  }

  const navigateMonth = (direction: 'prev' | 'next') => {
    setCurrentMonth(prev => 
      direction === 'prev' ? prev.subtract(1, 'month') : prev.add(1, 'month')
    )
  }

  const getWeekNumber = (date: dayjs.Dayjs) => {
    const startOfYear = date.startOf('year')
    const diff = date.diff(startOfYear, 'day')
    return Math.ceil((diff + 1) / 7)
  }

  return (
    <div className={cn('p-4 bg-surface-white border border-outline-gray-2 rounded-lg', className)}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateMonth('prev')}
          disabled={disabled}
          className="h-8 w-8 p-0"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        
        <h2 className="text-lg font-semibold text-ink-gray-9">
          {currentMonth.format('MMMM YYYY')}
        </h2>
        
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateMonth('next')}
          disabled={disabled}
          className="h-8 w-8 p-0"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-1">
        {/* Week Numbers Header */}
        {showWeekNumbers && (
          <div className="text-xs font-medium text-ink-gray-5 p-2 text-center">
            Wk
          </div>
        )}
        
        {/* Week Day Headers */}
        {weekDays.map((day) => (
          <div
            key={day}
            className="text-xs font-medium text-ink-gray-5 p-2 text-center"
          >
            {day}
          </div>
        ))}

        {/* Calendar Days */}
        {calendarDays.map((date, index) => {
          const isCurrentMonth = date.isSame(currentMonth, 'month')
          const isToday = date.isSame(today, 'day')
          const isSelected = selectedDate?.isSame(date, 'day')
          const isDisabled = isDateDisabled(date)
          const isHighlighted = isDateHighlighted(date)
          const showWeekNum = showWeekNumbers && index % 7 === 0

          return (
            <React.Fragment key={date.format('YYYY-MM-DD')}>
              {/* Week Number */}
              {showWeekNum && (
                <div className="text-xs text-ink-gray-4 p-2 text-center">
                  {getWeekNumber(date)}
                </div>
              )}
              
              {/* Day Cell */}
              <button
                className={cn(
                  'h-8 w-8 text-sm rounded-md transition-colors relative',
                  'hover:bg-surface-gray-2 focus:outline-none focus:ring-2 focus:ring-blue-500',
                  !isCurrentMonth && 'text-ink-gray-4',
                  isCurrentMonth && 'text-ink-gray-8',
                  isToday && 'bg-surface-blue-1 text-ink-blue-3 font-medium',
                  isSelected && 'bg-blue-500 text-white font-medium',
                  isDisabled && 'opacity-50 cursor-not-allowed hover:bg-transparent',
                  isHighlighted && !isSelected && 'bg-green-100 text-green-800'
                )}
                onClick={() => handleDateClick(date)}
                disabled={isDisabled}
              >
                {date.date()}
                
                {/* Highlight dot */}
                {isHighlighted && !isSelected && (
                  <div className="absolute bottom-0.5 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-green-500 rounded-full" />
                )}
              </button>
            </React.Fragment>
          )
        })}
      </div>

      {/* Today Button */}
      <div className="mt-4 flex justify-center">
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const todayDate = today.toDate()
            setCurrentMonth(today)
            onChange?.(todayDate)
          }}
          disabled={disabled || isDateDisabled(today)}
        >
          Today
        </Button>
      </div>
    </div>
  )
}
