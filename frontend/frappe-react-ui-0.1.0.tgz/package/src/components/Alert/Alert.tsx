import React from 'react'
import { X, AlertCircle, CheckCircle, Info, AlertTriangle } from 'lucide-react'
import { cn } from '../../utils/cn'

const alertVariants = {
  default: 'bg-surface-white text-ink-gray-9 border-outline-gray-2',
  destructive: 'border-red-500/50 text-red-900 bg-red-50',
  success: 'border-green-500/50 text-green-900 bg-green-50',
  warning: 'border-yellow-500/50 text-yellow-900 bg-yellow-50',
  info: 'border-blue-500/50 text-blue-900 bg-blue-50',
}

const getAlertClasses = (variant: keyof typeof alertVariants = 'default') => {
  return cn(
    'relative w-full rounded-lg border p-4',
    alertVariants[variant]
  )
}

export interface AlertProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: keyof typeof alertVariants
  dismissible?: boolean
  onDismiss?: () => void
  icon?: React.ReactNode
  title?: string
}

const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ className, variant, dismissible = false, onDismiss, icon, title, children, ...props }, ref) => {
    const defaultIcons = {
      default: <Info className="h-4 w-4" />,
      destructive: <AlertCircle className="h-4 w-4" />,
      success: <CheckCircle className="h-4 w-4" />,
      warning: <AlertTriangle className="h-4 w-4" />,
      info: <Info className="h-4 w-4" />,
    }

    const displayIcon = icon !== undefined ? icon : defaultIcons[variant || 'default']

    return (
      <div
        ref={ref}
        role="alert"
        className={cn(getAlertClasses(variant), className)}
        {...props}
      >
        <div className="flex items-start gap-3">
          {displayIcon && (
            <div className="flex-shrink-0 mt-0.5">
              {displayIcon}
            </div>
          )}
          <div className="flex-1">
            {title && <AlertTitle>{title}</AlertTitle>}
            <div className={title ? 'mt-1' : ''}>{children}</div>
          </div>
          {dismissible && (
            <button
              className="flex-shrink-0 ml-3 inline-flex text-gray-400 hover:text-gray-600 focus:outline-none focus:text-gray-600 transition ease-in-out duration-150"
              onClick={onDismiss}
            >
              <X className="h-4 w-4" />
              <span className="sr-only">Close</span>
            </button>
          )}
        </div>
      </div>
    )
  }
)
Alert.displayName = 'Alert'

const AlertTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLHeadingElement>
>(({ className, ...props }, ref) => (
  <h5
    ref={ref}
    className={cn('mb-1 font-medium leading-none tracking-tight', className)}
    {...props}
  />
))
AlertTitle.displayName = 'AlertTitle'

const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn('text-sm [&_p]:leading-relaxed', className)}
    {...props}
  />
))
AlertDescription.displayName = 'AlertDescription'

export { Alert, AlertTitle, AlertDescription }
