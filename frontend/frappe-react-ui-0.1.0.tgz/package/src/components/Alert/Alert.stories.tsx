import type { Meta, StoryObj } from '@storybook/react'
import React from 'react'
import { Alert, AlertTitle, AlertDescription } from './Alert'
import { AlertCircle, CheckCircle, Info as InfoIcon, AlertTriangle } from 'lucide-react'

const meta: Meta<typeof Alert> = {
  title: 'Components/Alert',
  component: Alert,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['default', 'destructive', 'success', 'warning', 'info'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    children: (
      <>
        <AlertTitle>Default Alert</AlertTitle>
        <AlertDescription>
          This is a default alert message with some information.
        </AlertDescription>
      </>
    ),
  },
}

export const Success: Story = {
  args: {
    variant: 'success',
    children: (
      <>
        <AlertTitle>Success!</AlertTitle>
        <AlertDescription>
          Your changes have been saved successfully.
        </AlertDescription>
      </>
    ),
  },
}

export const Warning: Story = {
  args: {
    variant: 'warning',
    children: (
      <>
        <AlertTitle>Warning</AlertTitle>
        <AlertDescription>
          Please review your settings before proceeding.
        </AlertDescription>
      </>
    ),
  },
}

export const Error: Story = {
  args: {
    variant: 'destructive',
    children: (
      <>
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Something went wrong. Please try again.
        </AlertDescription>
      </>
    ),
  },
}

export const Information: Story = {
  args: {
    variant: 'info',
    children: (
      <>
        <AlertTitle>Information</AlertTitle>
        <AlertDescription>
          Here's some helpful information for you.
        </AlertDescription>
      </>
    ),
  },
}

export const Dismissible: Story = {
  args: {
    variant: 'info',
    dismissible: true,
    onDismiss: () => alert('Alert dismissed!'),
    children: (
      <>
        <AlertTitle>Dismissible Alert</AlertTitle>
        <AlertDescription>
          This alert can be dismissed by clicking the X button.
        </AlertDescription>
      </>
    ),
  },
}

export const CustomIcon: Story = {
  args: {
    variant: 'warning',
    icon: <AlertTriangle className="h-4 w-4" />,
    children: (
      <>
        <AlertTitle>Custom Icon</AlertTitle>
        <AlertDescription>
          This alert uses a custom icon instead of the default one.
        </AlertDescription>
      </>
    ),
  },
}

export const NoIcon: Story = {
  args: {
    variant: 'default',
    icon: null,
    children: (
      <>
        <AlertTitle>No Icon Alert</AlertTitle>
        <AlertDescription>
          This alert has no icon displayed.
        </AlertDescription>
      </>
    ),
  },
}
