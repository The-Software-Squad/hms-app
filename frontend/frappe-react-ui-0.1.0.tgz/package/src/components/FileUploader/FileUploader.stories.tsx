import React, { useState } from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { FileUploader } from './FileUploader'

const meta: Meta<typeof FileUploader> = {
  title: 'Components/FileUploader',
  component: FileUploader,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

// Mock upload function
const mockUpload = async (files: File[]) => {
  console.log('Uploading files:', files.map(f => f.name))
  // Simulate upload delay
  await new Promise(resolve => setTimeout(resolve, 2000))
  console.log('Upload completed!')
}

export const Default: Story = {
  args: {
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const MultipleFiles: Story = {
  args: {
    multiple: true,
    maxFiles: 5,
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const ImagesOnly: Story = {
  args: {
    accept: 'image/*',
    multiple: true,
    maxFiles: 3,
    dropzoneText: 'Drop images here or click to browse',
    browseText: 'Browse Images',
    onFilesChange: (files) => console.log('Images selected:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const DocumentsOnly: Story = {
  args: {
    accept: '.pdf,.doc,.docx,.txt',
    multiple: true,
    dropzoneText: 'Drop documents here (.pdf, .doc, .docx, .txt)',
    browseText: 'Browse Documents',
    onFilesChange: (files) => console.log('Documents selected:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const SingleFile: Story = {
  args: {
    multiple: false,
    accept: 'image/*',
    maxSize: 5 * 1024 * 1024, // 5MB
    dropzoneText: 'Drop a single image here or click to browse',
    browseText: 'Select Image',
    onFilesChange: (files) => console.log('Image selected:', files[0]?.name),
    onUpload: mockUpload,
  },
}

export const WithSizeLimit: Story = {
  args: {
    multiple: true,
    maxSize: 2 * 1024 * 1024, // 2MB
    maxFiles: 3,
    dropzoneText: 'Drop files here (max 2MB each, up to 3 files)',
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const Disabled: Story = {
  args: {
    disabled: true,
    dropzoneText: 'File upload is disabled',
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
  },
}

export const NoPreview: Story = {
  args: {
    multiple: true,
    showPreview: false,
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const NoRemove: Story = {
  args: {
    multiple: true,
    allowRemove: false,
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const CustomText: Story = {
  args: {
    multiple: true,
    dropzoneText: '📁 Drag and drop your files here',
    browseText: '🔍 Choose Files',
    uploadText: '🚀 Start Upload',
    onFilesChange: (files) => console.log('Files changed:', files.map(f => f.name)),
    onUpload: mockUpload,
  },
}

export const ControlledExample: Story = {
  render: () => {
    const [files, setFiles] = useState<File[]>([])
    const [uploadStatus, setUploadStatus] = useState<string>('')
    
    const handleUpload = async (filesToUpload: File[]) => {
      setUploadStatus('Uploading...')
      try {
        await mockUpload(filesToUpload)
        setUploadStatus('Upload successful!')
        setTimeout(() => setUploadStatus(''), 3000)
      } catch (error) {
        setUploadStatus('Upload failed!')
        setTimeout(() => setUploadStatus(''), 3000)
      }
    }
    
    return (
      <div className="w-96 space-y-4">
        <FileUploader
          multiple
          maxFiles={5}
          onFilesChange={setFiles}
          onUpload={handleUpload}
        />
        
        <div className="text-sm text-gray-600">
          <div>Selected files: {files.length}</div>
          {files.length > 0 && (
            <div className="mt-2">
              <strong>Files:</strong>
              <ul className="list-disc list-inside">
                {files.map((file, index) => (
                  <li key={index}>{file.name} ({(file.size / 1024).toFixed(1)} KB)</li>
                ))}
              </ul>
            </div>
          )}
          {uploadStatus && (
            <div className={`mt-2 p-2 rounded ${
              uploadStatus.includes('successful') ? 'bg-green-100 text-green-800' :
              uploadStatus.includes('failed') ? 'bg-red-100 text-red-800' :
              'bg-blue-100 text-blue-800'
            }`}>
              {uploadStatus}
            </div>
          )}
        </div>
      </div>
    )
  },
}

export const ProfilePicture: Story = {
  render: () => {
    const [profilePic, setProfilePic] = useState<File | null>(null)
    const [previewUrl, setPreviewUrl] = useState<string>('')
    
    const handleFileChange = (files: File[]) => {
      const file = files[0]
      if (file) {
        setProfilePic(file)
        const url = URL.createObjectURL(file)
        setPreviewUrl(url)
      }
    }
    
    return (
      <div className="w-80 space-y-4">
        <div className="text-center">
          <h3 className="text-lg font-semibold mb-2">Profile Picture Upload</h3>
          {previewUrl && (
            <div className="mb-4">
              <img 
                src={previewUrl} 
                alt="Preview" 
                className="w-24 h-24 rounded-full mx-auto object-cover border-4 border-gray-200"
              />
            </div>
          )}
        </div>
        
        <FileUploader
          accept="image/*"
          multiple={false}
          maxSize={5 * 1024 * 1024} // 5MB
          dropzoneText="Drop your profile picture here"
          browseText="Choose Profile Picture"
          uploadText="Save Picture"
          onFilesChange={handleFileChange}
          onUpload={async (files) => {
            console.log('Saving profile picture:', files[0]?.name)
            await new Promise(resolve => setTimeout(resolve, 1500))
            alert('Profile picture saved!')
          }}
        />
        
        {profilePic && (
          <div className="text-sm text-gray-600 text-center">
            Selected: {profilePic.name} ({(profilePic.size / 1024).toFixed(1)} KB)
          </div>
        )}
      </div>
    )
  },
}
