import React, { useRef, useState, useCallback } from 'react'
import { Upload, X, File, Image, FileText } from 'lucide-react'
import { cn } from '../../utils/cn'
import { Button } from '../Button'
import { Progress } from '../Progress'

export interface FileUploaderProps {
  accept?: string
  multiple?: boolean
  maxSize?: number // in bytes
  maxFiles?: number
  onFilesChange?: (files: File[]) => void
  onUpload?: (files: File[]) => Promise<void>
  disabled?: boolean
  className?: string
  dropzoneText?: string
  browseText?: string
  uploadText?: string
  showPreview?: boolean
  allowRemove?: boolean
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  accept,
  multiple = false,
  maxSize = 10 * 1024 * 1024, // 10MB
  maxFiles = 10,
  onFilesChange,
  onUpload,
  disabled = false,
  className,
  dropzoneText = 'Drop files here or click to browse',
  browseText = 'Browse Files',
  uploadText = 'Upload',
  showPreview = true,
  allowRemove = true,
}) => {
  const [files, setFiles] = useState<File[]>([])
  const [dragActive, setDragActive] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const inputRef = useRef<HTMLInputElement>(null)

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes'
    const k = 1024
    const sizes = ['Bytes', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) {
      return <Image className="h-4 w-4" />
    } else if (file.type.includes('text') || file.type.includes('document')) {
      return <FileText className="h-4 w-4" />
    }
    return <File className="h-4 w-4" />
  }

  const validateFile = (file: File) => {
    if (maxSize && file.size > maxSize) {
      return `File size exceeds ${formatFileSize(maxSize)}`
    }
    return null
  }

  const handleFiles = useCallback((newFiles: FileList | File[]) => {
    const fileArray = Array.from(newFiles)
    const validFiles: File[] = []
    
    for (const file of fileArray) {
      const error = validateFile(file)
      if (!error) {
        validFiles.push(file)
      }
    }

    const totalFiles = multiple ? [...files, ...validFiles] : validFiles
    const limitedFiles = totalFiles.slice(0, maxFiles)
    
    setFiles(limitedFiles)
    onFilesChange?.(limitedFiles)
  }, [files, multiple, maxFiles, maxSize])

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true)
    } else if (e.type === 'dragleave') {
      setDragActive(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    
    if (disabled) return
    
    const droppedFiles = e.dataTransfer.files
    if (droppedFiles) {
      handleFiles(droppedFiles)
    }
  }, [disabled, handleFiles])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      handleFiles(e.target.files)
    }
  }

  const removeFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index)
    setFiles(newFiles)
    onFilesChange?.(newFiles)
  }

  const handleUpload = async () => {
    if (!onUpload || files.length === 0) return
    
    setUploading(true)
    setUploadProgress(0)
    
    try {
      // Simulate progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(interval)
            return prev
          }
          return prev + 10
        })
      }, 200)
      
      await onUpload(files)
      setUploadProgress(100)
      
      setTimeout(() => {
        setFiles([])
        setUploadProgress(0)
        setUploading(false)
        onFilesChange?.([])
      }, 1000)
    } catch (error) {
      setUploading(false)
      setUploadProgress(0)
    }
  }

  return (
    <div className={cn('space-y-4', className)}>
      {/* Dropzone */}
      <div
        className={cn(
          'border-2 border-dashed rounded-lg p-6 text-center transition-colors',
          dragActive && 'border-blue-500 bg-blue-50',
          !dragActive && 'border-outline-gray-2 hover:border-outline-gray-3',
          disabled && 'opacity-50 cursor-not-allowed'
        )}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <Upload className="mx-auto h-8 w-8 text-ink-gray-4 mb-2" />
        <p className="text-sm text-ink-gray-6 mb-2">{dropzoneText}</p>
        <Button
          variant="outline"
          size="sm"
          disabled={disabled}
          onClick={() => inputRef.current?.click()}
        >
          {browseText}
        </Button>
        
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={handleInputChange}
          disabled={disabled}
          className="hidden"
        />
      </div>

      {/* File Preview */}
      {showPreview && files.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-ink-gray-8">
            Selected Files ({files.length})
          </h4>
          <div className="space-y-2">
            {files.map((file, index) => (
              <div
                key={`${file.name}-${index}`}
                className="flex items-center justify-between p-3 border border-outline-gray-2 rounded-lg"
              >
                <div className="flex items-center space-x-3">
                  {getFileIcon(file)}
                  <div>
                    <p className="text-sm font-medium text-ink-gray-8">
                      {file.name}
                    </p>
                    <p className="text-xs text-ink-gray-5">
                      {formatFileSize(file.size)}
                    </p>
                  </div>
                </div>
                
                {allowRemove && !uploading && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                    className="h-6 w-6 p-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Upload Progress */}
      {uploading && (
        <div className="space-y-2">
          <Progress value={uploadProgress} label="Uploading..." showValue />
        </div>
      )}

      {/* Upload Button */}
      {onUpload && files.length > 0 && !uploading && (
        <Button
          variant="solid"
          theme="blue"
          onClick={handleUpload}
          disabled={disabled}
          className="w-full"
        >
          {uploadText} ({files.length} file{files.length !== 1 ? 's' : ''})
        </Button>
      )}
    </div>
  )
}
