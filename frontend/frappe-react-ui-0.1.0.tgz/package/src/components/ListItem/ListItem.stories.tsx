import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { ListItem } from './ListItem'
import { MoreHorizontal, Edit, Trash2 } from 'lucide-react'

const meta: Meta<typeof ListItem> = {
  title: 'Components/ListItem',
  component: ListItem,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    title: 'John Doe',
    subtitle: 'Software Engineer at Acme Corp',
  },
}

export const WithMultilineSubtitle: Story = {
  args: {
    title: 'Project Alpha',
    subtitle: 'A comprehensive project management solution\nDue date: December 31, 2024',
  },
}

export const WithActions: Story = {
  args: {
    title: 'Jane Smith',
    subtitle: 'Product Manager',
    actions: (
      <div className="flex gap-2">
        <button className="p-1 text-gray-500 hover:text-gray-700">
          <Edit className="h-4 w-4" />
        </button>
        <button className="p-1 text-gray-500 hover:text-gray-700">
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    ),
  },
}

export const WithCustomSubtitle: Story = {
  args: {
    title: 'Sarah Wilson',
    subtitleSlot: (
      <div className="flex items-center gap-2">
        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
          Active
        </span>
        <span className="text-sm text-gray-600">Last seen 2 hours ago</span>
      </div>
    ),
  },
}

export const UserList: Story = {
  render: () => (
    <div className="w-full max-w-md border rounded-lg divide-y">
      <ListItem
        title="Alice Johnson"
        subtitle="alice@example.com\nAdmin"
        actions={
          <button className="p-1 text-gray-500 hover:text-gray-700">
            <MoreHorizontal className="h-4 w-4" />
          </button>
        }
      />
      <ListItem
        title="Bob Smith"
        subtitle="bob@example.com\nEditor"
        actions={
          <button className="p-1 text-gray-500 hover:text-gray-700">
            <MoreHorizontal className="h-4 w-4" />
          </button>
        }
      />
      <ListItem
        title="Carol Davis"
        subtitle="carol@example.com\nViewer"
        actions={
          <button className="p-1 text-gray-500 hover:text-gray-700">
            <MoreHorizontal className="h-4 w-4" />
          </button>
        }
      />
    </div>
  ),
}

export const TaskList: Story = {
  render: () => (
    <div className="w-full max-w-lg space-y-1">
      <ListItem
        title="Complete project proposal"
        subtitle="High priority • Due tomorrow"
        actions={
          <div className="flex gap-1">
            <button className="px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50">Mark Done</button>
            <button className="p-1 text-gray-500 hover:text-gray-700">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>
        }
      />
      <ListItem
        title="Review design mockups"
        subtitle="Medium priority • Due next week"
        actions={
          <div className="flex gap-1">
            <button className="px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50">Mark Done</button>
            <button className="p-1 text-gray-500 hover:text-gray-700">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>
        }
      />
      <ListItem
        title="Update documentation"
        subtitle="Low priority • No due date"
        actions={
          <div className="flex gap-1">
            <button className="px-3 py-1 text-sm border border-gray-300 rounded hover:bg-gray-50">Mark Done</button>
            <button className="p-1 text-gray-500 hover:text-gray-700">
              <MoreHorizontal className="h-4 w-4" />
            </button>
          </div>
        }
      />
    </div>
  ),
}
