import React, { ReactNode } from 'react'
import { cn } from '../../utils/cn'

export interface ListItemProps {
  title: string
  subtitle?: string
  subtitleSlot?: ReactNode
  actions?: ReactNode
  className?: string
}

const ListItem: React.FC<ListItemProps> = ({
  title,
  subtitle,
  subtitleSlot,
  actions,
  className,
}) => {
  const secondaryText = subtitle ? subtitle.replace('\n', '<br>') : ''

  return (
    <div className={cn('flex items-center justify-between py-3', className)}>
      <div>
        <h3 className="text-base font-medium text-gray-900">
          {title}
        </h3>
        {(secondaryText || subtitleSlot) && (
          <div className="mt-1">
            {secondaryText && (
              <span 
                className="text-base text-gray-600"
                dangerouslySetInnerHTML={{ __html: secondaryText }}
              />
            )}
            {subtitleSlot}
          </div>
        )}
      </div>
      {actions}
    </div>
  )
}

export { ListItem }
