import React from 'react'
import { ChevronRight, Home } from 'lucide-react'
import { cn } from '../../utils/cn'

export interface BreadcrumbItem {
  label: string
  href?: string
  onClick?: () => void
  disabled?: boolean
}

export interface BreadcrumbsProps {
  items: BreadcrumbItem[]
  separator?: React.ReactNode
  showHome?: boolean
  homeHref?: string
  onHomeClick?: () => void
  className?: string
  maxItems?: number
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({
  items,
  separator = <ChevronRight className="h-4 w-4" />,
  showHome = false,
  homeHref = '/',
  onHomeClick,
  className,
  maxItems,
}) => {
  const displayItems = maxItems && items.length > maxItems 
    ? [
        ...items.slice(0, 1),
        { label: '...', disabled: true },
        ...items.slice(-(maxItems - 2))
      ]
    : items

  const allItems = showHome 
    ? [{ label: 'Home', href: homeHref, onClick: onHomeClick }, ...displayItems]
    : displayItems

  return (
    <nav aria-label="Breadcrumb" className={cn('flex items-center space-x-1', className)}>
      <ol className="flex items-center space-x-1">
        {allItems.map((item, index) => (
          <li key={index} className="flex items-center">
            {index > 0 && (
              <span className="mx-2 text-ink-gray-4">
                {separator}
              </span>
            )}
            
            {item.label === 'Home' && showHome ? (
              <BreadcrumbLink
                href={item.href}
                onClick={item.onClick}
                disabled={item.disabled}
                className="flex items-center"
              >
                <Home className="h-4 w-4" />
                <span className="sr-only">Home</span>
              </BreadcrumbLink>
            ) : item.disabled || item.label === '...' ? (
              <span className="text-ink-gray-5 cursor-default">
                {item.label}
              </span>
            ) : index === allItems.length - 1 ? (
              <span className="text-ink-gray-8 font-medium" aria-current="page">
                {item.label}
              </span>
            ) : (
              <BreadcrumbLink
                href={item.href}
                onClick={item.onClick}
                disabled={item.disabled}
              >
                {item.label}
              </BreadcrumbLink>
            )}
          </li>
        ))}
      </ol>
    </nav>
  )
}

interface BreadcrumbLinkProps {
  href?: string
  onClick?: () => void
  disabled?: boolean
  children: React.ReactNode
  className?: string
}

const BreadcrumbLink: React.FC<BreadcrumbLinkProps> = ({
  href,
  onClick,
  disabled,
  children,
  className,
}) => {
  const handleClick = (e: React.MouseEvent) => {
    if (disabled) {
      e.preventDefault()
      return
    }
    if (onClick) {
      e.preventDefault()
      onClick()
    }
  }

  const linkClasses = cn(
    'text-ink-gray-6 hover:text-ink-gray-8 transition-colors',
    disabled && 'cursor-not-allowed opacity-50',
    className
  )

  if (href && !onClick) {
    return (
      <a 
        href={href} 
        className={linkClasses}
        onClick={handleClick}
        aria-disabled={disabled}
      >
        {children}
      </a>
    )
  }

  return (
    <button
      type="button"
      className={linkClasses}
      onClick={handleClick}
      disabled={disabled}
    >
      {children}
    </button>
  )
}
