import React from 'react'
import type { Meta, StoryObj } from '@storybook/react'
import { Breadcrumbs } from './Breadcrumbs'
import { Home, Folder, FileText } from 'lucide-react'

const meta: Meta<typeof Breadcrumbs> = {
  title: 'Components/Breadcrumbs',
  component: Breadcrumbs,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {
    items: [
      { label: 'Home', href: '/' },
      { label: 'Products', href: '/products' },
      { label: 'Laptops', href: '/products/laptops' },
      { label: 'MacBook Pro' },
    ],
  },
}

export const WithIcons: Story = {
  args: {
    items: [
      { label: 'Home', href: '/', icon: <Home className="h-4 w-4" /> },
      { label: 'Documents', href: '/documents', icon: <Folder className="h-4 w-4" /> },
      { label: 'Projects', href: '/documents/projects', icon: <Folder className="h-4 w-4" /> },
      { label: 'README.md', icon: <FileText className="h-4 w-4" /> },
    ],
  },
}

export const LongPath: Story = {
  args: {
    items: [
      { label: 'Home', href: '/' },
      { label: 'Organization', href: '/org' },
      { label: 'Department', href: '/org/dept' },
      { label: 'Team', href: '/org/dept/team' },
      { label: 'Projects', href: '/org/dept/team/projects' },
      { label: 'Current Project', href: '/org/dept/team/projects/current' },
      { label: 'Task Details' },
    ],
  },
}

export const SingleItem: Story = {
  args: {
    items: [
      { label: 'Dashboard' },
    ],
  },
}

export const TwoItems: Story = {
  args: {
    items: [
      { label: 'Home', href: '/' },
      { label: 'Settings' },
    ],
  },
}
