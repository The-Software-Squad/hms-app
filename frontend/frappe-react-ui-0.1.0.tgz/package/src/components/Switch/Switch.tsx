import React, { forwardRef } from 'react'
import * as SwitchPrimitive from '@radix-ui/react-switch'
import { cn } from '../../utils/cn'

export interface SwitchProps extends React.ComponentPropsWithoutRef<typeof SwitchPrimitive.Root> {
  label?: string
  description?: string
  error?: string
  size?: 'sm' | 'md' | 'lg'
}

const Switch = forwardRef<
  React.ElementRef<typeof SwitchPrimitive.Root>,
  SwitchProps
>(({ className, label, description, error, size = 'md', ...props }, ref) => {
  const switchId = React.useId()

  const sizeClasses = {
    sm: 'h-5 w-9',
    md: 'h-6 w-11',
    lg: 'h-7 w-13',
  }

  const thumbSizeClasses = {
    sm: 'h-4 w-4 data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0',
    md: 'h-5 w-5 data-[state=checked]:translate-x-5 data-[state=unchecked]:translate-x-0',
    lg: 'h-6 w-6 data-[state=checked]:translate-x-6 data-[state=unchecked]:translate-x-0',
  }

  if (label || description) {
    return (
      <div className="space-y-2">
        <div className="flex items-center space-x-3">
          <SwitchPrimitive.Root
            ref={ref}
            id={switchId}
            className={cn(
              'peer inline-flex shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-outline-gray-3 focus-visible:ring-offset-2 focus-visible:ring-offset-surface-white disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-blue-500 data-[state=unchecked]:bg-surface-gray-3',
              sizeClasses[size],
              error && 'ring-2 ring-red-500',
              className
            )}
            {...props}
          >
            <SwitchPrimitive.Thumb
              className={cn(
                'pointer-events-none block rounded-full bg-surface-white shadow-lg ring-0 transition-transform',
                thumbSizeClasses[size]
              )}
            />
          </SwitchPrimitive.Root>
          
          <div className="grid gap-1.5 leading-none">
            {label && (
              <label
                htmlFor={switchId}
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                {label}
              </label>
            )}
            {description && (
              <p className="text-sm text-ink-gray-5">
                {description}
              </p>
            )}
          </div>
        </div>
        
        {error && (
          <p className="text-sm text-red-600">{error}</p>
        )}
      </div>
    )
  }

  return (
    <SwitchPrimitive.Root
      ref={ref}
      className={cn(
        'peer inline-flex shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-outline-gray-3 focus-visible:ring-offset-2 focus-visible:ring-offset-surface-white disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-blue-500 data-[state=unchecked]:bg-surface-gray-3',
        sizeClasses[size],
        error && 'ring-2 ring-red-500',
        className
      )}
      {...props}
    >
      <SwitchPrimitive.Thumb
        className={cn(
          'pointer-events-none block rounded-full bg-surface-white shadow-lg ring-0 transition-transform',
          thumbSizeClasses[size]
        )}
      />
    </SwitchPrimitive.Root>
  )
})

Switch.displayName = SwitchPrimitive.Root.displayName

export { Switch }
