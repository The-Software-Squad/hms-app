import type { Meta, StoryObj } from '@storybook/react'
import { Switch } from './Switch'
import { useState } from 'react'

const meta: Meta<typeof Switch> = {
  title: 'Components/Switch',
  component: Switch,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
    },
  },
}

export default meta
type Story = StoryObj<typeof meta>

export const Default: Story = {
  args: {},
}

export const WithLabel: Story = {
  args: {
    label: 'Enable notifications',
  },
}

export const WithDescription: Story = {
  args: {
    label: 'Dark mode',
    description: 'Switch to dark theme for better viewing in low light.',
  },
}

export const WithError: Story = {
  args: {
    label: 'Required setting',
    error: 'This setting must be enabled',
  },
}

export const Disabled: Story = {
  args: {
    label: 'Disabled switch',
    disabled: true,
  },
}

export const Sizes: Story = {
  render: () => (
    <div className="space-y-4">
      <Switch size="sm" label="Small switch" />
      <Switch size="md" label="Medium switch" />
      <Switch size="lg" label="Large switch" />
    </div>
  ),
}

export const Controlled: Story = {
  render: () => {
    const [enabled, setEnabled] = useState(false)
    
    return (
      <div className="space-y-4">
        <Switch
          checked={enabled}
          onCheckedChange={setEnabled}
          label="Controlled switch"
          description={`Current state: ${enabled ? 'enabled' : 'disabled'}`}
        />
        <button
          onClick={() => setEnabled(!enabled)}
          className="px-3 py-1 bg-blue-500 text-white rounded text-sm"
        >
          Toggle
        </button>
      </div>
    )
  },
}
