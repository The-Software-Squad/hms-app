import type { Meta, StoryObj } from '@storybook/react'
import { 
  Button, 
  Input, 
  Card, 
  Badge, 
  Avatar, 
  AvatarImage, 
  AvatarFallback,
  Progress,
  Alert,
  AlertTitle,
  AlertDescription,
  Checkbox,
  Switch,
  Spinner
} from '../index'
import { CheckCircle, User, Settings, Bell } from 'lucide-react'

const meta: Meta = {
  title: 'Overview/Component Showcase',
  parameters: {
    layout: 'fullscreen',
  },
  tags: ['autodocs'],
}

export default meta
type Story = StoryObj<typeof meta>

export const AllComponents: Story = {
  render: () => (
    <div className="p-8 space-y-8 max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-ink-gray-9 mb-4">
          Frappe React UI Components
        </h1>
        <p className="text-lg text-ink-gray-6">
          A comprehensive React port of the frappe-ui Vue.js library
        </p>
      </div>

      {/* Buttons Section */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Buttons</h2>
        <div className="space-y-4">
          <div className="flex flex-wrap gap-4">
            <Button variant="solid" theme="blue">Primary</Button>
            <Button variant="subtle" theme="gray">Secondary</Button>
            <Button variant="outline" theme="green">Success</Button>
            <Button variant="ghost" theme="red">Danger</Button>
            <Button loading>Loading</Button>
          </div>
          <div className="flex flex-wrap gap-4">
            <Button size="sm">Small</Button>
            <Button size="md">Medium</Button>
            <Button size="lg">Large</Button>
            <Button size="xl">Extra Large</Button>
          </div>
        </div>
      </Card>

      {/* Form Components */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Form Components</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <Input 
              label="Email Address" 
              placeholder="Enter your email"
              iconLeft={<User className="h-4 w-4" />}
            />
            <div className="space-y-2">
              <Checkbox label="Accept terms and conditions" />
              <Switch label="Enable notifications" />
            </div>
          </div>
          <div className="space-y-4">
            <Progress value={75} label="Profile Completion" showValue />
            <div className="flex items-center gap-4">
              <Spinner size="sm" />
              <span className="text-sm text-ink-gray-6">Loading...</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Display Components */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Display Components</h2>
        <div className="space-y-6">
          <div className="flex flex-wrap gap-4">
            <Badge variant="default" theme="blue">New</Badge>
            <Badge variant="secondary" theme="green">Active</Badge>
            <Badge variant="outline" theme="yellow">Pending</Badge>
            <Badge variant="destructive">Error</Badge>
          </div>
          
          <div className="flex items-center gap-4">
            <Avatar>
              <AvatarImage src="https://github.com/shadcn.png" alt="User" />
              <AvatarFallback>JD</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">John Doe</p>
              <p className="text-sm text-ink-gray-6">john@example.com</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Alerts */}
      <div className="space-y-4">
        <Alert variant="success">
          <CheckCircle className="h-4 w-4" />
          <AlertTitle>Success!</AlertTitle>
          <AlertDescription>
            Your profile has been updated successfully.
          </AlertDescription>
        </Alert>
        
        <Alert variant="info">
          <Bell className="h-4 w-4" />
          <AlertTitle>Information</AlertTitle>
          <AlertDescription>
            New features are available in this update.
          </AlertDescription>
        </Alert>
      </div>

      {/* Dashboard Example */}
      <Card className="p-6">
        <h2 className="text-2xl font-semibold mb-4">Dashboard Example</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card variant="outline" className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-ink-gray-6">Total Users</p>
                <p className="text-2xl font-bold">1,234</p>
              </div>
              <Badge variant="secondary" theme="green">+12%</Badge>
            </div>
          </Card>
          
          <Card variant="outline" className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-ink-gray-6">Revenue</p>
                <p className="text-2xl font-bold">$45,678</p>
              </div>
              <Badge variant="secondary" theme="blue">+8%</Badge>
            </div>
          </Card>
          
          <Card variant="outline" className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-ink-gray-6">Orders</p>
                <p className="text-2xl font-bold">892</p>
              </div>
              <Badge variant="secondary" theme="yellow">+5%</Badge>
            </div>
          </Card>
        </div>
      </Card>

      {/* Footer */}
      <div className="text-center pt-8 border-t border-outline-gray-1">
        <p className="text-ink-gray-6">
          Built with ❤️ using Frappe React UI • 
          <a href="#" className="text-blue-500 hover:underline ml-1">
            View Documentation
          </a>
        </p>
      </div>
    </div>
  ),
}

export const ThemeShowcase: Story = {
  render: () => (
    <div className="p-8 space-y-8">
      <h1 className="text-3xl font-bold text-center mb-8">Theme Showcase</h1>
      
      {['gray', 'blue', 'green', 'red'].map((theme) => (
        <Card key={theme} className="p-6">
          <h2 className="text-xl font-semibold mb-4 capitalize">{theme} Theme</h2>
          <div className="space-y-4">
            <div className="flex flex-wrap gap-4">
              <Button variant="solid" theme={theme as any}>Solid</Button>
              <Button variant="subtle" theme={theme as any}>Subtle</Button>
              <Button variant="outline" theme={theme as any}>Outline</Button>
              <Button variant="ghost" theme={theme as any}>Ghost</Button>
            </div>
            <div className="flex flex-wrap gap-4">
              <Badge variant="default" theme={theme as any}>Default</Badge>
              <Badge variant="secondary" theme={theme as any}>Secondary</Badge>
              <Badge variant="outline" theme={theme as any}>Outline</Badge>
            </div>
          </div>
        </Card>
      ))}
    </div>
  ),
}
