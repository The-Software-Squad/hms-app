<div align="center" markdown="1">

<img src="https://github.com/user-attachments/assets/0a81cdc1-d957-47a9-b151-f5571be0d038" width="80" />

# Frappe React UI
**Rapidly build modern frontends for Frappe apps with React**

React port of the popular [frappe-ui](https://github.com/frappe/frappe-ui) Vue.js component library.

</div>

## Frappe React UI

Frappe React UI provides a set of React components and utilities for rapid UI development. Components are built using React 18, TypeScript, and Tailwind CSS. Along with generic components like Button, Dialog, Input, etc., it also contains utilities for handling server-side data fetching and state management.

### Motivation

This is a React port of the excellent [frappe-ui](https://github.com/frappe/frappe-ui) Vue.js library, maintaining the same API design and component behavior while leveraging React's ecosystem and patterns.

### Under the Hood

- **React 18**: Latest React with concurrent features
- **TypeScript**: Full type safety and excellent DX
- **TailwindCSS**: Utility-first CSS framework with custom design tokens
- **Radix UI**: Unstyled, accessible UI primitives
- **TipTap**: ProseMirror-based rich-text editor with React integration
- **TanStack Query**: Powerful data fetching and caching
- **Zustand**: Lightweight state management
- **dayjs**: Minimal date manipulation library

## Installation

```sh
npm install frappe-react-ui
# or
yarn add frappe-react-ui
```

## Usage

Import the components and start using them in your React app:

```tsx
import { Button, Input, Dialog } from 'frappe-react-ui'
import 'frappe-react-ui/dist/style.css'

function App() {
  return (
    <div>
      <Button theme="blue" variant="solid">
        Click me
      </Button>
    </div>
  )
}
```

In your `tailwind.config.js` file, include the frappe-react-ui preset:

```js
module.exports = {
  presets: [
    require('frappe-react-ui/tailwind/preset')
  ],
  // your config
}
```

## Components

All components from frappe-ui have been ported to React with the same API:

- **Form Controls**: Button, Input, Textarea, Select, Checkbox, Switch
- **Layout**: Card, Dialog, Popover, Tabs, Sidebar
- **Data Display**: Avatar, Badge, Progress, Rating, Toast
- **Navigation**: Breadcrumbs, Dropdown, CommandPalette
- **Data**: ListView, DatePicker, Calendar, Charts
- **Text**: TextEditor (TipTap-based rich text editor)

## Data Fetching

React hooks for Frappe backend integration:

```tsx
import { useCall, useList, useDoc } from 'frappe-react-ui'

function MyComponent() {
  const { data, loading, error } = useCall({
    url: '/api/method/my_method',
    params: { name: 'test' }
  })

  const { data: users } = useList({
    doctype: 'User',
    filters: { enabled: 1 }
  })

  return <div>{/* your component */}</div>
}
```

## License

MIT
