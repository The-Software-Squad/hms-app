import path from 'path'
import fs from 'fs'
import { getAppName } from './utils.js'

export function buildConfig({
  outDir,
  baseUrl,
  indexHtmlPath,
  emptyOutDir = true,
  sourcemap = true,
} = {}) {
  const appName = getAppName()
  
  // Auto-detect paths if not provided
  if (!outDir) {
    outDir = `../${appName}/public/frontend`
  }
  
  if (!baseUrl) {
    baseUrl = `/assets/${appName}/frontend/`
  }

  return {
    name: 'frappe-react-ui-build-config',
    config: (config, { command }) => {
      if (command === 'build') {
        return {
          base: baseUrl,
          build: {
            outDir,
            emptyOutDir,
            sourcemap,
            rollupOptions: {
              output: {
                // Ensure consistent asset naming for Frappe
                assetFileNames: (assetInfo) => {
                  const info = assetInfo.name.split('.')
                  const ext = info[info.length - 1]
                  if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(ext)) {
                    return `assets/images/[name]-[hash][extname]`
                  }
                  if (/css/i.test(ext)) {
                    return `assets/css/[name]-[hash][extname]`
                  }
                  return `assets/[name]-[hash][extname]`
                },
                chunkFileNames: 'assets/js/[name]-[hash].js',
                entryFileNames: 'assets/js/[name]-[hash].js',
              },
            },
          },
        }
      }
    },
    closeBundle: async () => {
      // Copy index.html to specified location after build
      if (indexHtmlPath) {
        try {
          const builtIndexPath = path.resolve(outDir, 'index.html')
          const targetPath = path.resolve(indexHtmlPath)
          
          if (fs.existsSync(builtIndexPath)) {
            // Ensure target directory exists
            const targetDir = path.dirname(targetPath)
            if (!fs.existsSync(targetDir)) {
              fs.mkdirSync(targetDir, { recursive: true })
            }
            
            // Copy the built index.html
            fs.copyFileSync(builtIndexPath, targetPath)
            console.log(`✓ Copied index.html to ${indexHtmlPath}`)
          }
        } catch (error) {
          console.error(`✗ Failed to copy index.html: ${error.message}`)
        }
      }
    },
  }
}
