import { frappeProxy } from './frappeProxy.js'
import { frappeTypes } from './frappeTypes.js'
import { jinjaBootData } from './jinjaBootData.js'
import { buildConfig } from './buildConfig.js'

function frappeReactUIPlugin(
  options = {
    frappeProxy: true,
    frappeTypes: true,
    jinjaBootData: true,
    buildConfig: true,
  },
) {
  let plugins = []

  if (options.frappeProxy) {
    plugins.push(frappeProxy(options.frappeProxy))
  }

  if (options.frappeTypes) {
    plugins.push(frappeTypes(options.frappeTypes))
  }

  if (options.jinjaBootData) {
    plugins.push(jinjaBootData(options.jinjaBootData))
  }

  if (options.buildConfig) {
    plugins.push(buildConfig(options.buildConfig))
  }

  return plugins
}

// Export individual plugins for direct usage
export { frappeProxy, frappeTypes, jinjaBootData, buildConfig }

// Export the combined plugin as default and named export
export default frappeReactUIPlugin
export { frappeReactUIPlugin }
