import fs from 'fs'
import path from 'path'

export function getCommonSiteConfig() {
  try {
    const configPath = path.resolve('../sites/common_site_config.json')
    if (fs.existsSync(configPath)) {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'))
    }
  } catch (error) {
    console.warn('Could not read common_site_config.json:', error.message)
  }
  return null
}

export function getAppName() {
  try {
    const packageJsonPath = path.resolve('package.json')
    if (fs.existsSync(packageJsonPath)) {
      const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'))
      return packageJson.name
    }
  } catch (error) {
    console.warn('Could not read package.json:', error.message)
  }
  return 'app'
}

export function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true })
  }
}
