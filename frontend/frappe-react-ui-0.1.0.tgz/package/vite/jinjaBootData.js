export function jinjaBootData(options = {}) {
  return {
    name: 'frappe-react-ui-jinja-boot-data',
    transformIndexHtml: {
      enforce: 'pre',
      transform(html) {
        // During Vite build, always use placeholder to avoid Jinja syntax issues
        // The actual Jinja injection happens server-side by Frappe
        const placeholderScript = `
<!-- Frappe Boot Data Placeholder -->
<script>
  // Boot data will be injected by Frappe server
  window.boot = window.boot || {};
</script>
<!-- End Frappe Boot Data Placeholder -->`

        return html.replace('</head>', `${placeholderScript}\n</head>`)
      },
    },
  }
}
