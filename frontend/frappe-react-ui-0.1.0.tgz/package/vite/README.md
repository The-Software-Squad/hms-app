# Frappe React UI Vite Plugins

A collection of Vite plugins specifically designed for React applications that integrate with Frappe backend systems.

## Installation

```bash
npm install frappe-react-ui
```

## Usage

In your `vite.config.js` file:

```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import frappeReactUI from 'frappe-react-ui/vite'

export default defineConfig({
  plugins: [
    react(),
    ...frappeReactUI({
      frappeProxy: true, // Setup proxy to Frappe backend
      jinjaBootData: true, // Inject server-side boot data
      // Generate TypeScript interfaces from DocTypes
      frappeTypes: {
        input: {
          your_app_name: ['User', 'Task', 'Project'],
        },
      },
      // Production build config for Frappe deployment
      buildConfig: {
        indexHtmlPath: '../your_app/www/frontend.html',
      },
    }),
  ],
})
```

## Plugins

### 🔌 Frappe Proxy Plugin

Automatically configures a development server that proxies requests to your Frappe backend.

#### Features

- Sets up a proxy for backend routes (`/api`, `/app`, etc.)
- Automatically detects Frappe port from `common_site_config.json`
- Smart port calculation based on Frappe webserver port

#### Configuration

```javascript
frappeReactUI({
  frappeProxy: {
    port: 8080, // Frontend dev server port (auto-calculated if not provided)
    source: '^/(app|login|api|assets|files|private)', // Routes to proxy
  },
})
```

### 🏗️ Frappe Types Plugin

Generates TypeScript interfaces for your Frappe DocTypes, providing type safety when working with Frappe data in React components.

#### Features

- Automatically generates TypeScript interfaces from DocType JSON files
- Creates and updates interfaces only when DocTypes change
- Supports nested DocTypes (Table fields)
- Hot reloading when DocType definitions change

#### Configuration

```javascript
frappeReactUI({
  frappeTypes: {
    input: {
      your_app_name: ['User', 'Task', 'Project', 'Settings'],
    },
    output: 'src/types/doctypes.ts', // (optional, default shown)
    appsPath: '../apps', // (optional, default shown)
  },
})
```

#### Generated Types Example

```typescript
// Generated in src/types/doctypes.ts
export interface User extends DocType {
  /** Full Name: Data */
  full_name: string;
  /** Email: Data */
  email: string;
  /** Role Profile: Link (Role Profile) */
  role_profile?: string;
  /** Enabled: Check */
  enabled: 0 | 1;
}

export interface Task extends DocType {
  /** Subject: Data */
  subject: string;
  /** Status: Select */
  status: 'Open' | 'Working' | 'Pending Review' | 'Completed' | 'Cancelled';
  /** Assigned To: Link (User) */
  assigned_to?: string;
}
```

### 🌐 Jinja Boot Data Plugin

Injects Jinja template code that reads keys from the `boot` context object and sets them in the browser's `window` object. Essential for Frappe authentication and configuration.

#### Configuration

```javascript
frappeReactUI({
  jinjaBootData: true,
})
```

#### Usage

In your Python/Jinja template:

```python
def get_context(context):
    context.boot = {
        "csrf_token": frappe.session.csrf_token,
        "user": frappe.session.user,
        "user_info": frappe.session.user_info,
        "site_name": frappe.local.site,
    }
    return context
```

In your React code:

```typescript
// Access injected data
declare global {
  interface Window {
    csrf_token: string;
    user: string;
    user_info: any;
    site_name: string;
  }
}

// Use in your React components
function MyComponent() {
  const currentUser = window.user;
  const csrfToken = window.csrf_token;
  
  // Use with frappe-react-ui data fetching hooks
  const { data } = useCall({
    url: '/api/method/my_method',
    headers: {
      'X-Frappe-CSRF-Token': csrfToken,
    },
  });
}
```

### 📦 Build Configuration Plugin

Handles production builds with proper asset paths and HTML output for Frappe's directory structure.

#### Features

- Configures output directories for build assets
- Sets up correct asset paths for Frappe's standard directory structure
- Copies the built index.html to a specified location (typically in www)
- Optimizes asset naming for Frappe deployment

#### Configuration

```javascript
frappeReactUI({
  buildConfig: {
    // Auto-detected from app name if not specified
    outDir: '../your_app/public/frontend',
    // Base URL for assets (auto-detected from outDir if not specified)
    baseUrl: '/assets/your_app/frontend/',
    // Required: where to copy the built index.html
    indexHtmlPath: '../your_app/www/your_app.html',
    emptyOutDir: true, // Clear output directory before build
    sourcemap: true, // Generate sourcemaps
  },
})
```

## Complete Example

Here's a complete `vite.config.js` for a Frappe React app:

```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'
import frappeReactUI from 'frappe-react-ui/vite'

export default defineConfig({
  plugins: [
    react(),
    ...frappeReactUI({
      // Development proxy to Frappe backend
      frappeProxy: true,
      
      // Inject Frappe boot data
      jinjaBootData: true,
      
      // Generate TypeScript interfaces
      frappeTypes: {
        input: {
          my_app: ['User', 'Task', 'Project', 'Settings'],
          frappe: ['User', 'Role', 'Permission'],
        },
        output: 'src/types/frappe-types.ts',
      },
      
      // Production build configuration
      buildConfig: {
        indexHtmlPath: '../my_app/www/my_app.html',
        sourcemap: process.env.NODE_ENV !== 'production',
      },
    }),
  ],
  
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
  
  // Additional Vite configuration
  define: {
    __DEV__: process.env.NODE_ENV === 'development',
  },
})
```

## Integration with Frappe React UI

These plugins work seamlessly with the `frappe-react-ui` component library:

```tsx
import React from 'react'
import { useCall, Button, Card } from 'frappe-react-ui'
import type { User, Task } from './types/frappe-types'

function TaskList() {
  const { data: tasks, loading } = useCall<Task[]>({
    url: '/api/method/my_app.get_tasks',
  })
  
  const { data: users } = useCall<User[]>({
    url: '/api/method/frappe.desk.search.search_link',
    params: { doctype: 'User' },
  })

  if (loading) return <div>Loading...</div>

  return (
    <Card>
      <h2>Tasks</h2>
      {tasks?.map(task => (
        <div key={task.name}>
          <h3>{task.subject}</h3>
          <p>Status: {task.status}</p>
          <p>Assigned to: {task.assigned_to}</p>
        </div>
      ))}
    </Card>
  )
}
```

## Differences from Vue Version

The React version of these plugins has been optimized for React development:

- ❌ **No Lucide Icons Plugin**: React uses `lucide-react` package directly
- ✅ **Same Frappe Integration**: All Frappe-specific functionality preserved
- ✅ **React-Optimized**: Works with React dev tools and ecosystem
- ✅ **TypeScript First**: Full TypeScript support out of the box
