import { DocTypeInterfaceGenerator } from './doctypeInterfaceGenerator.js'
import path from 'path'

export function frappeTypes({
  input = {},
  output = 'src/types/doctypes.ts',
  appsPath = '../apps',
} = {}) {
  return {
    name: 'frappe-react-ui-types-generator',
    buildStart: async () => {
      if (Object.keys(input).length === 0) {
        console.log('No DocTypes specified for type generation')
        return
      }

      try {
        const generator = new DocTypeInterfaceGenerator(
          path.resolve(appsPath),
          input,
          path.resolve(output)
        )
        await generator.generate()
      } catch (error) {
        console.error('Failed to generate Frappe types:', error.message)
      }
    },
    handleHotUpdate: async ({ file }) => {
      // Regenerate types when DocType JSON files change
      if (file.includes('.json') && file.includes('doctype')) {
        try {
          const generator = new DocTypeInterfaceGenerator(
            path.resolve(appsPath),
            input,
            path.resolve(output)
          )
          await generator.generate()
          console.log('♻️  Regenerated Frappe types due to DocType changes')
        } catch (error) {
          console.error('Failed to regenerate types:', error.message)
        }
      }
    },
  }
}
