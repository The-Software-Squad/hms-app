const plugin = require('tailwindcss/plugin')
const forms = require('@tailwindcss/forms')
const typography = require('@tailwindcss/typography')

// Color palette - matching frappe-ui exactly
const colorPalette = {
  // Base colors
  white: '#ffffff',
  black: '#000000',
  
  // Gray scale
  gray: {
    50: '#f9fafb',
    100: '#f3f4f6',
    200: '#e5e7eb',
    300: '#d1d5db',
    400: '#9ca3af',
    500: '#6b7280',
    600: '#4b5563',
    700: '#374151',
    800: '#1f2937',
    900: '#111827',
  },
  
  // Blue
  blue: {
    50: '#eff6ff',
    100: '#dbeafe',
    200: '#bfdbfe',
    300: '#93c5fd',
    400: '#60a5fa',
    500: '#3b82f6',
    600: '#2563eb',
    700: '#1d4ed8',
    800: '#1e40af',
    900: '#1e3a8a',
  },
  
  // Green
  green: {
    50: '#f0fdf4',
    100: '#dcfce7',
    200: '#bbf7d0',
    300: '#86efac',
    400: '#4ade80',
    500: '#22c55e',
    600: '#16a34a',
    700: '#15803d',
    800: '#166534',
    900: '#14532d',
  },
  
  // Red
  red: {
    50: '#fef2f2',
    100: '#fee2e2',
    200: '#fecaca',
    300: '#fca5a5',
    400: '#f87171',
    500: '#ef4444',
    600: '#dc2626',
    700: '#b91c1c',
    800: '#991b1b',
    900: '#7f1d1d',
  },
  
  // Yellow
  yellow: {
    50: '#fefce8',
    100: '#fef3c7',
    200: '#fde68a',
    300: '#fcd34d',
    400: '#fbbf24',
    500: '#f59e0b',
    600: '#d97706',
    700: '#b45309',
    800: '#92400e',
    900: '#78350f',
  },
}

// Semantic colors - matching frappe-ui design tokens
const semanticColors = {
  // Ink colors (text)
  ink: {
    'white': 'var(--ink-white)',
    'gray-1': 'var(--ink-gray-1)',
    'gray-2': 'var(--ink-gray-2)',
    'gray-3': 'var(--ink-gray-3)',
    'gray-4': 'var(--ink-gray-4)',
    'gray-5': 'var(--ink-gray-5)',
    'gray-6': 'var(--ink-gray-6)',
    'gray-7': 'var(--ink-gray-7)',
    'gray-8': 'var(--ink-gray-8)',
    'gray-9': 'var(--ink-gray-9)',
    'blue-1': 'var(--ink-blue-1)',
    'blue-2': 'var(--ink-blue-2)',
    'blue-3': 'var(--ink-blue-3)',
    'blue-link': 'var(--ink-blue-link)',
    'green-1': 'var(--ink-green-1)',
    'green-2': 'var(--ink-green-2)',
    'red-1': 'var(--ink-red-1)',
    'red-2': 'var(--ink-red-2)',
  },
  
  // Surface colors (backgrounds)
  surface: {
    'white': 'var(--surface-white)',
    'gray-1': 'var(--surface-gray-1)',
    'gray-2': 'var(--surface-gray-2)',
    'gray-3': 'var(--surface-gray-3)',
    'gray-4': 'var(--surface-gray-4)',
    'gray-5': 'var(--surface-gray-5)',
    'gray-6': 'var(--surface-gray-6)',
    'gray-7': 'var(--surface-gray-7)',
    'blue-1': 'var(--surface-blue-1)',
    'blue-2': 'var(--surface-blue-2)',
    'blue-3': 'var(--surface-blue-3)',
    'green-1': 'var(--surface-green-1)',
    'green-2': 'var(--surface-green-2)',
    'green-3': 'var(--surface-green-3)',
    'red-1': 'var(--surface-red-1)',
    'red-2': 'var(--surface-red-2)',
    'red-3': 'var(--surface-red-3)',
    'red-4': 'var(--surface-red-4)',
    'red-5': 'var(--surface-red-5)',
    'red-6': 'var(--surface-red-6)',
    'red-7': 'var(--surface-red-7)',
  },
  
  // Outline colors (borders)
  outline: {
    'gray-1': 'var(--outline-gray-1)',
    'gray-2': 'var(--outline-gray-2)',
    'gray-3': 'var(--outline-gray-3)',
    'gray-4': 'var(--outline-gray-4)',
    'gray-modals': 'var(--outline-gray-modals)',
    'blue-1': 'var(--outline-blue-1)',
    'green-1': 'var(--outline-green-1)',
    'green-2': 'var(--outline-green-2)',
    'red-1': 'var(--outline-red-1)',
    'red-2': 'var(--outline-red-2)',
  },
}

// CSS Variables for design tokens
const cssVariables = {
  ':root': {
    // Ink (text) colors
    '--ink-white': '#ffffff',
    '--ink-gray-1': '#f3f4f6',
    '--ink-gray-2': '#e5e7eb',
    '--ink-gray-3': '#d1d5db',
    '--ink-gray-4': '#9ca3af',
    '--ink-gray-5': '#6b7280',
    '--ink-gray-6': '#4b5563',
    '--ink-gray-7': '#374151',
    '--ink-gray-8': '#1f2937',
    '--ink-gray-9': '#111827',
    '--ink-blue-1': '#dbeafe',
    '--ink-blue-2': '#3b82f6',
    '--ink-blue-3': '#1d4ed8',
    '--ink-blue-link': '#2563eb',
    '--ink-green-1': '#dcfce7',
    '--ink-green-2': '#16a34a',
    '--ink-red-1': '#fee2e2',
    '--ink-red-2': '#dc2626',
    
    // Surface (background) colors
    '--surface-white': '#ffffff',
    '--surface-gray-1': '#f9fafb',
    '--surface-gray-2': '#f3f4f6',
    '--surface-gray-3': '#e5e7eb',
    '--surface-gray-4': '#d1d5db',
    '--surface-gray-5': '#9ca3af',
    '--surface-gray-6': '#6b7280',
    '--surface-gray-7': '#4b5563',
    '--surface-blue-1': '#eff6ff',
    '--surface-blue-2': '#dbeafe',
    '--surface-blue-3': '#3b82f6',
    '--surface-green-1': '#f0fdf4',
    '--surface-green-2': '#dcfce7',
    '--surface-green-3': '#22c55e',
    '--surface-red-1': '#fef2f2',
    '--surface-red-2': '#fee2e2',
    '--surface-red-3': '#fecaca',
    '--surface-red-4': '#fca5a5',
    '--surface-red-5': '#ef4444',
    '--surface-red-6': '#dc2626',
    '--surface-red-7': '#b91c1c',
    
    // Outline (border) colors
    '--outline-gray-1': '#e5e7eb',
    '--outline-gray-2': '#d1d5db',
    '--outline-gray-3': '#9ca3af',
    '--outline-gray-4': '#6b7280',
    '--outline-gray-modals': '#d1d5db',
    '--outline-blue-1': '#bfdbfe',
    '--outline-green-1': '#bbf7d0',
    '--outline-green-2': '#86efac',
    '--outline-red-1': '#fecaca',
    '--outline-red-2': '#fca5a5',
  },
  
  // Dark theme variables
  '[data-theme="dark"]': {
    '--ink-white': '#000000',
    '--ink-gray-1': '#1f2937',
    '--ink-gray-2': '#374151',
    '--ink-gray-3': '#4b5563',
    '--ink-gray-4': '#6b7280',
    '--ink-gray-5': '#9ca3af',
    '--ink-gray-6': '#d1d5db',
    '--ink-gray-7': '#e5e7eb',
    '--ink-gray-8': '#f3f4f6',
    '--ink-gray-9': '#f9fafb',
    '--surface-white': '#111827',
    '--surface-gray-1': '#1f2937',
    '--surface-gray-2': '#374151',
    '--surface-gray-3': '#4b5563',
    '--surface-gray-4': '#6b7280',
    '--outline-gray-1': '#374151',
    '--outline-gray-2': '#4b5563',
    '--outline-gray-3': '#6b7280',
    '--outline-gray-modals': '#4b5563',
  },
}

const globalStyles = (theme) => ({
  html: {
    'font-family': `Inter, ${theme('fontFamily.sans')}`,
  },
  '@supports (font-variation-settings: normal)': {
    html: {
      'font-family': `InterVar, ${theme('fontFamily.sans')}`,
      'font-optical-sizing': 'auto',
    },
  },
  'html, body, button, p, span, div': {
    fontVariationSettings: "'opsz' 24",
    WebkitFontSmoothing: 'antialiased',
    MozOsxFontSmoothing: 'grayscale',
  },
  select: {
    backgroundImage:
      'url(\'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" fill="none" stroke="%237C7C7C" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" aria-hidden="true" viewBox="0 0 24 24" ><path d="m6 9 6 6 6-6" /></svg>\')',
    backgroundSize: '1.13em',
    backgroundPosition: 'right 0.44rem center',
  },
})

// Fixed component styles - moved problematic selectors to base styles
const componentStyles = {
  '.form-input, .form-textarea, .form-select': {
    '@apply h-7 rounded border border-[--surface-gray-2] bg-surface-gray-2 py-1.5 pl-2 pr-2 text-base text-ink-gray-8 placeholder-ink-gray-4 transition-colors hover:border-outline-gray-modals hover:bg-surface-gray-3 focus:border-outline-gray-4 focus:bg-surface-white focus:shadow-sm focus:ring-0 focus-visible:ring-2 focus-visible:ring-outline-gray-3':
      {},
  },
  '.form-checkbox': {
    '@apply rounded-md bg-surface-gray-2 text-ink-blue-2 focus:ring-0 focus-visible:ring-1':
      {},
  },
}

// Fixed: Move complex selectors to base styles instead of component styles
const additionalBaseStyles = {
  "[data-theme='dark'] [type='checkbox']:checked": {
    'background-image': `url("data:image/svg+xml,%3csvg viewBox='0 0 16 16' fill='%230F0F0F' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z'/%3e%3c/svg%3e")`,
  },
  "[data-theme='dark'] img": {
    filter: 'brightness(.8) contrast(1.2)',
  },
}

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: ['selector', '[data-theme="dark"]'],
  theme: {
    colors: {
      ...colorPalette,
      ...semanticColors,
    },
    borderRadius: {
      none: '0px',
      sm: '0.25rem',
      DEFAULT: '0.5rem',
      md: '0.625rem',
      lg: '0.75rem',
      xl: '1rem',
      '2xl': '1.25rem',
      full: '9999px',
    },
    boxShadow: {
      sm: '0px 1px 2px rgba(0, 0, 0, 0.1)',
      DEFAULT: '0px 0px 1px rgba(0, 0, 0, 0.45), 0px 1px 2px rgba(0, 0, 0, 0.1)',
      md: '0px 0px 1px rgba(0, 0, 0, 0.12), 0px 0.5px 2px rgba(0, 0, 0, 0.15), 0px 2px 3px rgba(0, 0, 0, 0.16)',
      lg: '0px 0px 1px rgba(0, 0, 0, 0.35), 0px 6px 8px -4px rgba(0, 0, 0, 0.1)',
      xl: '0px 0px 1px rgba(0, 0, 0, 0.19), 0px 1px 2px rgba(0, 0, 0, 0.07), 0px 6px 15px -5px rgba(0, 0, 0, 0.11)',
      '2xl': '0px 0px 1px rgba(0, 0, 0, 0.2), 0px 1px 3px rgba(0, 0, 0, 0.05), 0px 10px 24px -3px rgba(0, 0, 0, 0.1)',
      none: 'none',
    },
    fontSize: {
      '2xs': ['11px', { lineHeight: '1.15', letterSpacing: '0.01em', fontWeight: '420' }],
      xs: ['12px', { lineHeight: '1.15', letterSpacing: '0.02em', fontWeight: '420' }],
      sm: ['13px', { lineHeight: '1.15', letterSpacing: '0.02em', fontWeight: '420' }],
      base: ['14px', { lineHeight: '1.15', letterSpacing: '0.02em', fontWeight: '420' }],
      lg: ['16px', { lineHeight: '1.15', letterSpacing: '0.02em', fontWeight: '400' }],
      xl: ['18px', { lineHeight: '1.15', letterSpacing: '0.01em', fontWeight: '400' }],
      '2xl': ['20px', { lineHeight: '1.15', letterSpacing: '0.01em', fontWeight: '400' }],
      '3xl': ['24px', { lineHeight: '1.15', fontWeight: 400, letterSpacing: '0.005em' }],
      // Paragraph font sizes
      'p-2xs': ['11px', { lineHeight: '1.6', letterSpacing: '0.01em', fontWeight: '420' }],
      'p-xs': ['12px', { lineHeight: '1.6', letterSpacing: '0.02em', fontWeight: '420' }],
      'p-sm': ['13px', { lineHeight: '1.5', letterSpacing: '0.02em', fontWeight: '420' }],
      'p-base': ['14px', { lineHeight: '1.5', letterSpacing: '0.02em', fontWeight: '420' }],
      'p-lg': ['16px', { lineHeight: '1.5', letterSpacing: '0.02em', fontWeight: '400' }],
      'p-xl': ['18px', { lineHeight: '1.42', letterSpacing: '0.01em', fontWeight: '400' }],
      'p-2xl': ['20px', { lineHeight: '1.38', letterSpacing: '0.01em', fontWeight: '400' }],
      'p-3xl': ['24px', { lineHeight: '1.2', fontWeight: 400, letterSpacing: '0.005em' }],
    },
    extend: {
      spacing: {
        4.5: '1.125rem',
        5.5: '1.375rem',
        6.5: '1.625rem',
        7.5: '1.875rem',
        8.5: '2.125rem',
        9.5: '2.375rem',
        10.5: '2.625rem',
        11.5: '2.875rem',
        12.5: '3.125rem',
        13: '3.25rem',
        13.5: '3.375rem',
        14.5: '3.625rem',
        15: '3.75rem',
        15.5: '3.875rem',
      },
      width: {
        3.5: '0.875rem',
        112: '28rem',
        wizard: '650px',
      },
      height: {
        3.5: '0.875rem',
      },
      minWidth: {
        40: '10rem',
        50: '18rem',
      },
      maxHeight: {
        52: '13rem',
      },
    },
  },
  plugins: [
    forms,
    typography,
    plugin(function ({ addBase, addComponents, theme }) {
      // Add all base styles including CSS variables and complex selectors
      addBase({ 
        ...globalStyles(theme), 
        ...cssVariables,
        ...additionalBaseStyles 
      })
      // Only add proper component utilities
      addComponents(componentStyles)
    }),
  ],
}